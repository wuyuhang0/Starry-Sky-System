#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import division
import pygame,sys,random,time,turtle
import math
from wx import *
import os
import time
import sys

import requests
import json
from copy import *
from tkinter.ttk import Button,Entry,Radiobutton,Scrollbar
from tkinter import END,Label,Tk,StringVar,Listbox,messagebox,SINGLE,PhotoImage
"""
VIP视频解析：http://www.vipjiexi.com/
无名小站：http://www.wmxz.wang/
http://www.iqiyi.com/lib/dianying/%E5%96%9C%E5%89%A7,%E4%B8%AD%E5%9B%BD%E5%A4%A7%E9%99%86,2018_11_1.html
"""
# from moviepy.editor import *
import pyglet
from pyglet.media import *
import requests
import re
import os
from lxml import etree
from  selenium import webdriver
import wx
import wx.html2
import webbrowser
from PIL import Image,ImageTk
import io
import re
import requests
import tkinter as tk
import sys
from PyQt5.QtWidgets import (QWidget, QDesktopWidget,
    QMessageBox, QHBoxLayout, QVBoxLayout, QSlider, QListWidget,
    QPushButton, QLabel, QComboBox, QFileDialog)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt, QUrl, QTimer
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
import os, time
import configparser
from PIL import Image, ImageTk
from tkinter.filedialog import askdirectory
import tkinter.messagebox
import pyperclip 
import tkinter
from tkinter import Button
from tkinter import Label
from tkinter import Entry
from tkinter import Scale
from tkinter import Label,PhotoImage
from tkinter import messagebox
from tkinter import Toplevel
import copy
from pymediainfo import MediaInfo
import re
from tkinter import Message
import threading
from tkinter.filedialog   import askopenfilename
from tkinter.filedialog import askdirectory
from tkinter import StringVar
import os
from cefpython3 import cefpython
from pygame.locals import *
import wx
from tkinter import *
import tkinter.filedialog
import tkinter.messagebox as tmb
import urllib.request
from lxml import etree
from time import*
from tkinter import*
import wx.html2
import pygame.gfxdraw
from collections import namedtuple
from collections import deque
from pyglet import image
from pyglet.gl import *
import numpy as np
from datetime import*
import platform
import wx.html2
from pygame.color import THECOLORS as COLORS
from collections import OrderedDict
from pyglet.graphics import TextureGroup
from pyglet.window import key, mouse
from tkinter.ttk import *
from math import *
pygame.init()
from easygui import *
import wmi
import psutil
from os import path
from sys import exit
from time import sleep
from random import choice
from itertools import product
from matplotlib import pyplot as plt
from tkinter.colorchooser import askcolor
from datetime import*
from win10toast import ToastNotifier
class ErrorAction(ToastNotifier):
    def __init__(self,text = ''):
        super().__init__()
        self.show_toast(title="Error!", msg=text,
                        duration=2)
                        
class InfoAction(ToastNotifier):
    def __init__(self,title = '嘿,有一个事情',text = ''):
        super().__init__()
        self.show_toast(title=title, msg=text,
                        duration=2)
                        
class AskAction(ToastNotifier):
    def __init__(self,title = '嘿,有一个问题',text = ''):
        super().__init__()
        self.show_toast(title=title, msg=text,
                        duration=2)
from MBPython import miniblink
from pygame.locals import QUIT, KEYDOWN
if (sys.version_info > (3, 0)):
    from tkinter import *
    from tkinter import messagebox
else:
    from Tkinter import *
import wx,tkinter
from wx import *
import time
import math
from math import *
global dakai,xuanzhong
kaishijian = "win10开始键.png"
applist = ["浏览器","计算器","画图器(未开放)","聊天机器人","BMI检测(未开放)","五子棋","我的世界","贪吃蛇","俄罗斯方块","2048游戏(未开放)","数字华容道","数独游戏","沙盘游戏","Flappy Bird","绘画板","记事本","代码编辑器","音乐播放器","小球打砖块","设置(未开放)","迷宫游戏(未开放)","打字游戏","此电脑文件(未开放)","视频播放器(未开放)"]
dakailist = ["setting","chrome","jisuan","huatu","qq","bmi","off","wuziqi","minecraft","snake","eluosi","twofour","huarong","shudu","shapan","flybird","huihua","wenben","code","music"]
mousex, mousey = pygame.mouse.get_pos()
mouseRect = pygame.Rect(mousex,mousey,5,5)
settingRect = pygame.Rect(50,25,50,50)
chromeRect = pygame.Rect(125,25,50,50)
jisuanRect = pygame.Rect(200,25,50,50)
musicRect = pygame.Rect(275,25,50,50)
qqRect = pygame.Rect(350,25,50,50)
offRect = pygame.Rect(0,710,60,60)
codeRect = pygame.Rect(425,25,50,50)
wuziqiRect = pygame.Rect(500,25,50,50)
minecraftRect = pygame.Rect(575,25,50,50)
snakeRect = pygame.Rect(650,25,50,50)
eluosiRect = pygame.Rect(725,25,50,50)
daziRect = pygame.Rect(800,25,50,50)
huarongRect = pygame.Rect(875,25,50,50)
shuduRect = pygame.Rect(950,25,50,50)
shapanRect = pygame.Rect(50,100,50,50)
flybirdRect = pygame.Rect(125,100,50,50)
huihuaRect = pygame.Rect(200,100,50,50)
wenbenRect = pygame.Rect(275,100,50,50)
huatuRect = pygame.Rect(350,100,50,50)
xiaoqiuRect = pygame.Rect(425,100,50,50)
migongRect = pygame.Rect(500,100,50,50)
shipinRect = pygame.Rect(575,100,50,50)
mofangRect = pygame.Rect(650,100,50,50)
twofourRect = pygame.Rect(725,100,50,50)
tuixiangRect = pygame.Rect(800,100,50,50)
chidouRect = pygame.Rect(875,100,50,50)
golfRect = pygame.Rect(950,100,50,50)
paokuRect = pygame.Rect(50,175,50,50)
saoleiRect = pygame.Rect(125,175,50,50)
saicheRect = pygame.Rect(200,175,50,50)
dongwuRect = pygame.Rect(275,175,50,50)
fanpaiRect = pygame.Rect(350,175,50,50)
qiangzhanRect = pygame.Rect(425,175,50,50)
tafangRect = pygame.Rect(500,175,50,50)
tailaRect = pygame.Rect(575,175,50,50)
baoweiRect = pygame.Rect(650,175,50,50)
renzheRect = pygame.Rect(725,175,50,50)
feijiRect = pygame.Rect(800,175,50,50)
secaiRect = pygame.Rect(875,175,50,50)
hepingRect = pygame.Rect(950,175,50,50)
wangzheRect = pygame.Rect(50,250,50,50)
shijianRect = pygame.Rect(800,710,60,60)
cortanaRect = pygame.Rect(70,710,60,60)
souRect = pygame.Rect(140,710,60,60)
renwuRect = pygame.Rect(210,710,60,60)
kongzhi = pygame.transform.scale(pygame.image.load("files.ico"),(50,50))
chrome = pygame.transform.scale(pygame.image.load("chrome.jpeg"),(50,50))
jisuan = pygame.transform.scale(pygame.image.load("计算器.jpg"),(50,50))
music = pygame.transform.scale(pygame.image.load("音乐播放器.jpeg"),(50,50))
bg = pygame.transform.scale(pygame.image.load("png.jpeg"),(1200,800))
qq = pygame.transform.scale(pygame.image.load("聊天机器人.jpg"),(50,50))
twofour = pygame.transform.scale(pygame.image.load("2048游戏.jpeg"),(50,50))
code = pygame.transform.scale(pygame.image.load("icon.jpg"),(50,50))
wuziqi = pygame.transform.scale(pygame.image.load("五子棋.jpeg"),(50,50))
minecraft = pygame.transform.scale(pygame.image.load("我的世界.jpeg"),(50,50))
snake = pygame.transform.scale(pygame.image.load("贪吃蛇.jpeg"),(50,50))
eluosi = pygame.transform.scale(pygame.image.load("俄罗斯方块.jpeg"),(50,50))
dazi = pygame.transform.scale(pygame.image.load("打字游戏.jpeg"),(50,50))
caidan = pygame.transform.scale(pygame.image.load("菜单栏.png"),(1300,60))
huarong = pygame.transform.scale(pygame.image.load("数字华容道.jpeg"),(50,50))
shudu = pygame.transform.scale(pygame.image.load("数独游戏.jpeg"),(50,50))
shapan = pygame.transform.scale(pygame.image.load("沙盘游戏.png"),(50,50))
flybird = pygame.transform.scale(pygame.image.load("flybird.jpeg"),(50,50))
huihua = pygame.transform.scale(pygame.image.load("画图.jpeg"),(50,50))
wenben = pygame.transform.scale(pygame.image.load("记事本.jpeg"),(50,50))
huatu = pygame.transform.scale(pygame.image.load("画图器.jpg"),(50,50))
xiaoqiu = pygame.transform.scale(pygame.image.load("小球打砖块.jpeg"),(50,50))
migong = pygame.transform.scale(pygame.image.load("迷宫游戏.jpg"),(50,50))
shipin = pygame.transform.scale(pygame.image.load("视频播放器.jpeg"),(50,50))
mofang = pygame.transform.scale(pygame.image.load("魔方游戏.jpeg"),(50,50))
tuixiang = pygame.transform.scale(pygame.image.load("推箱子.jpeg"),(50,50))
chidou = pygame.transform.scale(pygame.image.load("吃豆人游戏.jpeg"),(50,50))
golf = pygame.transform.scale(pygame.image.load("高尔夫球游戏.png"),(50,50))
paoku = pygame.transform.scale(pygame.image.load("跑酷游戏.jpeg"),(50,50))
saolei = pygame.transform.scale(pygame.image.load("扫雷游戏.jpeg"),(50,50))
saiche = pygame.transform.scale(pygame.image.load("赛车游戏.png"),(50,50))
dongwu = pygame.transform.scale(pygame.image.load("动物棋.jpg"),(50,50))
fanpai = pygame.transform.scale(pygame.image.load("翻牌.jpeg"),(50,50))
qiangzhan = pygame.transform.scale(pygame.image.load("枪战游戏.jpeg"),(50,50))
tafang = pygame.transform.scale(pygame.image.load("塔防游戏.jpeg"),(50,50))
taila = pygame.transform.scale(pygame.image.load("泰拉瑞亚.jpeg"),(50,50))
baowei = pygame.transform.scale(pygame.image.load("保卫萝卜.jpeg"),(50,50))
renzhe = pygame.transform.scale(pygame.image.load("忍者游戏.jpeg"),(50,50))
feiji = pygame.transform.scale(pygame.image.load("模拟飞机.jpeg"),(50,50))
secai = pygame.transform.scale(pygame.image.load("色彩游戏.jpeg"),(50,50))
heping = pygame.transform.scale(pygame.image.load("和平精英.jpeg"),(50,50))
wangzhe = pygame.transform.scale(pygame.image.load("王者荣耀.jpeg"),(50,50))
shijian = pygame.transform.scale(pygame.image.load("时钟.jpeg"),(60,60))
dianliang = pygame.transform.scale(pygame.image.load("电池.png"),(60,60))
shengyin = pygame.transform.scale(pygame.image.load("声音.png"),(60,60))
wangluo = pygame.transform.scale(pygame.image.load("网络.png"),(60,60))
myFont = pygame.font.SysFont("STzhongsong",15)
kongzhiText = myFont.render("此电脑",True,(255,255,255))
chromeText = myFont.render("浏览器",True,(255,255,255))
jisuanText = myFont.render("计算器",True,(255,255,255))
musicText = myFont.render("音乐播放器",True,(255,255,255))
qqText = myFont.render("聊天机器人",True,(255,255,255))
codeText = myFont.render("代码编辑器",True,(255,255,255))
wuziqiText = myFont.render("五子棋",True,(255,255,255))
minecraftText = myFont.render("我的世界",True,(255,255,255))
snakeText = myFont.render("贪吃蛇",True,(255,255,255))
eluosiText = myFont.render("俄罗斯方块",True,(255,255,255))
daziText = myFont.render("打字游戏",True,(255,255,255))
huarongText = myFont.render("数字华容道",True,(255,255,255))
shuduText = myFont.render("数独游戏",True,(255,255,255))
shapanText = myFont.render("沙盘游戏",True,(255,255,255))
flybirdText = myFont.render("Flappy Bird",True,(255,255,255))
huihuaText = myFont.render("绘画板",True,(255,255,255))
wenbenText = myFont.render("记事本",True,(255,255,255))
huatuText = myFont.render("画图器",True,(255,255,255))
xiaoqiuText = myFont.render("小球打砖块",True,(255,255,255))
migongText = myFont.render("迷宫游戏",True,(255,255,255))
shipinText = myFont.render("视频播放器",True,(255,255,255))
mofangText = myFont.render("魔方游戏",True,(255,255,255))
twofourText = myFont.render("2048游戏",True,(255,255,255))
tuixiangText = myFont.render("推箱子",True,(255,255,255))
chidouText = myFont.render("吃豆人",True,(255,255,255))
golfText = myFont.render("高尔夫球",True,(255,255,255))
paokuText = myFont.render("跑酷游戏",True,(255,255,255))
saoleiText = myFont.render("扫雷游戏",True,(255,255,255))
saicheText = myFont.render("赛车游戏",True,(255,255,255))
dongwuText = myFont.render("动物棋",True,(255,255,255))
fanpaiText = myFont.render("记忆翻牌",True,(255,255,255))
qiangzhanText = myFont.render("枪战游戏",True,(255,255,255))
tafangText = myFont.render("塔防游戏",True,(255,255,255))
tailaText = myFont.render("泰拉瑞亚",True,(255,255,255))
baoweiText = myFont.render("保卫萝卜",True,(255,255,255))
renzheText = myFont.render("忍者游戏",True,(255,255,255))
feijiText = myFont.render("模拟飞机",True,(255,255,255))
secaiText = myFont.render("色彩游戏",True,(255,255,255))
hepingText = myFont.render("和平精英",True,(255,255,255))
wangzheText = myFont.render("王者荣耀",True,(255,255,255))
messagebox.showinfo("欢迎","尊敬的用户，您好！")
messagebox.showinfo("欢迎","欢迎使用星空模拟系统(Starry Sky System,简称S.S.S模拟系统)")
messagebox.showinfo("欢迎","本系统功能齐全，有各种工具与游戏供您使用。")
messagebox.showinfo("欢迎","本系统不同于社区其他系统，本系统是完全以Python为脚本语言，采用了pygame、tkinter、wxpython等多种可视化工具打造的一款图形化模拟系统，而非文字系统。")
messagebox.showinfo("欢迎","本系统完全仿照windows 10系统的UI图形化界面制作，带给您熟悉而方便快捷的体验。")
messagebox.showinfo("欢迎","本系统虽为模拟系统，但却有许多功能与目前电脑系统有直接联系，真实与模拟的电脑系统相交融，带来真正的方便！")
messagebox.showinfo("欢迎","最后，祝您使用愉快！")
pygame.display.set_caption("Starry Sky System(星空系统)")
clip = VideoFileClip('open.mp4')
clip= clip.resize(newsize=(1280,720))
clip.preview()
def fasdasdf1():

    global dakai,xuanzhong
    xuanzhong = None
    dakai = None
    pygame.init()
    screen = pygame.display.set_mode((1024,768))
    pygame.display.set_caption("Starry Sky System(星空系统)")
    # clip = VideoFileClip('open.mp4')
    # clip= clip.resize(newsize=(1280,720))
    # clip.preview()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if messagebox.askokcancel("是否退出", "您确定退出吗（主窗口退出将直接结束程序）"):
                    sys.exit(0)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if mouseRect.colliderect(settingRect):
                    if xuanzhong == "setting":
                        dakai = "setting"
                        break
                    else:
                        xuanzhong = "setting"
                elif mouseRect.colliderect(chromeRect):
                    if xuanzhong == "chrome":
                        dakai = "chrome"
                        
                    else:
                        xuanzhong = "chrome"
                elif mouseRect.colliderect(jisuanRect):
                    if xuanzhong == "jisuan":
                        dakai = "jisuan"
                    else:
                        xuanzhong = "jisuan"
                elif mouseRect.colliderect(qqRect):
                    if xuanzhong == "qq":
                        dakai = "qq"
                    else:
                        xuanzhong = "qq"
                elif mouseRect.colliderect(offRect):
                    if xuanzhong == "off":
                        dakai = "off"
                    else:
                        dakai = "off"
                elif mouseRect.colliderect(wuziqiRect):
                    if xuanzhong == "wuziqi":
                        dakai = "wuziqi"
                    else:
                        xuanzhong = "wuziqi"
                elif mouseRect.colliderect(minecraftRect):
                    if xuanzhong == "minecraft":
                        dakai = "minecraft"
                    else:
                        xuanzhong = "minecraft"
                elif mouseRect.colliderect(snakeRect):
                    if xuanzhong == "snake":
                        dakai = "snake"
                    else:
                        xuanzhong = "snake"
                elif mouseRect.colliderect(eluosiRect):
                    if xuanzhong == "eluosi":
                        dakai = "eluosi"
                    else:
                        xuanzhong = "eluosi"
                elif mouseRect.colliderect(daziRect):
                    if xuanzhong == "dazi":
                        dakai = "dazi"
                    else:
                        xuanzhong = "dazi"
                elif mouseRect.colliderect(huarongRect):
                    if xuanzhong == "huarong":
                        dakai = "huarong"
                    else:
                        xuanzhong = "huarong"
                elif mouseRect.colliderect(shuduRect):
                    if xuanzhong == "shudu":
                        dakai = "shudu"
                    else:
                        xuanzhong = "shudu"
                elif mouseRect.colliderect(shapanRect):
                    if xuanzhong == "shapan":
                        dakai = "shapan"
                    else:
                        xuanzhong = "shapan"
                elif mouseRect.colliderect(flybirdRect):
                    if xuanzhong == "flybird":
                        dakai = "flybird"
                    else:
                        xuanzhong = "flybird"
                elif mouseRect.colliderect(huihuaRect):
                    if xuanzhong == "huihua":
                        dakai = "huihua"
                    else:
                        xuanzhong = "huihua"
                elif mouseRect.colliderect(wenbenRect):
                    if xuanzhong == "wenben":
                        dakai = "wenben"
                    else:
                        xuanzhong = "wenben"
                elif mouseRect.colliderect(codeRect):
                    if xuanzhong == "code":
                        dakai = "code"
                    else:
                        xuanzhong = "code"
                elif mouseRect.colliderect(musicRect):
                    if xuanzhong == "music":
                        dakai = "music"
                    else:
                        xuanzhong = "music"
                elif mouseRect.colliderect(huatuRect):
                    if xuanzhong == "huatu":
                        dakai = "huatu"
                    else:
                        xuanzhong = "huatu"
                elif mouseRect.colliderect(xiaoqiuRect):
                    if xuanzhong == "xiaoqiu":
                        dakai = "xiaoqiu"
                    else:
                        xuanzhong = "xiaoqiu"
                elif mouseRect.colliderect(migongRect):
                    if xuanzhong == "migong":
                        dakai = "migong"
                    else:
                        xuanzhong = "migong"
                elif mouseRect.colliderect(shipinRect):
                    if xuanzhong == "shipin":
                        dakai = "shipin"
                    else:
                        xuanzhong = "shipin"
                elif mouseRect.colliderect(mofangRect):
                    if xuanzhong == "mofang":
                        dakai = "mofang"
                    else:
                        xuanzhong = "mofang"
                elif mouseRect.colliderect(twofourRect):
                    if xuanzhong == "twofour":
                        dakai = "twofour"
                    else:
                        xuanzhong = "twofour"
                elif mouseRect.colliderect(tuixiangRect):
                    if xuanzhong == "tuixiang":
                        dakai = "tuixiang"
                    else:
                        xuanzhong = "tuixiang"
                elif mouseRect.colliderect(chidouRect):
                    if xuanzhong == "chidou":
                        dakai = "chidou"
                    else:
                        xuanzhong = "chidou"
                elif mouseRect.colliderect(golfRect):
                    if xuanzhong == "golf":
                        dakai = "golf"
                    else:
                        xuanzhong = "golf"
                elif mouseRect.colliderect(paokuRect):
                    if xuanzhong == "paoku":
                        dakai = "paoku"
                    else:
                        xuanzhong = "paoku"
                elif mouseRect.colliderect(saoleiRect):
                    if xuanzhong == "saolei":
                        dakai = "saolei"
                    else:
                        xuanzhong = "saolei"
                elif mouseRect.colliderect(saicheRect):
                    if xuanzhong == "saiche":
                        dakai = "saiche"
                    else:
                        xuanzhong = "saiche"
                elif mouseRect.colliderect(dongwuRect):
                    if xuanzhong == "dongwu":
                        dakai = "dongwu"
                    else:
                        xuanzhong = "dongwu"
                elif mouseRect.colliderect(fanpaiRect):
                    if xuanzhong == "fanpai":
                        dakai = "fanpai"
                    else:
                        xuanzhong = "fanpai"
                elif mouseRect.colliderect(qiangzhanRect):
                    if xuanzhong == "qiangzhan":
                        dakai = "qiangzhan"
                    else:
                        xuanzhong = "qiangzhan"
                elif mouseRect.colliderect(tafangRect):
                    if xuanzhong == "tafang":
                        dakai = "tafang"
                    else:
                        xuanzhong = "tafang"
                elif mouseRect.colliderect(tailaRect):
                    if xuanzhong == "taila":
                        dakai = "taila"
                    else:
                        xuanzhong = "taila"
                elif mouseRect.colliderect(baoweiRect):
                    if xuanzhong == "baowei":
                        dakai = "baowei"
                    else:
                        xuanzhong = "baowei"
                elif mouseRect.colliderect(renzheRect):
                    if xuanzhong == "renzhe":
                        dakai = "renzhe"
                    else:
                        xuanzhong = "renzhe"
                elif mouseRect.colliderect(feijiRect):
                    if xuanzhong == "feiji":
                        dakai = "feiji"
                    else:
                        xuanzhong = "feiji"
                elif mouseRect.colliderect(hepingRect):
                    if xuanzhong == "heping":
                        dakai = "heping"
                    else:
                        xuanzhong = "heping"
                elif mouseRect.colliderect(secaiRect):
                    if xuanzhong == "secai":
                        dakai = "secai"
                    else:
                        xuanzhong = "secai"
                elif mouseRect.colliderect(wangzheRect):
                    if xuanzhong == "wangzhe":
                        dakai = "wangzhe"
                    else:
                        xuanzhong = "wangzhe"
                elif mouseRect.colliderect(shijianRect):
                    dakai = "shijian"
                elif mouseRect.colliderect(cortanaRect):
                    dakai = "cortana" 
            if mouseRect.colliderect(offRect) and not(event.type == pygame.MOUSEBUTTONDOWN):
                kaishijian = "windows10.png"
            else:
                kaishijian = "win10开始键.png"
            if mouseRect.colliderect(cortanaRect) and not(event.type == pygame.MOUSEBUTTONDOWN):
                cortanajian = "cortana1.png"
            else:
                cortanajian = "cortana.png"
            if mouseRect.colliderect(souRect) and not(event.type == pygame.MOUSEBUTTONDOWN):
                soujian = "sou1.png"
            else:
                soujian = "sou.png"
            if mouseRect.colliderect(renwuRect) and not(event.type == pygame.MOUSEBUTTONDOWN):
                renwujian = "任务视图1.png"
            else:
                renwujian = "任务视图.png"
        if dakai != None:
            pygame.quit()
            break
        screen.fill((255,255,255))
        screen.blit(bg,(0,0))
        screen.blit(kongzhi,(50,25))
        screen.blit(kongzhiText,(60,75))
        screen.blit(chrome,(125,25))
        screen.blit(chromeText,(125,75))
        screen.blit(jisuan,(200,25))
        screen.blit(jisuanText,(200,75))
        screen.blit(music,(275,25))
        screen.blit(musicText,(260,75))
        screen.blit(qq, (350, 25))
        screen.blit(qqText, (340, 75))
        screen.blit(code,(425,25))
        screen.blit(codeText,(418,75))
        screen.blit(wuziqi,(500,25))
        screen.blit(wuziqiText,(500,75))
        screen.blit(minecraft,(575,25))
        screen.blit(minecraftText,(575,75))
        screen.blit(snake,(650,25))
        screen.blit(snakeText,(650,75))
        screen.blit(eluosi,(725,25))
        screen.blit(eluosiText,(710,75))
        screen.blit(dazi,(800,25))
        screen.blit(daziText,(790,75))
        screen.blit(huarong,(875,25))
        screen.blit(huarongText,(860,75))
        screen.blit(shudu,(950,25))
        screen.blit(shuduText,(945,75))
        screen.blit(shapan,(50,100))
        screen.blit(shapanText,(40,150))
        screen.blit(flybird,(125,100))
        screen.blit(flybirdText,(110,150))
        screen.blit(huihua,(200,100))
        screen.blit(huihuaText,(210,150))
        screen.blit(wenben,(275,100))
        screen.blit(wenbenText,(275,150))
        screen.blit(huatu,(350,100))
        screen.blit(huatuText,(350,150))
        screen.blit(xiaoqiu,(425,100))
        screen.blit(xiaoqiuText,(405,150))
        screen.blit(migong,(500,100))
        screen.blit(migongText,(490,150))
        screen.blit(shipin,(575,100))
        screen.blit(shipinText,(560,150))
        screen.blit(mofang,(650,100))
        screen.blit(mofangText,(640,150))
        screen.blit(twofour,(725,100))
        screen.blit(twofourText,(715,150))
        screen.blit(tuixiang,(800,100))
        screen.blit(tuixiangText,(795,150))
        screen.blit(chidou,(875,100))
        screen.blit(chidouText,(870,150))
        screen.blit(golf,(950,100))
        screen.blit(golfText,(945,150))
        screen.blit(paoku,(50,175))
        screen.blit(paokuText,(50,225))
        screen.blit(saolei,(125,175))
        screen.blit(saoleiText,(125,225))
        screen.blit(saiche,(200,175))
        screen.blit(saicheText,(200,225))
        screen.blit(dongwu,(275,175))
        screen.blit(dongwuText,(275,225))
        screen.blit(fanpai,(350,175))
        screen.blit(fanpaiText,(350,225))
        screen.blit(qiangzhan,(425,175))
        screen.blit(qiangzhanText,(425,225))
        screen.blit(tafang,(500,175))
        screen.blit(tafangText,(500,225))
        screen.blit(taila,(575,175))
        screen.blit(tailaText,(575,225))
        screen.blit(baowei,(650,175))
        screen.blit(baoweiText,(650,225))
        screen.blit(renzhe,(725,175))
        screen.blit(renzheText,(725,225))
        screen.blit(feiji,(800,175))
        screen.blit(feijiText,(800,225))
        screen.blit(secai,(875,175))
        screen.blit(secaiText,(875,225))
        screen.blit(heping,(950,175))
        screen.blit(hepingText,(950,225))
        screen.blit(wangzhe,(50,250))
        screen.blit(wangzheText,(50,300))
        screen.blit(caidan,(81,710))
        screen.blit(shijian,(800,710))
        screen.blit(dianliang,(863,710))
        screen.blit(shengyin,(918,710))
        screen.blit(wangluo,(975,710))
        
        off = pygame.transform.scale(pygame.image.load(kaishijian),(80,60))
        cortana = pygame.transform.scale(pygame.image.load(cortanajian),(60,60))
        sou = pygame.transform.scale(pygame.image.load(soujian),(60,60))
        renwu = pygame.transform.scale(pygame.image.load(renwujian),(60,60))
        screen.blit(off,(0,710))
        screen.blit(cortana,(70,710))
        screen.blit(sou,(140,710))
        screen.blit(renwu,(210,710))
        
        mouseRect.center = (pygame.mouse.get_pos())
        pygame.display.update()
    if dakai == "setting":
        try:
            # -*- coding: utf-8 -*-
            __author__ = 'Yang'

            class Application_UI(object):

                # path = r"E:\\python开发工具\\project\\tkinter"
                path = os.path.abspath(".")
                file_types = [".png", ".jpg", ".jpeg", ".ico", ".gif"]
                scroll_visiblity = True

                font = 11
                font_type = "Courier New"

                def __init__(self):
                    # 设置UI界面
                    window = tkinter.Tk()
                    self.root = window
                    win_width = 800
                    win_height = 600

                    screen_width, screen_height = window.maxsize()
                    x = int((screen_width - win_width) / 2)
                    y = int((screen_height - win_height) / 2)
                    window.title("文件管理工具")
                    window.geometry("%sx%s+%s+%s" % (win_width, win_height, x, y))

                    menu = tkinter.Menu(window)
                    window.config(menu=menu)

                    selct_path = tkinter.Menu(menu, tearoff=0)
                    selct_path.add_command(label="打开", accelerator="Ctrl + O", command=self.open_dir)
                    selct_path.add_command(label="保存", accelerator="Ctrl + S", command=self.save_file)

                    menu.add_cascade(label="文件", menu=selct_path)

                    about = tkinter.Menu(menu, tearoff=0)
                    about.add_command(label="版本", accelerator="v1.0.0")
                    about.add_command(label="作者", accelerator="样子")
                    menu.add_cascade(label="关于", menu=about)

                    # 顶部frame
                    top_frame = Frame(window, bg="#fff")
                    top_frame.pack(side=TOP, fill=X)
                    label = Label(top_frame, text="当前选中路径：", bg="#fff")
                    label.pack(side=LEFT)

                    self.path_var = StringVar()
                    self.path_var.set("无")
                    label_path = Label(top_frame, textvariable=self.path_var, bg="#fff", fg="red", height=2)
                    label_path.pack(anchor=W)

                    paned_window = PanedWindow(window, showhandle=False, orient=HORIZONTAL)
                    paned_window.pack(expand=1, fill=BOTH)

                    # 左侧frame
                    self.left_frame = Frame(paned_window)
                    paned_window.add(self.left_frame)

                    self.tree = ttk.Treeview(self.left_frame, show="tree", selectmode="browse")
                    tree_y_scroll_bar = Scrollbar(self.left_frame, command=self.tree.yview, relief=SUNKEN, width=2)
                    tree_y_scroll_bar.pack(side=RIGHT, fill=Y)
                    self.tree.config(yscrollcommand=tree_y_scroll_bar.set)
                    self.tree.pack(expand=1, fill=BOTH)

                    # 右侧frame
                    right_frame = Frame(paned_window)
                    paned_window.add(right_frame)

                    # 右上角frame
                    right_top_frame = Frame(right_frame)
                    right_top_frame.pack(expand=1, fill=BOTH)

                    self.number_line = Text(right_top_frame, width=0, takefocus=0, border=0, font=(self.font_type, self.font),
                                            cursor="")
                    self.number_line.pack(side=LEFT, fill=Y)

                    # 右上角Text
                    text = Text(right_top_frame, font=(self.font_type, self.font), state=DISABLED, cursor="", wrap=NONE)
                    self.text_obj = text
                    text_x_scroll = Scrollbar(right_frame, command=text.xview, orient=HORIZONTAL)
                    text_y_scroll = Scrollbar(right_top_frame, command=text.yview)
                    self.text_scroll_obj = text_y_scroll
                    text.config(xscrollcommand=text_x_scroll.set, yscrollcommand=text_y_scroll.set)
                    text_y_scroll.pack(side=RIGHT, fill=Y)
                    text_x_scroll.pack(side=BOTTOM, fill=X)
                    text.pack(expand=1, fill=BOTH)

                    # 右下角frame
                    right_bottom_frame = Frame(right_frame)
                    right_bottom_frame.pack(side=BOTTOM, fill=X)

                    self.folder_img = PhotoImage(file=r"./image/folder.png")
                    self.file_img = PhotoImage(file=r"./image/text_file.png")

                    php_img = PhotoImage(file=r"./image/php.png")
                    python_img = PhotoImage(file=r"./image/python.png")
                    image_img = PhotoImage(file=r"./image/img.png")

                    # 设置文件图标
                    self.icon = {".php": php_img, ".py": python_img, ".pyc": python_img, ".png": image_img, ".jpg": image_img,
                                 ".jpeg": image_img, ".gif": image_img, ".ico": image_img}

                    # 加载目录文件
                    self.load_tree("", self.path)
                    self.tree.bind("<<TreeviewSelect>>", lambda event: self.select_tree())
                    text.bind("<MouseWheel>", lambda event: self.update_line())

                    self.number_line.bind("<FocusIn>", self.focus_in_event)
                    self.number_line.bind('<Button-1>', self.button_ignore)
                    self.number_line.bind('<Button-2>', self.button_ignore)
                    self.number_line.bind('<Button-3>', self.button_ignore)
                    self.number_line.bind('<B1-Motion>', self.button_ignore)
                    self.number_line.bind('<B2-Motion>', self.button_ignore)
                    self.number_line.bind('<B3-Motion>', self.button_ignore)

                    self.text_scroll_obj.bind('<B1-Motion>', lambda event: self.update_line())
                    self.text_obj.bind('<KeyRelease>', lambda event: self.update_line())

                    text.bind("<Control-Key-s>", lambda event: self.save_file())
                    text.bind("<Control-Key-S>", lambda event: self.save_file())
                    text.bind("<Control-Key-Z>", lambda event: self.toUndo())
                    text.bind("<Control-Key-Y>", lambda event: self.toRedo())

                    window.mainloop()

            class Application(Application_UI):
                def __init__(self):
                    Application_UI.__init__(self)

                ''' 保存文件'''

                def save_file(self):
                    # 判断是否是文件
                    path = self.path_var.get()
                    print(path)
                    if self.is_file(path) is True:
                        # 判断是否为图片
                        if self.is_type_in(path) is False:
                            content = self.text_obj.get(1.0, END)[:-1]
                            with open(path, "w", encoding="utf-8") as f:
                                f.write(content)
                            messagebox.showinfo("提示", "保存成功")
                        else:
                            messagebox.showwarning("提示", "不能保存图片")
                    else:
                        messagebox.showwarning("提示", "不能保存目录")

                ''' 设置默认搜索路径'''

                def open_dir(self):
                    path = filedialog.askdirectory(title=u"设置目录", initialdir=self.path)
                    print("设置路径：" + path)
                    self.path = path
                    # 删除所有目录
                    self.delete_tree()
                    self.load_tree("", self.path)

                ''' 判断是否为文件'''

                def is_file(self, path):
                    if os.path.isfile(path):
                        return True
                    return False

                ''' 判断是否是图片类型'''

                def is_type_in(self, path):
                    ext = self.file_extension(path)
                    if ext in self.file_types:
                        return True
                    return False

                ''' 删除树'''

                def delete_tree(self):
                    self.tree.delete(self.tree.get_children())

                def focus_in_event(self, event=None):
                    self.text_obj.focus_set()

                def button_ignore(self, ev=None):
                    return "break"

                ''' 加载目录'''

                def load_tree(self, root, path):
                    is_open = False
                    if root == "":
                        is_open = True

                    root = self.tree.insert(root, END, text=" " + self.dir_name(path), values=(path,), open=is_open,
                                            image=self.folder_img)

                    try:
                        for file in os.listdir(path):
                            file_path = path + "\\" + file
                            if os.path.isdir(file_path):
                                self.load_tree(root, file_path)
                            else:
                                ext = self.file_extension(file)
                                img = self.icon.get(ext)
                                if img is None:
                                    img = self.file_img
                                self.tree.insert(root, END, text=" " + file, values=(file_path,), image=img)
                    except Exception as e:
                        print(e)

                ''' 获取文件后缀'''

                def file_extension(self, file):
                    file_info = os.path.splitext(file)
                    return file_info[-1]

                ''' 获取目录名称'''

                def dir_name(self, path):
                    path_list = os.path.split(path)
                    return path_list[-1]

                ''' 更新行数'''

                def update_line(self):
                    if not self.scroll_visiblity:
                        return
                    self.number_line.delete(1.0, END)
                    text_h, text_l = map(int, str.split(self.text_obj.index(END), "."))
                    q = range(1, text_h)
                    r = map(lambda x: '%i' % x, q)
                    s = '\n'.join(r)
                    self.number_line.insert(END, s)

                    if text_h <= 100:
                        width = 2
                    elif text_h <= 1000:
                        width = 3
                    elif text_h <= 10000:
                        width = 4
                    else:
                        width = 5
                    self.number_line.configure(width=width)
                    self.number_line.yview_moveto(self.text_obj.yview()[0])

                ''' 选中item回调'''

                def select_tree(self):
                    for item in self.tree.selection():
                        item_text = self.tree.item(item, "values")
                        select_path = "\\".join(item_text)
                        self.path_var.set(select_path)

                        self.text_obj.config(state=NORMAL, cursor="xterm")
                        # 清空text内容
                        self.text_obj.delete(1.0, END)
                        self.update_line()
                        if self.is_file(select_path) is True:
                            if self.is_type_in(select_path) is True:
                                self.text_obj.config(state=DISABLED, cursor="")
                                self.look_image(select_path)
                            else:
                                try:
                                    self.open_file(select_path, "r", "utf-8")
                                    self.update_line()
                                except Exception as e:
                                    print(e)
                        else:
                            self.text_obj.config(state=DISABLED, cursor="")

                ''' 查看图片'''

                def look_image(self, select_path):
                    try:
                        image = Image.open(select_path)
                        self.look_photo = ImageTk.PhotoImage(image)
                        self.text_obj.image_create(END, image=self.look_photo)
                    except Exception as e:
                        print(e)

                ''' 打开文件写入内容'''

                def open_file(self, select_path, mode, encoding=None):
                    with open(select_path, mode=mode, encoding=encoding) as f:
                        self.text_obj.insert(1.0, f.read())

            if __name__ == "__main__":
                Application()
            # def fasdasdf():
            #     window1.destroy()
            #     fasdasdf1()
            # window1 = Tk() #建立窗口，把窗口储存在window中
            # window1.title("Lightning UI Setting") #设置标题
            # window1.geometry("400x300")
            # window1.iconbitmap("金星.ico")
            # def Check_state():
            #     wifi = Pywifi()
            #     iface = wifi.interfaces()[0]
            #     print(ifaces.status())
            #     if ifaces.status() == 4:
            #         print("此电脑已连接无线网络")
            # def shuangka():
            #     window2 = Tk() #建立窗口，把窗口储存在window中
            #     window2.title("Lightning Dual Card Settings") #设置标题
            #     window2.geometry("800x600")
            #     def dual5g():
            #         windowsx = Tk() #建立窗口，把窗口储存在window中
            #         windowsx.title("if you okay to open 5G") #设置标题
            #         windowsx.geometry("400x300")
            #         Label(windowsx,text = "你确定开启5G模式？这将使你的电脑内存占用变高").pack()
            #         def open5g():
            #             messagebox.showwarning("","你现在使用的是：5G/4G/3G/2G模式")
            #         def close5g():
            #             messagebox.showwarning("","你现在使用的是4G/3G/2G模式")
            #         Button(windowsx,text = "是，开启5G模式",command = open5g).pack()
            #         Button(windowsx,text = "否，停用5G，使用4G",command = close5g).pack()
            #     Label(window2,text = "星空系统采用移动网络系统，因此优势在于免费、快速，5G最快下载/上传速度为：148MB/S，4G为18.5MB/S。").pack()
            #     Button(window2,text = "1.5G/4G/3G/2G",command = dual5g).pack()
            #     def dual4g():
            #         messagebox.showwarning("","你现在使用的是4G/3G/2G模式")
            #     Button(window2,text = "2.4G/3G/2G",command = dual4g).pack()
            #     def dual3g():
            #         messagebox.showwarning("","你现在使用的是3G/2G模式")
            #     Button(window2,text = "3.3G/2G",command = dual3g).pack()
            #     def dual2g():
            #         messagebox.showwarning("","你现在使用的是仅2G模式")
            #     Button(window2,text = "4.仅2G",command = dual2g).pack()
            #     def dual0g():
            #         messagebox.showwarning("","你已关闭移动数据网络")
            #     Button(window2,text = "5.关闭移动数据网络",command = dual0g).pack()
            # def button_is_clicked():
            #     print("")
            # def disk():
            #     window4 = Tk() #建立窗口，把窗口储存在window中
            #     window4.title("Lightning Disk Management") #设置标题
            #     window4.geometry("700x300")
            #     import ctypes
            #     import os
            #     import platform
            #     import sys
            #     def get_free_space_mb(folder):
            #         """ Return folder/drive free space (in bytes)
            #         """
            #         if platform.system() == 'Windows':
            #             free_bytes = ctypes.c_ulonglong(0)
            #             ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(folder), None, None, ctypes.pointer(free_bytes))
            #             return free_bytes.value/1024/1024/1024 
            #         else:
            #             st = os.statvfs(folder)
            #             return st.f_bavail * st.f_frsize/1024/1024
            #     Label(window4,text = "计算机C标号磁盘剩余可使用空间" + str(get_free_space_mb('C:\\')) + 'GB').pack()
            #     Label(window4,text = "计算机D标号磁盘剩余可使用空间" + str(get_free_space_mb('D:\\')) + 'GB').pack()
            #     Label(window4,text = "计算机E标号磁盘剩余可使用空间(如果你没有该标号磁盘，请忽略)" + str(get_free_space_mb('E:\\')) + 'GB').pack()
            #     Label(window4,text = "计算机F标号磁盘剩余可使用空间(如果你没有该标号磁盘，请忽略)" + str(get_free_space_mb('F:\\')) + 'GB').pack()
            #     Label(window4,text = "计算机G标号磁盘剩余可使用空间(如果你没有该标号磁盘，请忽略)" + str(get_free_space_mb('G:\\')) + 'GB').pack()
            # def momery():
            #     window3 = Tk() #建立窗口，把窗口储存在window中
            #     window3.title("Lightning Detect Memory") #设置标题
            #     window3.geometry("700x300")
            #     import psutil
            #     mem = psutil.virtual_memory()
            #     zj = float(mem.total/1024/1024/1024)
            #     Label(window3,text = "此计算机所有内存空间：" + str(zj) + "GB").pack()
            #     ysy = float(mem.used/1024/1024/1024)
            #     Label(window3,text = "此计算机已使用内存空间：" + str(ysy) + "GB").pack()
            #     kx = float(mem.free/1024/1024/1024)
            #     Label(window3,text = "此计算机剩余可使用内存空间:" + str(kx) + "GB").pack()
            # def system():
            #     window888 = Tk() #建立窗口，把窗口储存在window中
            #     window888.title("Night Star System") #设置标题
            #     window888.geometry("1070x606")
            #     import platform
            #     import wmi
            #     import psutil
            #     Label(window888,text = "Lightning UI").pack()
            #     Label(window888,text = "设备规格").pack()
            #     cpuinfo = wmi.WMI()
            #     for cpu in cpuinfo.Win32_Processor(): 
            #         Label(window888,text = "处理器：" + cpu.Name).pack()
            #     mem = psutil.virtual_memory()
            #     zj = float(mem.total)
            #     Label(window888,text = "机带RAM：" + str(zj / 1024 / 1024 /1024) + " GB").pack()
            #     Label(window888,text = "设备ID：16ASDG59-AF4W-ASGF-1F2D-A4EW69GRW3E5")
            #     Label(window888,text = "产品ID：00916-49852-94836-AG156")
            #     import os
            #     prg = 'C:Program Files(x86)'
            #     if True == os.path.exists( prg ):
            #         Label(window888,text = "系统类型：32位操作系统，基于x86的处理器").pack()
            #     else:
            #         Label(window888,text = "系统类型：64位操作系统，基于x64的处理器").pack()
            #     Label(window888,text = "笔和触控：没有可用于此显示器的笔或触控").pack()
            #     Label(window888,text = "Lightning UI 规格").pack()
            #     Label(window888,text = "版本：Lightning UI 1.1 测试版").pack()
            #     Label(window888,text = "版本号：1002").pack()
            #     Label(window888,text = "安装日期：" + strftime("%Y/%m/%d %H:%M:%S")).pack()
            #     Label(window888,text = "操作系统版本：10325.9582").pack()
            #     Label(window888,text = "体验：Lightning UI Feature Experience Pack 165.1563.18.6980").pack()
            # Button(window1,text = "1.WLAN(要使用，请下载pywifi库，该库可能仅在笔记本电脑上可用)",command = Check_state).pack()
            # Button(window1,text = "2.双卡和移动网络(不能设置双卡)",command = shuangka).pack()
            # Button(window1,text = "3.蓝牙(暂时不可用)",command = button_is_clicked).pack()
            # Button(window1,text = "4.飞行模式(暂时不可用)",command = button_is_clicked).pack()
            # Button(window1,text = "5.计算机磁盘剩余存储空间",command = disk).pack()
            # Button(window1,text = "6.计算机内存使用情况",command = momery).pack()
            # Button(window1,text = "7.关于 Lightning UI",command = system).pack()
            # window1.protocol("WM_DELETE_WINDOW",fasdasdf)
            # window1.mainloop()
        except:
            messagebox.showinfo("提示","该功能维护中，暂未开放")
            fasdasdf1()
    elif dakai == "chrome":
        

        def download(url):
            # 请求地址
            url = 'https://baike.baidu.com/item/' + urllib.parse.quote(url)
            # 请求头部
            headers = { 
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36' 
            }
            # 利用请求地址和请求头部构造请求对象
            req = urllib.request.Request(url=url, headers=headers, method='GET')
            # 发送请求，获得响应
            response = urllib.request.urlopen(req)
            # 读取响应，获得文本
            text = response.read().decode('utf-8')
            # 构造 _Element 对象
            html = etree.HTML(text)
            # 使用 xpath 匹配数据，得到匹配字符串列表
            sen_list = html.xpath('//div[contains(@class,"lemma-summary") or contains(@class,"lemmaWgt-lemmaSummary")]//text()') 
            # 过滤数据，去掉空白
            sen_list_after_filter = [item.strip('\n') for item in sen_list]
            # 将字符串列表连成字符串并返回
            return ''.join(sen_list_after_filter)
        def get_data(html):
            regex = re.compile('<meta name="description" content="(.*?)">')
            regex = re.compile('<div class="lemma-summary" label-module="lemmaSummary">(\s*)<div class="para" label-module="para">([\s\S]*?)</div>(\s*)</div>')
            data = [('\n', 'Python是一种计算机程序设计语言。是一种动态的、面向对象的脚本语言，最初被设计用于编写自动化脚本(shell)，随着版本的不断更新和语言新功能的添加，越来越多被用于独立的、大型项目的开发。', '\n')]
            data = re.findall(regex, html)[0][1]
            return data
        curr_time = datetime.now()
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        def x(a):
            d = {
            0 : '-星期一',
            1 : '-星期二',
            2 : '-星期三',
            3 : '-星期四',
            4 : '-星期五',
            5 : '-星期六',
            6 : '-星期天',
            }
            day = a.weekday()
            return d[day]
        xxx=x(datetime.now())
        ttt=curr_time.strftime("%Y-%m-%d")
        rrr='日期:'+ttt+xxx
        def main(a):
            class MyBrowser(wx.Dialog):
                def __init__(self, *args, **kwds):
                    wx.Dialog.__init__(self, *args, **kwds)
                    sizer = wx.BoxSizer(wx.VERTICAL)
                    self.browser = wx.html2.WebView.New(self)
                    sizer.Add(self.browser, 1, wx.EXPAND, 10)
                    self.SetSizer(sizer)
                    self.SetSize((1500, 1500))
            app = wx.App()
            dialog = MyBrowser(None, -1)
            dialog.browser.LoadURL(a) #加载页面。如果是加载html字符串应该使用  dialog.browser.SetPage(html_string,"")
            dialog.Show()
            app.MainLoop()
        class MyFrame(wx.Frame):
            def __init__(self, parent, id):
                wx.Frame.__init__(self, parent, id, '银河浏览器', size=(1100, 600),name='银河浏览器')
                panel = wx.Panel(self)
                self.SetBackgroundColour("#00BFFF") 
                self.bt_confirm = wx.Button(panel, label='访问网站')
                self.bt_confirm.Bind(wx.EVT_BUTTON,self.OnclickSubmit)
                self.bt_km = wx.Button(panel, label='银河搜索')
                self.bt_km.Bind(wx.EVT_BUTTON,self.km)
                self.bt_baidu = wx.Button(panel, label='百度搜索')
                self.bt_baidu.Bind(wx.EVT_BUTTON,self.baidu)
                self.bt_bdbk = wx.Button(panel, label='百度百科')
                self.bt_bdbk.Bind(wx.EVT_BUTTON,self.bdbk)
                self.bt_bing= wx.Button(panel, label='必应搜索')
                self.bt_bing.Bind(wx.EVT_BUTTON,self.bing)
                self.bt_s= wx.Button(panel, label='360搜索')
                self.bt_s.Bind(wx.EVT_BUTTON,self.s)
                self.bt_sougou= wx.Button(panel, label='搜狗搜索')
                self.bt_sougou.Bind(wx.EVT_BUTTON,self.sougou)
                self.bt_cancel = wx.Button(panel, label='清除内容')
                self.bt_cancel.Bind(wx.EVT_BUTTON,self.OnclickCancel)
                self.bt_gx= wx.Button(panel, label='查看更新')
                self.bt_gx.Bind(wx.EVT_BUTTON,self.gx)
                self.x= wx.StaticText(panel, label='银河浏览器')
                font = wx.Font(20, wx.DEFAULT, wx.FONTSTYLE_NORMAL, wx.NORMAL)
                self.x.SetFont(font)
                self.bq=wx.StaticText(panel, label='© 2021 吴宇航 版权所有')
                self.lzx=wx.StaticText(panel, label=rrr)
                self.title = wx.StaticText(panel, label="输入网址或搜索内容")
                self.text_user = wx.TextCtrl(panel, style=wx.TE_LEFT)
                hsizer_user = wx.BoxSizer(wx.HORIZONTAL)
                hsizer_user.Add(self.text_user, proportion=1, flag=wx.ALL, border=5)
                hsizer_pwd = wx.BoxSizer(wx.HORIZONTAL)
                hsizer_button = wx.BoxSizer(wx.HORIZONTAL)
                hsizer_button.Add(self.bt_confirm, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_km, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_baidu, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_bdbk, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_bing, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_s, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_sougou, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_cancel, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                hsizer_button.Add(self.bt_gx, proportion=1, flag=wx.ALIGN_CENTER | wx.LEFT, border=10)
                vsizer_all = wx.BoxSizer(wx.VERTICAL)
                vsizer_all.Add(self.x, proportion=0, flag=wx.BOTTOM | wx.TOP | wx.ALIGN_CENTER,
                                border=15)
                vsizer_all.Add(self.title, proportion=0, flag=wx.BOTTOM | wx.TOP | wx.ALIGN_CENTER,
                                border=15)
                vsizer_all.Add(hsizer_user, proportion=0, flag=wx.EXPAND | wx.LEFT | wx.RIGHT, border=45)
                vsizer_all.Add(hsizer_pwd, proportion=0, flag=wx.EXPAND | wx.LEFT | wx.RIGHT, border=45)
                vsizer_all.Add(hsizer_button, proportion=0, flag=wx.ALIGN_CENTER | wx.TOP, border=15)
                hsizer_pwd = wx.BoxSizer(wx.HORIZONTAL)
                hsizer_button = wx.BoxSizer(wx.HORIZONTAL)
                vsizer_all.Add(self.bq, proportion=0, flag= wx.TOP | wx.ALIGN_CENTER,
                                border=350)
                panel.SetSizer(vsizer_all)
            def OnclickSubmit(self,event):
                message = ""
                username = self.text_user.GetValue()  
                if username == "":
                    message = '检测到网址空白'
                    wx.MessageBox(message)
                else:
                    main(username)
            def OnclickCancel(self,event):
                self.text_user.SetValue("") 
            def baidu(self,event):
                message = ""
                username = self.text_user.GetValue()
                if username == "":
                    message = '检测到内容空白'
                    wx.MessageBox(message)
                else:
                    x='https://www.baidu.com/s?ie=UTF-8&wd='+username
                    main(x)
            def gx(self,event):
                message = """版本:终结版
                更新:哎，我不说，我就是玩儿
                """
                wx.MessageBox(message)
            def bing(self,event):
                message = ""
                username = self.text_user.GetValue()
                if username == "":
                    message = '检测到内容空白'
                    wx.MessageBox(message)
                else:
                    x='https://cn.bing.com/search?q='+username
                    main(x)
            def s(self,event):
                message = ""
                username = self.text_user.GetValue()
                if username == "":
                    message = '检测到内容空白'
                    wx.MessageBox(message)
                else:
                    x='https://www.so.com/s?ie=utf-8&fr=none&src=360sou_newhome&q='+username
                    main(x)
            def sougou(self,event):
                message = ""
                username = self.text_user.GetValue()
                if username == "":
                    message = '检测到内容空白'
                    wx.MessageBox(message)
                else:
                    x='https://www.sogou.com/web?query='+username
                    main(x)
            def bdbk(self,event):
                message = ""
                username = self.text_user.GetValue()
                if username == "":
                    message = '检测到内容空白'
                else:
                    a=username
                    message = download(a)
                    # url = 'http://baike.baidu.com/item/{}'.format(a)
                    # html_cont = download(url)
                    # try:
                    #     data = get_data(html_cont)
                    #     data = re.sub(r'<([\s\S]*?)>|&nbsp;|\n','',data)
                    #     with open(a+'.txt', 'w', encoding='utf-8') as f:
                    #         f.write(data)
                    #         f.close()
                    # except:
                    #     data='没有这个词'
                    # message=data
                wx.MessageBox(message)
            def km(self,event):
                message = ""
                username = self.text_user.GetValue()
                if username == "":
                    message = '检测到内容空白'
                else:
                    a=username
                    if a =="飞机":
                        b='''
                        搜索：飞机
                        ┌──────────┐
                        │----------│
                        │   飞机   │
                        │----------│
                        └──────────┘
                        
                        飞机（aeroplane,airplane）是指具有一具或多具发动机的动力装置产生前进的推力或拉力，由机身的固定机翼产生升力，在大气层内飞行的重于空气的航空器。  飞机是20世纪初最重大的发明之一，公认由美国人莱特兄弟发明。他们在1903年12月17日进行的飞行作为“第一次重于空气的航空器进行的受控的持续动力飞行”被国际航空联合会（FAI）所认可，同年他们创办了“莱特飞机公司”。自从飞机发明以后，飞机日益成为现代文明不可缺少的工具。它深刻的改变和影响了人们的生活，开启了人们征服蓝天历史。 
                        '''
                    elif a == "C++" or a == "c++":
                        b='''
                        搜索：C++
                        ┌──────────┐  
                        │----------│  
                        │   C++    │  编程语言?
                        │----------│
                        └──────────┘  
                        C++是一种面向对象的计算机程序设计语言，由美国AT&T贝尔实验室的本贾尼·斯特劳斯特卢普博士发明并实现（最初这种语言被称作“C with Classes”带类的C）。
                        它是一种静态数据类型检查的、支持多重编程范式的通用程序设计语言。它支持过程化程序设计、数据抽象、面向对象程序设计、泛型程序设计等多种程序设计风格。\nC++是C语言的继承，进一步扩充和完善了C语言，成为一种面向对象的程序设计语言。C++这个词在中国大陆的程序员圈子中通常被读做“C++”，而西方的程序员通常读做“C plus plus”，“CPP”。
                        '''
                    elif a == "857" or  a == "八五七":
                        b='''
                        搜索：857
                        ┌──────────┐
                        │----------│
                        │    857   │     网络流行语
                        │----------│
                        └──────────┘    
                        857，网络流行语，指蹦迪神曲《bow chi bow》和《feel my bass》副歌里面的空耳，现已发展成蹦迪的代名词。
                        '''
                    elif a == "baidu" or a == "百度":
                        b='''
                        搜索：百度/baidu
                        ┌──────────┐
                        │----------│ 
                        │   百度   │? 全球最大的中文搜索引擎、最大的中文网站
                        │----------│
                        └──────────┘
                        百度，全球最大的中文搜索引擎、最大的中文网站。百度二字，来自于八百年前南宋词人辛弃疾的一句词：众里寻他千百度。这句话描述了词人对理想的执着追求。1999年底，身在美国硅谷的李彦宏看到了中国互联网及中文搜索引擎服务的巨大发展潜力，抱着技术改变世界的梦想，他毅然辞掉硅谷的高薪工作，携搜索引擎专利技术，于 2000年1月1日在中关村创建了百度公司。
                        '''
                    elif a == "易语言" or a == "EPL" or a == "erl" or a == "Erl":
                        b='''
                        搜索：易语言
                        ┌──────────┐
                        │----------│
                        │  易语言  │     专为中国人设置的简单编程语言")
                        │----------│
                        └──────────┘  
                        易语言（EPL）是一门以中文作为程序代码编程语言，其以“易”著称，创始人为吴涛。易语言早期版本的名字为E语言。其最早的版本的发布可追溯至2000年9月11日。创造易语言的初衷是进行用中文来编写程序的实践，方便中国人以中国人的思维编写程序，并不用再去学习西方思维。易语言的诞生极大的降低了编程的门槛和学习的难度。从2000年以来，易语言已经发展到一定的规模，功能上、用户数量上都十分可观。
                        '''
                    
                    
                    elif a == "CEO" or a == "ceo":
                        b='''
                        搜索：CEO
                        ┌───────────┐
                        │-----------│
                        │    CEO    │  Chief Executive Officer
                        │-----------│
                        └───────────┘   
                        首席执行官（Chief Executive Officer)职位名称，是在一个企业中负责日常事务的最高行政官员，主司企业行政事务，故又称作司政、行政总裁、总经理或最高执行长。在政治组织机构中，首席执行官为政府首脑，相当于部长会议主席、总理、首相、阁揆、行政院院长、政府主席等级别的行政事务最高负责高官。
                        '''
                    elif a == "钉钉":
                        b='''
                        搜索：钉钉
                        ┌──────────┐
                        │----------│
                        │   钉钉   │  专为中国企业打造的免费沟通和协同的多端平台
                        │----------│
                        └──────────┘   
                        钉钉（DingTalk）是阿里巴巴集团专为中国企业打造的免费沟通和协同的多端平台 [1]  ，提供PC版，Web版，Mac版和手机版，支持手机和电脑间文件互传。
                        '''
                    elif a == "乔布斯" or a == "史蒂夫·乔布斯" or a == "史蒂夫乔布斯 ":
                        b='''
                        搜索：史蒂夫·乔布斯
                        ┌─────────────┐
                        │-------------│
                        │史蒂夫·乔布斯│ 美国发明家、企业家、美国苹果公司联合创始人
                        │-------------│
                        └─────────────┘   
                        史蒂夫·乔布斯  （Steve Jobs，1955年2月24日—2011年10月5日   ），出生于美国加利福尼亚州旧金山，美国发明家、企业家、美国苹果公司联合创始人。 
                        乔布斯被认为是计算机业界与娱乐业界的标志性人物，他经历了苹果公司几十年的起落与兴衰，先后领导和推出了麦金塔计算机（Macintosh）、iMac、iPod、iPhone、iPad等风靡全球的电子产品，深刻地改变了现代通讯、娱乐、生活方式。乔布斯同时也是前Pixar动画公司的董事长及行政总裁。
                        '''
                    elif a == "比尔盖茨" or a == "比尔" or a == "盖茨" or a == "Bill Gates" or a == "bill gates" or a == "Bill gates" or a == "billgates" or a == "BillGates" or a == "Billgates":
                        b='''
                        搜索：比尔盖茨
                        ┌─────────────┐
                        │-------------│
                        │  比尔·盖茨  │ 比尔·盖茨 [1]  （Bill Gates），全名威廉·亨利·盖茨三世，简称比尔或盖茨
                        │-------------│
                        └─────────────┘
                        比尔·盖茨 [1]  （Bill Gates），全名威廉·亨利·盖茨三世，简称比尔或盖茨。1955年10月28日出生于美国华盛顿州西雅图，企业家、软件工程师、慈善家、微软公司创始人。曾任微软董事长、CEO和首席软件设计师。
                        '''
                    
                    
                    
                    
                    
                    
                    elif a == "Windows" or a == "windows":
                        b='''
                        搜索：Windows
                        ┌───────────┐
                        │-----------│
                        │  Windows  │   Microsoft Windows操作系统/美国微软公司研发的一套操作系统
                        │-----------│
                        └───────────┘  
                        MicrosoftWindows操作系统是美国微软公司研发的一套操作系统，它问世于1985年，起初仅仅是Microsoft-DOS模拟环境，后续的系统版本由于微软不断的更新升级，不但易用，也当前应用最广泛的操作系统。 [1] Windows采用了图形化模式GUI，比起从前的Dos需要输入指令使用的方式，更为人性化。随着计算机硬件和软件的不断升级，微软的 Windows也在不断升级，从架构的16位、32位再到64位,系统版本从最初的 Windows1.0到大家熟知的 Windows95、 Windows98、 Windows2000、 Windows XP、 Windows Vista、 Windows7、Windows8、Windows8.1、Windows 10和Windows Server服务器企业级操作系统，微软一直在致力于Windows操作系统的开发和完善。 [1]
                        '''
                    elif a == "编程" or a == "biancheng":
                        b='''
                        搜索：编程
                        ┌──────────┐  
                        │----------│  
                        │   编程   │  编程
                        │----------│  
                        └──────────┘  
                        编程（biān chéng）是编定程序的中文简称，就是让计算机代为解决某个问题，对某个计算体系规定一定的运算方式，使计算体系按照该计算方式运行，并最终得到相应结果的过程。
                        '''
                    elif a == "猿辅导":
                        b='''
                        搜索：猿辅导
                        ┌──────────┐
                        │----------│
                        │  猿辅导  │
                        │----------│
                        └──────────┘
                        截至2020年1月，猿辅导在线教育全国累计用户数突破4亿。(还不是被疫情逼的）) [1] 公司旗下拥有猿辅导、小猿搜题、猿题库、小猿口算、斑马AI课等多款在线教育产品。 [2-3] 猿辅导提供中小学全学科的课程，全国任何地区的中小学生，都可在家上名师直播课 [4]  。2019年6月11日，猿辅导入选“2019福布斯中国最具创新力企业榜”。 [5-6] 2019年12月16日，猿辅导、小猿搜题、猿题库、小猿口算、斑马英语列入第一批教育App备案名单。 [7] 猿辅导创立于2012年 [2]  ，顺利完成由IDG资本、高瓴资本、博裕资本、华平投资、腾讯等知名基金、巨头公司领投的多轮融资，估值超过78亿美元。 [8]  是K-12（覆盖学前到12年义务教育）在线教育首个独角兽公司 [9]  ，“2019胡润品牌榜-最具价值中国品牌”。
                        '''
                    elif a == "月高工作室":
                        b='''
                        搜索：月高工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        月高工作室于2019年11月23日由创始人潘夕习成立，目前具有代表作《跳舞的线》。
                        '''
                    elif a == "oppo" or a == "OPPO" or a == "Oppo":
                        b='''
                        搜索：OPPO
                        ┌──────────┐
                        │----------│
                        │   OPPO   │        开启探索和引领至美科技之旅
                        │----------│
                        └──────────┘
                        OPPO于2008年推出第一款“笑脸手机”，由此开启探索和引领至美科技之旅。今天，OPPO凭借以Find和R系列手机为核心的智能终端产品，以及OPPO+等互联网服务，让全球消费者尽享至美科技。
                        '''
                    elif a == "安卓" or a == "Android" or a == "android" or a == "anzhuo":
                        b='''
                        搜索：安卓
                        ┌──────────┐
                        │----------│
                        │   安卓   │         自由及开放源代码的操作系统
                        │----------│
                        └──────────┘
                        安卓是一种基于Linux内核（不包含GNU组件）的自由及开放源代码的操作系统。主要使用于移动设备，如智能手机和平板电脑，由美国Google公司和开放手机联盟领导及开发。Android操作系统最初由Andy Rubin开发，主要支持手机。
                        '''
                    elif a == "致所有人":
                        b='''
                        我不知道是谁引起的这个抄袭之风，连有些工作室都开始抄袭了，希望大家多多举报那些抄袭的作品，抄袭出来的毕竟不是自己的，自己做出来的作品会让你感到有所成就，而其他抄袭的作品会找到所有人的唾弃，希望那些抄袭的人不要再继续抄下去了，抄袭有意思吗》？
                        我想有些不要脸的人应该会说“有”，因为他们就知道抄！啊哈哈，抄袭只会害了自己，不会害了其他人，只会害了抄袭的自己呀！哎，还请抄袭的人不要再这样下去了
                        ！@闪翼抄袭室，请你们不要再抄袭了！请马上撤回抄袭作品！谢谢配合！
                        '''
                    elif a == "星光工作室" or a == "星光":
                        b='''
                        搜索：星光工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        关于 Star light （S.L.）星光工作室2020年2月28日以学而思编程为启动平台创立，主要建立教学部、科技研发部，以作品优秀著称,欢迎大家加入。
                        优秀的作品全学而思公认最水的工作室(滑稽)，作品涉及爬虫、pygame、tkinter和python终端输出。不断创新创新永远是我们的口号，探索探索再探索，学习学习再学习！技术党拥有涉及许多方面的技术人才，打造良好的学习环境。Idea创意使我们不甘平庸，创意使我们继续向前！
                        '''
                    elif a == "人类" or a == "renlei":
                        b='''
                        搜索：人类
                        ┌──────────┐
                        │----------│
                        │   人类   │   高智商生物
                        │----------│
                        └──────────┘
                        智人（学名：Homo sapiens），是人属下的唯一现存物种。形态特征比直立人更为进步。分为早期智人和晚期智人。
                        早期智人过去曾叫古人，生活在距今25万～4万年前，主要特征是脑容量大，在1300毫升以上；眉嵴发达，前额较倾斜，枕部突出，鼻部宽扁，颌部前突。一般认为是由直立人进化来的，但有争议 [1]  认为直立人在后来崛起的智人（现代人）走出非洲后灭绝或在此之前就灭绝了。
                        晚期智人（新人）是解剖结构上的现代人。大约从距今四五万年前开始出现。两者形态上的主要差别在于前部牙齿和面部减小，眉嵴减弱，颅高增大，到现代人则更加明显。晚期智人臂不过膝，体毛退化，有语言和劳动，有社会性和阶级性。有三种类型的材料来研究人从哪里来这个问题：基因、化石、语言文化。其中语言文化一般不能超过新石器时代。很多形态特征并不与种系差异相关。
                        ''' 
                    elif a == "霍格沃兹工作室":
                        b='''
                        搜索：霍格沃兹工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        霍格沃茨工作室在2020年3月9日成立，室长是陈张远致，随后，大批优秀成员进入。我们的精选作品：分院仪式，作者方政：https://code.xueersi.com/home/project/detail?lang=code&pid=4761562&version=python&form=python&langType=python密室大逃脱，作者茜烨：https://code.xueersi.com/home/project/detail?lang=code&pid=4887936&version=cpp&form=cpp&langType=cpp最强大脑特约版，作者李承骏、方政&金恺文（荐）：https://code.xueersi.com/home/project/detail?lang=code&pid=4982950&version=python&form=python&langType=python想要霍格沃茨四大学院的标志吗，作者陈张远致：https://code.xueersi.com/home/project/detail?lang=scratch&pid=5204731&version=3.0&langType=scratch更多优秀作品在我们的优秀作品大全！！（走过路过不要错过）里面
                        '''
                    elif a== "火焰工作室":
                        b='''
                        搜索：火焰工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        火焰工作室成立于2019-08-18日,是社区中较早的优秀的工作室,主攻python,以终端输出的美观与科技感而出名,目前最高观看8949点赞509,是值得认可的工作室!
                        '''
                    elif a == "浏览器" or a == "liulanqi":
                        b='''
                        搜索：浏览器
                        ┌──────────┐
                        │----------│
                        │  浏览器  │
                        │----------│
                        └──────────┘
                        浏览器是用来显示在万维网或局域网等内的文字、图像及其他信息的软件，它还可以让用户与这些文件进行交互操作。浏览器是电脑上网时经常使用到的应用软件，浏览器正是Internet时代的产物，随着电脑操作系统的普及、Internet的全球连接及人们对信息需求的爆炸式增长，为浏览器的诞生和兴起提供了强大的动力，同时它也标志着互联网时代的来临 [1]
                        '''
                    elif a == "诺耀工作室":
                        b='''
                        搜索：诺耀工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        诺耀工作室创建于2020年3月13日，由创始人李佳诺所建。2020年3月17日开始有了自己的官网：http://nuoyaogzsguanfang.cn，在短期内有了许多的成就。也在2020年4月16日创建了“诺耀工作室”的微信公众号。目前在学而思，网易卡塔，小码王等社区内总共作品超过60个！！！
                        '''
                    elif a == "梦想之星工作室":
                        b='''
                        搜索：梦想之星工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        相当于半个漫威，因为漫威的三大副室长全在这里，这里的人都是大佬，技术很NB
                        '''
                    elif a == "星斩工作室":
                        b='''
                        搜索：星斩工作室
                        ┌────────────┐
                        │------------│
                        │工作室许可证│
                        │------------│
                        └────────────┘
                        星斩工作室成立于2020.1.30。拥有成员20+，许多语言的程序员。官方网站：www.starcutc.com。官方邮箱：starcutcn@163.com、starcut@starcutc.com。在学而思、编程猫、卡搭社区都有人员。
                        '''
                    elif a == "张奥程"or a == "zac":
                        b="张奥程，男，原漫威副室长，原梦想之星副室长，会html，css，js，ddos，cc，bat，vbs，e，py，c++，sc，很牛逼的一个人"
                    elif a == "新型冠状病毒"or a == "新冠肺炎"or a == "新冠":
                        b="2019新型冠状病毒，2020年1月12日被世界卫生组织命名为2019-nCoV [1]  ，2020年2月11日被国际病毒分类委员会命名为SARS-CoV-2 [2]  。冠状病毒是一个大型病毒家族，已知可引起感冒以及中东呼吸综合征（MERS）和严重急性呼吸综合征（SARS）等较严重疾病。新型冠状病毒是以前从未在人体中发现的冠状病毒新毒株。"
                    elif a == "scratch" or a == "Scratch" :
                        b="Scratch是一款由麻省理工学院(MIT) 设计开发的少儿编程工具。其特点是:使用者可以不认识英文单词，也可以不会使用键盘。构成程序的命令和参数通过积木形状的模块来实现。用鼠标拖动模块到程序编辑栏就可以了。右边的部分是编辑好的程序代码，中间是可以用来选择的功能模块，左边上部是程序预览和运行窗口，左边下部是角色窗口。"
                    elif a == "thinkpad" or a == "Thinkpad" or a == "思考本":
                        b="ThinkPad（思考本）是IBM PC事业部旗下创立的便携式计算机品牌，凭借坚固和可靠的特性在业界享有很高声誉。2005年被联想（Lenovo）收购，ThinkPad商标为联想所有。ThinkPad自问世以来一直保持着黑色的经典外观并对技术有着自己独到的见解，如：TrackPoint（指点杆，俗称小红帽）、ThinkLight键盘灯、全尺寸键盘和APS（Active Protection System，主动保护系统）。"
                    elif a == "Python" or a == "python":
                        b="Python是一种计算机程序设计语言。是一种面向对象的动态类型语言，最初被设计用于编写自动化脚本(shell)，随着版本的不断更新和语言新功能的添加，越来越多被用于独立的、大型项目的开发。"
                    elif a == "css" or a == "CSS":
                        b="层叠样式表(英文全称：Cascading Style Sheets)是一种用来表现HTML（标准通用标记语言的一个应用）或XML（标准通用标记语言的一个子集）等文件样式的计算机语言。CSS不仅可以静态地修饰网页，还可以配合各种脚本语言动态地对网页各元素进行格式化。 CSS 能够对网页中元素位置的排版进行像素级精确控制，支持几乎所有的字体字号样式，拥有对网页对象和模型样式编辑的能力。"
                    elif a == "HTML" or a == "html"or a == "Html":
                        b="HTML（超文本标记语言）是用于在Internet上显示Web页面的主要标记语言。网页由HTML组成，用于通过Web浏览器显示文本，图像或其他资源。HTML文件的文件扩展名为.htm或.html。"
                    elif a == "PHP" or a == "Php" or a == "php":
                        b="PHP是PHP的递归首字母缩写：Hypertext Preprocessor，一种用于创建动态和交互式HTML网页的脚本语言。当网站访问者打开页面时，服务器处理PHP命令，然后将结果发送到访问者的浏览器。"
                    elif a == "RCD" or a == "rcd":
                        b("RCD（room temperature catalytic decomposition，室温催化分解），在室温条件下利用空气中的热量长期稳定的将空气中甲醛污染物催化氧化成水和二氧化碳。") 
                        sleep(3)
                        system("clear")
                    elif a == "JavaScript" or a == "js" or a=="javascript" or a=="JS" or a=="Script" or a=="script":
                        b="JavaScript（简称“JS”） 是一种具有函数优先的轻量级，解释型或即时编译型的编程语言。虽然它是作为开发Web页面的脚本语言而出名的，但是它也被用到了很多非浏览器环境中，JavaScript 基于原型编程、多范式的动态脚本语言，并且支持面向对象、命令式和声明式（如函数式编程）风格。 [1] JavaScript在1995年由Netscape公司的Brendan Eich，在网景导航者浏览器上首次设计实现而成。因为Netscape与Sun合作，Netscape管理层希望它外观看起来像Java，因此取名为JavaScript。但实际上它的语法风格与Self及Scheme较为接近。 [2] JavaScript的标准是ECMAScript 。截至 2012 年，所有浏览器都完整的支持ECMAScript 5.1，旧版本的浏览器至少支持ECMAScript 3 标准。2015年6月17日，ECMA国际组织发布了ECMAScript 的第六版，该版本正式名称为 ECMAScript 2015，但通常被称为ECMAScript 6 或者ES6。"
                    elif a == "华为" or a == "HUAWEI" or a == "huawei":
                        b='''
                        华为技术有限公司
                        华为消费者业务产品全面覆盖手机、移动宽带终端、终端云等，凭借自身的全球化网络优势、全球化运营能力，致力于将最新的科技带给消费者，让世界各地享受到技术进步的喜悦，以行践言，实现梦想。
                        '''
                    elif a == "apple" or a == "Apple":
                        b='''
                        中文意思：苹果
                        苹果公司（Apple Inc. ）是美国一家高科技公司。由史蒂夫·乔布斯、斯蒂夫·沃兹尼亚克和罗·韦恩(Ron Wayne)等人于1976年4月1日创立，并命名为美国苹果电脑公司（Apple Computer Inc. ），2007年1月9日更名为苹果公司，总部位于加利福尼亚州的库比蒂诺。
                        苹果公司1980年12月12日公开招股上市，2012年创下6235亿美元的市值记录，截至2014年6月，苹果公司已经连续三年成为全球市值最大公司。苹果公司在2016年世界500强排行榜中排名第9名。   2013年9月30日，在宏盟集团的“全球最佳品牌”报告中，苹果公司超过可口可乐成为世界最有价值品牌。2014年，苹果品牌超越谷歌（Google），成为世界最具价值品牌。
                        2016年9月8日凌晨1点，2016苹果秋季新品发布会在美国旧金山的比尔·格雷厄姆市政礼堂举行 [2]  。10月，苹果成为2016年全球100大最有价值品牌第一名。
                        2017年1月6日早晨8点整，“红色星期五”促销活动在苹果官网正式上线，瞬间大量用户涌入官网进行抢购，仅两分钟所有参与活动的耳机便被抢光；2月，Brand Finance发布2017年度全球500强品牌榜单，苹果排名第二； [3]  6月7日，2017年《财富》美国500强排行榜发布，苹果排名第3位； [4]  7月20日，2017年世界500强排名第9位。  
                        2018年12月18日，世界品牌实验室编制的《2018世界品牌500强》揭晓，苹果排名第3位。 2018年8月2日晚间，苹果盘中市值首次超过1万亿美元，股价刷新历史最高位至203.57美元。   入选2019《财富》世界500强、 2019福布斯全球数字经济100强榜第1位 
                        '''
                    elif a == "秦浩铭" or a == "漫威室长" or a == "原漫威室长":
                        b="漫威原室长，本作品的词库提供方之一，创造了很多奇迹。"
                    elif  a == "微软" or a == "微软公司" or a == "Microsoft":
                        b='''
                        微软  （英文名称：Microsoft；中文名称：微软公司或美国微软公司）始建于1975年，是一家美国跨国科技公司，也是世界PC（Personal Computer，个人计算机）软件开发的先导，由比尔·盖茨与保罗·艾伦创办于1975年，公司总部设立在华盛顿州的雷德蒙德（Redmond，邻近西雅图）。以研发、制造、授权和提供广泛的电脑软件服务业务为主。
                        最为著名和畅销的产品为Microsoft Windows操作系统和Microsoft Office系列软件，目前是全球最大的电脑软件提供商。
                        2018年4月22日，2017年全球最赚钱企业排行榜第15。   2018年5月29日，《2018年BrandZ全球最具价值品牌100强》第4位。 2018年7月19日，《财富》世界500强排行榜位列71位。   2018年12月18日，《2018世界品牌500强》第4位。
                        2019年6月，微软悄然删除其MS Celeb人脸识别数据库，微软称该数据库是全球最大的公开人脸识别数据库。   2019年7月，《财富》世界500强排行榜发布，微软位列60位。 2019福布斯全球数字经济100强榜排名第2位。  2019年10月，Interbrand发布的全球品牌百强排名第四位。  2020年1月22日，名列2020年《财富》全球最受赞赏公司榜单第3位。
                        '''
                    elif a == "迷你世界" or a == "迷你"  or a == "mini":
                        b='一款抄袭我的世界的垃圾游戏，玩家都是幼儿园和1、2年级的xxs'
                    elif a == "微博" or a == "微型博客" or a == "Wei Bo" or a == "Weibo" or a == "weibo" :
                        b="微博（Weibo）是指一种基于用户关系信息分享、传播以及获取的通过关注机制分享简短实时信息的广播式的社交媒体、网络平台，允许用户通过Web、Wap、Mail、App、IM、SMS以及用户可以通过PC、手机等多种移动终端接入，以文字、图片、视频等多媒体形式，实现信息的即时分享、传播互动。2009年8月新浪推出“新浪微博”内测版，成为门户网站中第一家提供微博服务的网站。此外微博还包括腾讯微博，网易微博，搜狐微博等。但如若没有特别说明，微博就是指新浪微博。2014年3月27日晚间，在中国微博领域一枝独秀的新浪微博宣布改名为“微博”，并推出了新的LOGO标识，新浪色彩逐步淡化。2018年8月8日，微博获金运奖年度最佳效果运营奖。"
                    elif a == "PEN果" or a == "PEN果公司" or a == "PEN果工作室" or  a== "MOGO" or a == "Mogo" or a == "mogo" or a == "pen果" or a == "Pen果" or a == "PENGUO" or a == "penguo" or a == "Penguo" or a == "PENguo":
                        b="PEN果公司，全英文名MOGO，全中文名笔果，旗下有酷喵公司，微软工作室，专攻编程专业，研究技术，成立于2019.6.6。室长【缪子航】"
                    elif a == "苹果":
                        b="苹果是蔷薇科苹果亚科苹果属植物，其树为落叶乔木。苹果营养价值很高，富含矿物质和维生素，含钙量丰富，有助于代谢掉体内多余盐分，苹果酸可代谢热量，防止下半身肥胖。苹果是一种低热量的食物，每100克产生大约60千卡左右的热量。苹果中营养成分可溶性大，容易被人体吸收，故有“活水”之称。它有利于溶解硫元素，使皮肤润滑柔嫩。"
                    elif a == "星河工作室":
                        b="暂无介绍。"
                    elif a == "Tank Stars" or  a == "tank stars" or a == "Tank stars" or a == "TANK STARS":
                        b="《Tank Stars》 是一款动作射击冒险游戏，在这个游戏中，玩家需要寻找对手，然后进行互相射击。游戏采用2D卡通风格画面呈现，游戏支持多人模式，玩家可以与好友一起挑战高分，也有单机挑战，在排行榜寻找对战好友。"
                    elif a == "呵呵" or a == "呵呵呵" or a == "呵" :
                        b="呵呵是一个汉语词汇，一指笑声的拟声词，二指形容说话声音含混不清。在网络中常表示在否定对方的同时表达嘲讽和不屑，而容易让人误解为嘲讽为【呵呵】本意或主意。"
                    elif a == "Mojang" or a == "mojang"  or a == "MOJANG"  or a == "MOJANG AB" or a == "Mojang AB" or a == "MOJANG ab" or a == "mojang ab" or a == "Mojäng Aktiebolag":
                        b='''
                        Mojang AB（瑞典文：mojäng /mʊˈjɛŋ/）全名Mojäng Aktiebolag（直译为小工具有限公司）是一个位于瑞典的电子游戏开发商，于2009年由马库斯·佩尔松以“Mojang Specifications”之名创立。因开发了沙盒游戏《我的世界》（Minecraft）而成名。此公司已经开发《Scrolls》和《Cobalt》，同时也继续更新《我的世界》。Mojang总部位于瑞典的首都斯德哥尔摩。
                        该公司已于2014年9月15日被微软以25亿美元收购。
                        '''
                    elif a == "酷喵" or a == "酷喵公司" or a == "酷喵工作室" or a == "kumiao":
                        b="酷喵公司（kumiao）：PEN果公司旗下工作室，成立于2019.1.1，于2019.6.6加入PEN果公司旗下，室长【缪子航】"
                    elif a == "cpb"or a == "Cpb"or a == "CPB"or a == "CPB防栗局"or a == "cpb防栗局"or a == "Cpb防栗局"or a == "SEVA工作室"or a == "SEVA"or a == "seva"or a == "seva工作室":
                        b="原名CPB(防栗局)后改名为SEVA，出过许多出名人物和作品。"
                    elif a == "漫威工作室" or a == "manwei" or a == "漫威":
                        b="漫威工作室创建于2019年10月23日，室长秦浩铭，最多50人左右。"
                    elif a == "qq" or a == "QQ":
                        b='''
                        QQ是腾讯QQ的简称，是一款基于Internet即时通信（IM）软件。目前QQ已经覆盖Microsoft Windows、macOS、Android、iOS、Windows Phone、Linux等多种主流平台。其标志是一只戴着红色围巾的小企鹅。腾讯QQ支持在线聊天、视频通话、点对点断点续传文件、共享文件、网络硬盘、自定义面板、QQ邮箱等多种功能，并可与多种通讯终端相连。
                        2017年1月5日，腾讯QQ和美的集团在深圳正式签署战略合作协议，双方将共同构建基于IP授权与物联云技术的深度合作，实现家电产品的连接、对话和远程控制。双方合作的第一步，是共同推出基于QQfamily IP授权和腾讯物联云技术的多款智能家电产品。
                        2018年12月12日，QQ发布公告，称由于业务调整，webQQ即将在2019年1月1日停止服务，并提示用户下载QQ客户端   。2019年3月13日起，QQ号码可注销   。
                        2019年03月27日，腾讯QQ宣布推出“鹅的20岁”生日庆典特别栏目，第一期分享了那个企鹅图标的“黑历史”。   2019年4月13日，腾讯QQ正式推送了iOS版的v8.0版本更新，将全新的操作界面带给了正式版用户。 
                        '''
                    elif a == "微信" or a == "weixin" or a == "WeChat" or a == "wechat" or a == "Wechat":
                        b='''
                        微信 （腾讯公司的通讯服务应用程序） 
                        微信（WeChat）  是腾讯公司于2011年1月21日推出的一个为智能终端提供即时通讯服务的免费应用程序   ，由张小龙所带领的腾讯广州研发中心产品团队打造 。
                        微信支持跨通信运营商、跨操作系统平台通过网络快速发送免费（需消耗少量网络流量）语音短信、视频、图片和文字，同时，也可以使用通过共享流媒体内容的资料和基于位置的社交插件“摇一摇”、“漂流瓶”、“朋友圈”、”公众平台“、”语音记事本“等服务插件。
                        截止到2016年第二季度，微信已经覆盖中国 94% 以上的智能手机，月活跃用户达到 8.06亿，   用户覆盖 200 多个国家、超过 20 种语言。   此外，各品牌的微信公众账号总数已经超过 800 万个，移动应用对接数量超过 85000 个，广告收入增至36.79亿人民币 [3]  ，微信支付用户则达到了4亿左右。 [4] 
                        微信提供公众平台、朋友圈、消息推送等功能，用户可以通过“摇一摇”、“搜索号码”、“附近的人”、扫二维码方式添加好友和关注公众平台，同时微信将内容分享给好友以及将用户看到的精彩内容分享到微信朋友圈。
                        2018年4月1日起，微信静态条码支付，每天限额500元。   11月30日起，微信暂时下线漂流瓶服务
                        '''
                    elif a == "设置" or a == "set up" or a == "Set up": 
                        b="设置是一个汉语词汇，读音为shè zhì，动词，指设立，布置；放置；装置。出自于黄溍 《圣寿院记》：“器物之须，设置如式。"
                    elif a == "学而思网校":
                        b=" 学而思网校是好未来旗下的中小学在线教育平台，依托学而思强大的教学资源与师资力量，以实现优秀教育资源的共享为己任，建立起的中小学在线教育平台。\n2016年，学而思网校提出“在线学习更有效”的品牌主张，并进行了全面的课程升级，推出“小班直播+个性化辅导”的先进模式。\n学而思网校注册学生人数已超过600万，遍及全国200多个城市。学而思网校以“在线学习更有效”的理念，开创了“直播+辅导”的模式。学而思网校用科技赋能教育，通过人机对话、语音测评等人工智能科技手段，构建更加完善和个性化的教学产品和服务。" 
                    elif a =="mc"or a=="Mc"or a=="MC"or a=="minecraft"or a=="Minecraft"or a=="我的世界"or a=="麦块"or a == "我的":
                        b='''
                        《Minecraft》（官方中文译名《我的世界》，台湾译为《当个创世神》。华人圈亦有人按照谐音称之麦块等），是一款创造生存类游戏，玩家可以在一个三维世界里用各种方块建造建筑物。最初由瑞典人马库斯·阿列克谢·泊松（Markus 'Notch' Persson，很多Minecraft玩家称之为Notch）单独开发，现已成立Mojang公司来开发此游戏。该游戏基于Java平台，开发灵感来自《矮人要塞》（Dwarf Fortress）、《模拟乐园》（Thrillville）、《地城守护者》（Dungeon Keeper）和《Infiniminer》。;现在Minecraft较为流行的四个版本是JAVA版(PC版)，PC中国版，基岩版（PE版），PE中国版（iOS），中国版手游安卓版。有的用Minecraft衍生出很多动画。
                        2014年9月15日，Mojang AB以及Minecraft被微软(Microsoft)以25亿美元的价格收购。2017年3月，中国大陆代理商网易正式确定Minecraft中文名为《我的世界》，《我的世界》中国版于2017年4月10开始小规模技术性删档测试，于2017年7月14日开始限号不删档测试，于2017年8月8日开始不限号测试，中国版手游iOS于2017年9月15日公测，手游安卓于2017年10月12日开玩。2018年7月6日，《我的世界》海洋版本正式上线手游。7月10日推出海洋更新版本。2018年11月，《我的世界》1.14测试版更新（至11月20日）。2019年4月，《我的世界》正式更新1.14版本，此版本更新了一个全新的材质包等等。"
                        '''
                    elif a == "中国" or a == "中华人民共和国":
                        b="中国，是以华夏文明为源泉、 中华文化为基础，并以汉族为主体民族的多民族国家，通用汉语、汉字，汉族与少数民族被统称为“ 中华民族”，又自称为炎黄子孙、龙的传人。中国是世界四大文明古国之一，有着悠久的历史，距今约5000年前，以中原地区为中心开始出现聚落组织进而形成 国家，后历经多次民族交融和朝代更迭，直至形成多民族国家的 大一统局面。20世纪初辛亥革命后， 君主政体退出历史舞台，共和政体建立。1949年中华人民共和国成立后，在中国大陆建立了人民代表大会制度的政体。中国文化渊远流长，是东亚文化圈的文化宗主国，在世界文化体系内占有重要地位，由于各地的地理位置、自然条件的差异，人文、经济方面也各有特点。传统文化艺术形式有 诗词、戏曲、书法、国画等，而春节、元宵、清明、端午、中秋、重阳等则是中国重要的传统节日。" 
                    elif a == "马子锦"or a == "马秃头" or  a =="马没秃":
                        b="马子锦，星河室长，又称马秃头。于2019年8月28号建立了星河工作室，他改编了slow函数，这个函数的作用是逐字输出。他十分伟大，伟大到什么程度呢？你看的C++里的逐字输出，就是他做的。" 
                    elif a == "缪子航": 
                        b="缪子航，PEN果室长。" 
                    elif a == "lcj"or a == "李承骏":
                        b="李承骏，星光工作室的优秀员工，干劲十足、创意源源不断，最强大脑是他的成名作。"
                    elif a=="吴宇航":
                        b='''
                          吴宇航 
                        此作品作者
                        '''
                    elif a=="三文鱼":
                        b="三文鱼（Oncorhynchus），又名大马哈鱼、鲑鱼、撒蒙鱼，属硬骨鱼纲、鲑形目、鲑属，主要分布在大西洋与太平洋、北冰洋交界的水域，属于冷水性的高度洄游鱼类，被国际美食界誉为“冰海之皇”。研究表明，金枪鱼和三文鱼均肉质鲜美，营养丰富，并且富含EPA和DHA等生物活性物质。 三文鱼具有商业价值的品种有30多个，目前最常见的是2种鳟鱼（三文鳟、金鳟）和4种鲑鱼（太平洋鲑、大西洋鲑、北极白点鲑、银鲑）。  "
                    elif a=="方便面":
                        b="""方便面，又称快餐面、泡面、杯面、快熟面、速食面、即食面，南方一般称为碗面，香港则称之为公仔面，是一种可在短时间之内用热水泡熟食用的面制食品。
                        广义上是指一种可在短时间之内用热水泡熟食用的面制食品，有相关的菜肴如归泡面、泡面沙拉等；狭义的方便面上通常指由面饼、调料包及油包组成的销售成品，市面上以袋装和杯或碗装居多。安藤百福在1958年发明方便面，随着生活节奏加快及旅行需要，方便面为现代生活不可或缺的简易食品之一。
                        方便面是通过对切丝出来的面条进行蒸煮、油炸，让面条形状固定（一般为方形或圆形），食用前以开水冲泡，溶解调味料，并将面条加热冲泡开，在短时间（一般在3分钟内）内便可食用的即食方便食品。
                        如今市场上各种品牌的方便面充斥着各大商场的货架，从大型零售超市到街头的小门头商铺都能够看到它的身影。"""
                    elif a=="手机":
                        b="手机、全称为移动电话或无线电话，通常称为手机，原本只是一种通讯工具，早期又有大哥大的俗称  ，是可以在较广范围内使用的便携式电话终端，最早是由美国贝尔实验室在1940年制造的战地移动电话机发展而来。1958年，苏联工程师列昂尼德.库普里扬诺维奇发明了ЛК-1型移动电话，1973年，美国摩托罗拉工程师马丁·库帕发明了世界上第一部商业化手机。迄今为止已发展至5G时代了。"
                    elif a == "电视剧":
                        b="电视剧（ TVplay; teleplay; TV drama; TV serial;）一种专为在电视上播映的演剧形式。它兼容电影、戏剧、 文学、音乐、舞蹈、绘画、造型等现代艺术诸元素，是一种适应电视广播特点、融合舞台和电影艺术的表现方法而形成的现代艺术样式。一般分单本剧和系列剧（电视影集）。电视剧是随着电视广播事业的诞生而发展起来的，在这幕后有一定的推动作用致使一些电视剧网站孕育而生，比较典型的分类电视剧在线观看网站很受大众的喜爱。生活中，电视剧的定义已经狭义化，仅指电视剧集系列，而非其他形式。“电视剧”的概念是中国特有的，在美国称“电视戏剧”，在苏联称“电视故事片”，在日本称“电视小说”。电视剧（又称为剧集、电视戏剧节目、电视戏剧或电视系列剧）是一种适应电视广播特点、融合舞台和电影艺术的表现方法而形成的艺术样式。一般分单元剧和连续剧，利用电视技术制作并通过电视网放映。电视发明后不断普及，最后改变大家对艺术欣赏的方式。电视剧的播放平台一般叫剧场。"
                    elif a == "电影":
                        b="电影，是由活动照相术和幻灯放映术结合发展起来的一种连续的影像画面，是一门视觉和听觉的现代艺术，也是一门可以容纳戏剧、摄影、绘画、音乐、舞蹈、文字、雕塑、建筑等多种艺术的现代科技与艺术的综合体。但它又具有独自的特征，电影在艺术表现力上不但具有其它各种艺术的特征，又因可以运用蒙太奇（法语：Montage）这种艺术性突跃的电影组接技巧，具有超越其它一切艺术的表现手段，而且影片可以大量复制放映，随着现代社会的发展，电影已深入到人类社会生活的方方面面，是人们日常生活不可或缺的一部分。国务院法制办于2018年2月2日—22日就《电影行政处罚裁量办法（征求意见稿）》向社会公开征求意见。"
                    elif a == "巧克力":
                        b="巧克力（chocolate也译朱古力），原产中南美洲，其鼻祖是“xocolatl”，意为“苦水”。其主要原料可可豆产于赤道南北纬18度以内的狭长地带。作饮料时，常称为“热巧克力”或可可亚。"
                    elif a == "尚书":
                        b="《尚书》，最早书名为《书》，约成书于前五世纪，传统《尚书》（又称《今文尚书》）由伏生传下来。传说为上古文化《三坟五典》遗留著作。西汉学者伏生口述的二十八篇《尚书》为今文《尚书》，鲁恭王在拆除孔子故宅一段墙壁时，发现的另一部《尚书》，为古文《尚书》。西晋永嘉年间战乱，今、古文《尚书》全都散失了。东晋初，豫章内史梅赜给朝廷献上了一部《尚书》，包括《今文尚书》33篇，以及伪《古文尚书》25篇 。《尚书》列为重要核心儒家经典之一， “尚”即“上”，《尚书》就是上古的书，它是中国上古历史文献和部分追述古代事迹著作的汇编，是我国最早的一部历史文献汇编。2018年11月，清华大学战国竹简研究成果发布，证实其中古文《尚书》系后人伪作。其「部份篇目」内容的来源可靠性从南宋开始遭受怀疑。清初，这些篇目在主流学术界被定作「伪书」，甚至排除出《尚书》之外。近十多年来，随着出土文献研究的发展，大大拓展了对古代尚书文献的认识。"
                    elif a == "十二生肖":
                        b="十二生肖，又叫属相，是中国与十二地支相配以人出生年份的十二种动物，包括鼠、牛、虎、兔、龙、蛇、马、羊、猴、鸡、狗、猪。 十二生肖的起源与动物崇拜有关。据湖北云梦睡虎地和甘肃天水放马滩出土的秦简可知，先秦时期即有比较完整的生肖系统存在。最早记载与现代相同的十二生肖的传世文献是东汉王充的《论衡》。 十二生肖是十二地支的形象化代表，即子（鼠）、丑（牛）、寅（虎）、卯（兔）、辰（龙）、巳（蛇）、午（马）、未（羊）、申（猴）、酉（鸡）、戌（狗）、亥（猪），随着历史的发展逐渐融合到相生相克的民间信仰观念，表现在婚姻、人生、年运等，每一种生肖都有丰富的传说，并以此形成一种观念阐释系统，成为民间文化中的形象哲学，如婚配上的属相、庙会祈祷、本命年等。现代，更多人把生肖作为春节的吉祥物，成为娱乐文化活动的象征。生肖作为悠久的民俗文化符号，历代留下了大量描绘生肖形象和象征意义的诗歌、春联、绘画、书画和民间工艺作品。除中国外，世界多国在春节期间发行生肖邮票，以此来表达对中国新年的祝福。 "
                    elif a == "节日":
                        b="节日，是指生活中值得纪念的重要日子。是世界人民为适应生产和生活的需要而共同创造的一种民俗文化，是世界民俗文化的重要组成部分。各民族和地区都有自己的节日。一些节日源于传统习俗，如中国的春节、中秋节、清明节、重阳节等。有的节日源于宗教，比如##教国家的圣诞节。有的节日源于对某人或某件事件的纪念，比如中国的端午节、国庆节、青年节等等。另有国际组织提倡的运动指定的日子，如劳动节、妇女节、母亲节。随着时间推移，节日的内涵和庆祝方式也在发生着变化。而现时节日经常与假日相混淆，事实上大多数节日都没有法定假期，如中国部分传统节日仍没有假期，如重阳节。"
                    elif a == "吸烟":
                        b="吸烟有危害，不仅仅危害人体健康，还会对社会产生不良的影响。任何有组织生物体只要还有生命迹象就必须要呼吸，呼出体内的二氧化碳，吸入空气中的氧气，进行新陈代谢，以维持正常的生命活动。不吸烟的人，每天都能吸入大量的新鲜空气；而经常吸烟的人，却享受不到大自然的恩惠，吸入的不是新鲜空气，而是被烟雾污染的有毒气体。烟叶里含有毒质烟碱，也叫尼古丁。1克重的烟碱能毒死300只兔或500只老鼠。如果给人注射50毫克烟碱，就会致死。吸烟对呼吸道危害最大，很容易引起喉头炎、气管炎，肺气肿等咳嗽病。吸烟的时候烟从口入，经过喉咙、气管、支气管、进入血液里。吸烟会让男性丢失Y染色体，增加患癌风险。  2017年10月27日，世界卫生组织国际癌症研究机构公布的致癌物清单初步整理参考，吸烟在一类致癌物清单中。 2018年5月1日起，在动车组列车上吸烟的旅客将被纳入“失信人”名单，在180天内限制乘车。"
                    elif a == "水":
                        b="水，化学式为H₂O，是由氢、氧两种元素组成的无机物，无毒，可饮用。在常温常压下为无色无味的透明液体，被称为人类生命的源泉。水是地球上最常见的物质之一，是包括无机化合、人类在内所有生命生存的重要资源，也是生物体最重要的组成部分。 纯水可以导电，但十分微弱，属于极弱的电解质。日常生活中的水由于溶解了其他电解质而有较多的正负离子，导电性增强。 "
                    elif a == "奥里给" or a == "奥利给" or a == "奥力给":
                        b="奥利给出自快手上的主播在直播或者录视频时的说的话术，该词就是我们常说的“给力”的意思，也称给力噢，作为感叹词，可能包含了赞美、加油打气等多种感情色彩。属于网络流行词。"
                    elif a == "1":
                        b="阿拉伯数字 1"
                    elif a == "2":
                        b="阿拉伯数字 2"
                    elif a == "3":
                        b="阿拉伯数字 3"
                    elif a == "4":
                        b="阿拉伯数字 4"
                    elif a == "5":
                        b="阿拉伯数字 5"
                    elif a == "6":
                        b="阿拉伯数字 6"
                    elif a == "7":
                        b="阿拉伯数字 7"
                    elif a == "8":
                        b="阿拉伯数字 8"
                    elif a == "9":
                        b="阿拉伯数字 9"
                    elif a == "阿拉伯数字":
                        b="阿拉伯数字由0，1，2，3，4，5，6，7，8，9共10个计数符号组成，阿拉伯数字最初由古印度人发明，后由阿拉伯人传向欧洲，之后再经欧洲人将其现代化，人们以为是阿拉伯发明，所以人们称其为“阿拉伯数字”。"
                    elif a == "皇帝":
                        b="上古三皇五帝，如羲皇伏羲、娲皇女娲、黄帝轩辕、炎帝神农等都不是真正帝王，仅为部落首领或部落联盟首领，其“皇”或“帝”号，为后人所追加。夏朝君主称“后”，商朝君主称“帝”，周天子称“王”。战国诸侯大多僭越称王，尊周天子为“天王”。秦王嬴政统一中国，认为自己“德兼三皇、功盖五帝”，创“皇帝”一词作为华夏最高统治者的正式称号。所以，秦始皇嬴政是中国首位皇帝，自称“始皇帝”。从此“皇帝”取代了“帝”与“王”，成为中国两千年多来封建社会最高统治者的称呼。"
                    elif a == "编程社区":
                        b="学而思编程社区、慧编程社区、小码王编程社区、编程猫编程社区、卡塔编程社区、GitHub等一些社区，去浏览器里搜就能搜到"
                    elif a == "《风》":
                        b="《风》是唐代诗人李峤创作的一首诗。此诗通过抓住“叶”“花”“浪”“竹”四样自然界物象在风力作用下的易变，间接地表现了“风”之种种形力、魅力与威力：它能使晚秋的树叶脱落，能催开早春二月的鲜花，经过江河时能掀起千尺巨浪，刮进竹林时可把万棵翠竹吹得歪歪斜斜。全诗四句两两成偶，以“三”“二”“千”“万”数字对举排列来表现风的强大，也表达了诗人对大自然的敬畏之情。"
                    elif a == "游戏":
                        b="游戏是所有哺乳类动物，特别是灵长类动物学习生存的第一步。它是一种基于物质需求满足之上的，在一些特定时间、空间范围内遵循某种特定规则的，追求精神世界需求满足的社会行为方式，但同时这种行为方式也是哺乳类动物或者灵长类动物所需的一种降压减排的方式，不管是在出生幼年期，或者发育期，成熟期都会需要的一种行为方式。 合理适度的游戏允许人类在模拟环境下挑战和克服障碍，可以帮助人类开发智力、锻炼思维和反应能力、训练技能、培养规则意识等，大型网络游戏还可以培养战略战术意识和团队精神。但凡事过犹不及，过度游戏也会对人的身心健康产生危害，沉迷于虚拟世界里，随心所欲的宣泄情感，因此长期沉迷网络游戏的孩子会对周围的人和事冷漠麻木，有的还会荒废学业，甚至发生犯罪现象，给正常生长带来各种各样的危害。2018年6月18日，世界卫生组织发布新版《国际疾病分类》，“游戏障碍”，被列为疾病。但是游戏障碍与人们口中说的游戏成瘾是两个不同的概念，容易混淆。 游戏有智力游戏和活动###之分，又翻译为Play、Pastime、Playgame、Sport、Spore、Squail、Games、Hopscotch、Jeu、Toy。现在的游戏多指各种平台上的电子游戏。"
                    elif a == "大脑":
                        b="大脑为神经系统最高级部分，由左、右两个大脑半球组成，两半球间有横行的神经纤维相联系。每个半球包括：大脑皮层（大脑皮质）：是表面的一层灰质（神经细胞的细胞体集中部分）。人的大脑表面有很多往下凹的沟（裂），沟（裂）之间有隆起的回，因而大大增加了大脑皮层的面积。人的大脑皮层最为发达，是思维的器官，主导机体内一切活动过程，并调节机体与周围环境的平衡，所以大脑皮层是高级神经活动的物质基础。"
                    elif a == "表情":
                        b="表情是一个汉语词语，拼音是biǎo qíng，意思是表达感情、情意。表现在面部或姿态上的思想感情。现代年轻人聊天多用图片类表情来代替语言进行交流，并衍生出海峡两岸表情大战等年轻文化交流事件。表情是情绪的主观体验的外部表现模式。人的表情主要有三种方式：面部表情、语言声调表情和身体姿态表情"
                    elif a == "666":
                        b="666是一个网络用语，用来形容某人或某物很厉害很牛、令人折服（大多是指游戏玩的好）。而在西方，666指魔鬼，撒旦和灵魂，是不吉利的象征。随着时代的发展，各类游戏的节奏也越来越快，666这样的语言用的越来越多。在江苏破获的网络涉毒案中，犯罪嫌疑人用666暗指吸毒，意思是让你溜。当人们表现出超常的能力时也会用来感叹。"
                    elif a == "555定时器":
                        b="55定时器是一种集成电路芯片，常被用于定时器、脉冲产生器和振荡电路。555可被作为电路中的延时器件、触发器或起振元件。555定时器于1971年由西格尼蒂克公司推出，由于其易用性、低廉的价格和良好的可靠性，直至今日仍被广泛应用于电子电路的设计中。许多厂家都生产555芯片，包括采用双极型晶体管的传统型号和采用CMOS设计的版本。555被认为是当前年产量最高的芯片之一，仅2003年，就有约10亿枚的产量。"
                    elif a == "哥斯拉":
                        b="《哥斯拉》（Godzilla）是一部由传奇影业与华纳兄弟影业公司合拍，英国导演加里斯·爱德华斯执导的美国科幻怪兽电影，是“哥斯拉系列”的重启、美国拍摄的第二部有关“哥斯拉”的影片，上一部同名影片于1998年上映。该片由亚伦·泰勒-约翰逊、渡边谦、伊丽莎白·奥尔森、朱丽叶·比诺什、莎莉·霍金斯、大卫·斯特雷泽恩、布莱恩·科兰斯顿等主演。该片重塑日本哥斯拉“可怕的自然之力”形象，于2014年5月16日"
                    elif a == "哪吒":
                        b="""哪吒（ nézhā），中国古代神话传说人物，道教##神。   哪吒信仰兴盛于道教与民间信仰；在道教的头衔为中坛元帅、通天太师、威灵显赫大将军、三坛海会大神等；尊称太子爷、三太子、善胜童子。 
                        主要记载源于元代宗教神话典籍《三教搜神大全》，活跃于明代神魔系列小说名著《西游记》、《南游记》、《封神演义》等多部古典文学作品。 托塔李天王家的三太子，最早传说来自古波斯和古印度教的神话，随着本土化的传教，唐末起就从古盛传至今，由佛教##军神“那咤”演变而成 [6]  ，记载已在东晋有之，主要定型于闹海传说与屠龙之说的内容，以及降魔伏妖再成仙成圣等古籍文献，出生奇异，一身神器，能变化三头六臂又或三头八臂，百邪不侵专克摄魂夺魄的莲花化身。
                        在中国各地成为世代传奇且家喻户晓的著名艺术形象；后期影响民间奉祀为保护神，并渐被道教所吸纳，将其遵崇供为中央祭坛的大罗天神，地位高贵鼎盛；神仙谱中被归类为“忠武战神”之位，属于武神一系。在民俗被尊为护世护民的“五营神将”之首；乃统领天兵天将的元帅之神，又称“太子元帅”，还被敬作“天帅领袖”和“火轮天王”，常以娃娃或者少年儿童的模样登场，终成神话史上独特无双、神通广大的天庭童神。在儒释道三体合流相融的文化传承中，得享华人的普遍崇拜与信仰。更因为其鲜明精彩的古老形象与经典传说故事名气响亮，从而吸引现代众多动漫和影视剧都将哪吒设定为主角，加以儿童化的少年英雄方式传扬，深受诸多孩子们的欢迎和喜爱。"""
                    elif a == "你好":
                        b="拼音[nǐ hǎo] 打招呼的敬语，作为一般对话的开场白、常用语。这也是个最基本的中文词语。主要用于打招呼请教别人问题前的时候，或者单纯表示礼貌的时候等。"
                    elif a == "KFC"or a =="肯德基":
                        b="肯德基（KentuckyFried Chicken，肯塔基州炸鸡，简称KFC），是美国跨国连锁餐厅之一，也是世界第二大速食及最大炸鸡连锁企业，1952年由创始人哈兰·山德士（Colonel Harland Sanders）创建， 主要出售炸鸡、汉堡、薯条、盖饭、蛋挞、汽水等高热量快餐食品。肯德基隶属于百胜中国控股有限公司（简称“百胜中国”） [2]  ， 股票代码为YUMC  ，是Yum！Brands在中国大陆的特许经营商   ，拥有肯德基品牌在中国大陆的独家经营权。 肯德基与百事可乐结成了战略联盟，固定销售百事公司提供的碳酸饮料。2017年6月，《2017年BrandZ最具价值全球品牌100强》公布，肯德基排名第81位。 自2018年2月17日开始，英国的大部分肯德基网点仍然暂停营业。当地900家门店中，截至2月20日，仍有562家处于关闭状态，在2月18日晚歇业的门店数量达到顶峰的646家。 在2018世界品牌500强排行榜中，肯德基排名第129位。"
                    elif a == "82年的拉菲":
                        b="82年的拉菲，网络流行语，源自影视剧中开拉菲的桥段，由于82年的拉菲酒品质好、价格昂贵，所以“82年的拉菲”是高规格的代名词。常常在网络聊天时作为表情包使用。"
                    elif a == "面":
                        b="（1）面，读作：miàn。面字从“一 + 自”，从囗（wéi）。“一 + 自”表示“鼻子及其附近”。“囗”指“外围”。“一 + 自”与“囗”联合起来表示“人脸”。本义是人脸。转义是妇人以谷粉擦脸。（2）麺、麪，读作：miàn。形声。从麦，丏或面声。本义：麦子磨的面粉。"
                    elif a == "饭":
                        b="fàn形声。字从食，从反，反亦声。“反”意为“镜像对称的事物或动作”。“食”与“反”联合起来表示“二人对食”。本义：夫妻对食。TA说"
                    elif a == "酒":
                        b="酒，中国汉语词汇，音jiu。英文：wine,Alcohol酒的化学成分是乙醇，一般含有微量的杂醇和酯类物质，食用白酒的浓度一般在60度（即60%）以下（少数有60度以上），白酒经分馏提纯至75%以上为医用酒精，提纯到99.5%以上为无水乙醇。酒是以粮食为原料经发酵酿造而成的。据新华社消息，饮酒量不论多少都无益。"
                    elif a == "牛肉":
                        b="牛肉（拼音：niú ròu），指从牛身上获得的肉，为常见的肉品之一。来源可以是奶牛、公牛、小母牛。牛的肌肉部分可以切成牛排、牛肉块或牛仔骨，也可以与其他的肉混合做成香肠或血肠。其他部位可食用的还有牛尾、牛肝、牛舌、牛百叶、牛胰腺、牛胸腺、牛心、牛脑、牛肾、牛鞭。牛肠也可以吃，不过常用来做香肠衣。牛骨可用做饲料。阉牛和小母牛肉质相似，但阉牛的脂肪更少。年纪大的母牛和公牛肉质粗硬，常用来做牛肉末。肉牛一般需要经过育肥，饲以谷物、膳食纤维、蛋白质、维生素和矿物质。牛肉是世界第三消耗肉品，约占肉制品市场的25%。落后于猪肉（38%）和家禽（30%）。美国、巴西和中国是世界消费牛肉前三的国家。按2009年人年消费来看，阿根廷以64.6千克排名第一，美国为42.1千克，欧洲为11.9千克。最大的牛肉出口国包括印度、巴西、澳大利亚和美国。牛肉制品对于巴拉圭、阿根廷、爱尔兰、墨西哥、新西兰、尼加拉瓜、乌拉圭的经济有重要影响。"
                    elif a == "空手道":
                        b="空手道是日本传统格斗术结合琉球武术唐手而形成的，起源于日本武道和琉球的唐手。唐手是中国武术传入琉球，结合当地武术琉球手发展而成的，而日本本土人又将九州、本州的摔、投等格斗技与唐手相结合，最终形成空手道。二战之后通过美军宣传而在全世界广泛传播。空手道当中包含踢、打、摔、拿、投、锁、绞、逆技、点穴等多种技术，一些流派中还练习武器术。一九九四年日本广岛第十二届亚运会空手道首次成为正式比赛项目，空手道比赛场地一般为8×8米；至于比赛项目有套路赛（型）和格斗赛（组手）两种，而在组手比赛中一方有效进攻导致对手瞬时丧失战斗能力或重心明显移动为得分标准。"
                    elif a == "《刀》":
                        b="《刀》是由徐克执导，赵文卓、熊欣欣、桑妮主演的动作片。影片讲述了刀客黎定安尽管失去右手又只有一本残缺的绝世刀谱在身，仍义无反顾地自创独臂刀法决战仇家，为父报仇的故事。该片于1995年12月21日在香港上映。"
                    elif a == "细菌":
                        b="细菌（学名：Bacteria）是指生物的主要类群之一，属于细菌域。也是所有生物中数量最多的一类，据估计，其总数约有5×10^30个。细菌的形状相当多样，主要有球状、杆状，以及螺旋状。细菌也对人类活动有很大的影响。一方面，细菌是许多疾病的病原体，包括肺结核、淋病、炭疽病、梅毒、鼠疫、砂眼等疾病都是由细菌所引发。然而，人类也时常利用细菌，例如乳酪及酸奶和酒酿的制作、部分抗生素的制造、废水的处理等，都与细菌有关。在生物科技领域中，细菌也有着广泛的运用。"
                    elif a == "自然"or a == "大自然":
                        b="自然，哲学名词，广义而言指的即是自然界，规模，   大至宇宙，小至基本粒子， 包括物理学宇宙、物质世界及物质宇宙。亦指道家术语。   东汉至六朝的佛教深受道教自然影响。至南北朝时期左右本土化佛教逐渐完成，由佛教所挑起的关于自然、因缘的争论。《楞严经》：“非因缘生，非自然性”，《道德真经广圣义》：“以无为体，以无为用，自然为体，因缘为用。此皆无也。” 与道家/教重视自然原则不同， 早期佛教认为世界万法都是因缘而成，均无其独立自性，因而是不真实的。这种通过分析主义的思维途径来论证事物虚幻不实的作法为其后大乘佛教所继承。大乘佛教进一步提出缘起论以对世界做性空的价值判断。这种通过层层分析达至的空相对中国传统重视阴阳和合的思想传统， 实在缺乏强制性。道理很简单， 因为中国人根本就不认为阴阳和合的事物不真实， 反而认为事物只有通过阴阳和合才能达至更高的善与美。这应当与中国古代重视综合性、 整体性思维方式密切相关。跟刘宋高僧慧琳一样在 《白黑论》 中对佛教的缘起性空理论予以驳斥：今析毫空树， 无伤垂荫之茂;离材虚空， 不损轮奂之美。明无常增其渴荫之情， 陈苦伪笃其竞辰之虑。 (《宋书》 卷九七 《天竺迦毗黎传》 )贝锦以繁采发挥， 和羹以盐梅致旨， 齐侯追爽鸠之乐， 燕王无延年之术。恐和合之辨， 危脆之教， 正足恋其嗜欲之私， 无以倾其爱竞之惑也。 (《宋书》 卷九七 《天竺迦毗黎传》 )这显然是用中土的和合论来对抗佛教的缘起论。"
                    elif a == "起床":
                        b="起床，本意离床下地、起身，喻指病愈。语出《儒林外史》第四八回：“饿到六天上，不能起牀（床）。"
                    elif a == "起床战争":
                        b="起床战争是《Minecraft》服务器中流行的PVP游戏，目的是搭方块到各种岛屿收集各种资源，保护自家的床并且挖掉其他队的床并杀死所有敌人来赢得游戏胜利。起床战争内容主题为‘床’（有些服务器是蛋糕），即重生点。玩家至少需要1人。一般的起床战争玩家分为4队或8队，每队4～16人。"
                    elif a == "PVP":
                        b="Present value of product： 即产品的现期价值，它是指经过一些时间变化后，所生产出来的产品在现在时间比以前时间所体现出来的价值。"
                    elif a == "小欢喜":
                        b="《小欢喜》是由汪俊执导，黄磊、海清、陶虹、王砚辉、咏梅领衔主演，周奇、李庚希、郭子凡、刘家祎主演，沙溢、任重特别出演的都市情感剧  。该剧改编自鲁引弓的同名小说   ，以方圆、童文洁夫妇的视角，讲述了方家、季家、乔家等几个高三考生家庭在高三这一年的故事  。该剧于2019年7月31日在东方卫视、浙江卫视首播，并在爱奇艺、腾讯视频同步播出"
                    elif a == "标准":
                        b="标准是规范性文件之一。其定义是为了在一定的范围内获得最佳秩序，经协商一致制定并由公认机构批准，共同使用的和重复使用的一种规范性文件。"
                    elif a == "作业帮":
                        b="作业帮致力于为全国中小学生提供全学科的学习辅导服务，作业帮用户量突破8亿 [1]  ，月活用户约1.7亿 [2]  ，是中小学在线教育领军品牌。 [3-6] 作业帮自主研发多余项学习工具，包括拍照搜题、作业帮直播课、古文助手、作文搜索等。在作业帮，学生可以通过拍照、语音等方式得到难题的解析步骤、考点答案；可以通过作业帮直播课与教师互动学习；可以迅速发现自己的知识薄弱点，精准练习补充；可以观看课程直播，手机互动学习；也可以连线老师在线一对一答疑解惑；学习之余还能与全国同龄学生一起交流，讨论学习生活中的趣事。2019年6月11日，作业帮入选“2019福布斯中国最具创新力企业榜”。 [7-8] 2019年12月24日，通过教育部备案，备案号为教APP备1100058号。 [9]"
                    elif a == "谷歌":
                        b="谷歌公司（Google Inc.）成立于1998年9月4日，由拉里·佩奇和谢尔盖·布林共同创建，被公认为全球最大的搜索引擎公司。 [1] 谷歌是一家位于美国的跨国科技企业，业务包括互联网搜索、云计算、广告技术等，同时开发并提供大量基于互联网的产品与服务，其主要利润来自于AdWords等广告服务。 [2] 1999年下半年，谷歌网站“Google”正式启用。 [3]  2010年3月23日，宣布关闭在中国大陆市场搜索服务。2015年8月10日，宣布对企业架构进行调整，并创办了一家名为Alphabet的“伞形公司”（Umbrella Company），成为Alphabet旗下子公司。2015年，在2015年度“世界品牌500强”排行中重返榜首，苹果和亚马逊分别位居第二和第三名。2016年6月8日，《2016年BrandZ全球最具价值品牌百强榜》公布，以2291.98亿美元的品牌价值重新超越苹果成为百强第一。 [4]  2017年2月，Brand Finance发布2017年度全球500强品牌榜单，排名第一。 [5]  2017年6月，《2017年BrandZ最具价值全球品牌100强》公布，谷歌公司名列第一位。 [6] 2017年12月13日，谷歌正式宣布谷歌AI中国中心（Google AI China Center）在北京成立。 [7] 2018年1月，腾讯和谷歌宣布双方签署一份覆盖多项产品和技术的专利交叉授权许可协议。 [8]  2018年5月29日，《2018年BrandZ全球最具价值品牌100强》发布，谷歌公司名列第一位。12月18日，世界品牌实验室编制的《2018世界品牌500强》揭晓，Google排名第2位。 [9]  2019年度全球最具价值100大品牌榜第二位。 [10]"
                    elif a == "小米" or a == "小米公司":
                        b="北京小米科技有限责任公司成立于2010年3月3日 [1]  ，是一家专注于智能硬件和电子产品研发的全球化移动互联网企业 [2]  ，同时也是一家专注于高端智能手机、互联网电视及智能家居生态链建设的创新型科技企业。 [3] 小米公司创造了用互联网模式开发手机操作系统、发烧友参与开发改进的模式。小米还是继苹果、三星、华为之后第四家拥有手机芯片自研能力的科技公司。2018年7月9日在香港交易所主板挂牌上市，成为港交所上市制度改革后首家采用不同投票权架构的上市企业。 [4] “为发烧而生”是小米的产品概念。“让每个人都能享受科技的乐趣”是小米公司的愿景。小米公司应用了互联网开发模式开发产品的模式，用极客精神做产品，用互联网模式干掉中间环节，致力让全球每个人，都能享用来自中国的优质科技产品。 [3] 小米已经建成了全球最大消费类IoT物联网平台，连接超过1亿台智能设备 [5]  ，MIUI月活跃用户达到2.42亿 [6]  。小米系投资的公司接近400家，覆盖智能硬件、生活消费用品、教育、游戏、社交网络、文化娱乐、医疗健康、汽车交通、金融等领域。2019年6月，入选2019福布斯中国最具创新力企业榜。 [7-8]  2019年7月，2019世界500强排行榜发布，小米排名468位 [9]  。2019年10月，2019福布斯全球数字经济100强榜发布，小米位列第56位。 [10]  2019年12月18日，人民日报“中国品牌发展指数”100榜单排名30位。 [11] 2019年，小米手机出货量1.25亿台，全球排名第四， [12]  电视在中国售出1021万台，排名第一。 [13]  入围2020全球百强创新名单，AI等专利位于全球前列。 [14] "
                    elif a == "苹果电脑" or a == "macbook" or a == "Macbook":
                        b="苹果电脑是苹果公司开发上市的一种产品，苹果公司原称苹果电脑公司（Apple Computer, Inc.）总部位于美国加利福尼亚的库比提诺，核心业务是电子科技产品，全球电脑市场占有率为3.8%。苹果的Apple II于1970年代助长了个人电脑革命，其后的Macintosh接力于1980年代持续发展。最知名的产品是其出品的Apple II、Macintosh电脑、iPod数位音乐播放器、iTunes音乐商店和iPhone智能手机，它在高科技企业中以创新而闻名。苹果公司于2007年1月9日旧金山的Macworld Expo上宣布改名。"
                    elif a == "2020":
                        b="尔凌软件科技有限公司（2020软件）成立于2007年，是一家辅助家居行业的软件供应商。主要经营计算机软件的开发、设计、制作，销售自产产品。总部位于加拿大，在上海和广州分别设立了办公室，2020的主要产品有针对家居行业设计、生产、管理的软件。2020Design 家具设计软件、2020 imos 易模式家具工艺软件、2020Insight 家具管理软件、2020IdealSpaces家居体验设计平台。"
                    elif a == "2012":
                        b="《2012》是一部关于全球毁灭的灾难电影，由罗兰·艾默里奇执导，约翰·库萨克、桑迪·牛顿、阿曼达·皮特和切瓦特·埃加福特等联袂出演，影片于2009年11月13日在美国上映。影片故事发生在2012年12月，一家人正在度假。没想到根据玛雅预言，2012年的12月21日，正是世界末日，玛雅人的日历也到那天为止，再没有下一页。电影讲述了主人公以及世界各国人民挣扎求生的经历，灾难面前，尽现人间百态"
                    elif a == "清"or a == "清朝":
                        b="清朝（1636年—1912年），是中国历史上最后一个封建王朝，共传十二帝  ，从努尔哈赤建立后金政权起，总计296年。   从皇太极改国号为清开始，国祚276年。   从清兵入关，建立全国性政权算起为268年。 1616年，建州女真首领努尔哈赤建立后金。1636年，皇太极改国号为大清。1644年，驻守山海关的明将吴三桂降清，多尔衮率领清兵入关，至1659年平定大顺、大西、南明等政权。后又平定三藩之乱、统一台湾，逐步掌控全国。  康雍乾三朝走向鼎盛，在此期间，中国的传统社会取得了前所未有的发展成就。清初人口增殖，土地增垦，物产盈丰，边境无事，小农经济的生产方式和社会生活相对繁荣稳定，综合国力远胜于汉唐。 [8]  鸦片战争后多遭列强入侵，中国人民进行了洋务运动和戊戌变法等近代化的探索和改革。1912年2月12日，北洋大臣袁世凯诱使清帝溥仪逊位，颁布了退位诏书，清朝从此结束。 [9-10] 清朝时期，统一多民族国家得到巩固和发展，清朝统治者统一蒙古诸部，将新疆和西藏纳入版图，积极维护国家领土主权的完整。乾隆年间，中国作为统一的多民族世界大国的格局最终确定。极盛时期的清朝，西抵葱岭和巴尔喀什湖，西北包括唐努乌梁海，北至漠北和西伯利亚，东到太平洋（包括库页岛），南达南沙群岛。包括50多个民族，国家空前统一。 期间中国古代的专制主义也推向了最高峰。清朝前期农业和商业发达，江南出现了密集的商业城市，并在全国出现了大商帮。在此基础上，人口突破四亿大关，占世界总人口十亿的近一半。"
                    elif a == "吃":
                        b="吃（拼音：chī），是指用手或工具（筷子，叉子，勺子等）把食物送进口腔，经过牙齿咀嚼后下咽经食道管进入胃里，再由消化系统完成整个消化过程。方言读音：四川方言读音为qī（启）。广东方言读音为hek方言用词：湖南省方言用“呷”（读qia，掐音）表示“吃”：呷饭。"
                    elif a == "麦片":
                        b="麦片(oatmeal)：是一种以小麦为原料加工而成的食品。是用普通的麦子和一些东西加工而成的。它曾经是第一种被工业化生产的早餐谷物食品。麦片的“片”字是指，它是一种来自被煮过，辗碎，和加以烘干的谷物，通常被放在牛奶和果汁里，或做成麦片粥加以食用。 麦片还分为普通麦片和燕麦片，燕麦片是由燕麦做成的，由于麦片食品的制作过程简单，而且省时，有的种类的麦片，只要经过水泡，就可以食用，所以受到了很多人的欢迎。"
                    elif a == "王思聪":
                        b="王思聪，1988年1月3日出生于辽宁省大连市，毕业于伦敦大学学院哲学系，  万达集团董事长王健林的独子，北京普思投资有限公司董事长、IG电子竞技俱乐部创始人、万达集团董事。2010年底，王思聪持有万达院线约1000万股。  2011年4月，因在微博上炮轰俏江南董事长张兰造谣，引起热议。2014年9月12日，王思聪以侵犯名誉权为由，起诉网易和搜狐，否认斥资千万拉票   。2015年8月末，王思聪出镜的BBC纪录片《中国的秘密》播出  ；9月5日，王思聪参加腾讯《英雄联盟》四周年庆典，并表示担任熊猫TV的CEO；10月24日，中国移动电竞联盟成立，王思聪任主席。 2016年，新版“京城四少”名单火热出炉，王思聪位居榜首。  2018年8月18日，王思聪开始自己的职业LOL生涯。同年9月19日，王思聪正式宣布退役。  2019年1月25日，王思聪豪掷630万招募编剧人才和优秀剧本"
                    elif a == "李现":
                        b="李现，曾用名李晛，1991年10月19日出生于湖北省咸宁市，成长于湖北省荆州市，中国内地影视男演员，毕业于北京电影学院表演系2010级。2011年，出演个人首部电影《万箭穿心》，从而正式进入演艺圈。2012年，主演青春爱情电影《初恋未满》。2013年，出演绿色环保爱情喜剧电影《玩命试爱》。2014年，出演国内首部原创都市奇幻单元《奇妙世纪》中第二集“最长的25米”。"
                    elif a == "陈伟霆":
                        b="陈伟霆（William Chan），1985年11月21日出生于中国香港，华语影视男演员、歌手、主持人。2003年，因参加全球华人新秀香港区选拔赛而进入演艺圈。2006年成为Sun Boy’z组合一员。2008年开始独立发展，随后推出个人首张专辑《Will Power》，并获香港十大劲歌金曲颁奖礼最受欢迎男新人金奖及香港十大中文金曲最有前途新人金奖。2013年，陈伟霆将工作重心转移至中国内地，"
                    elif a == "黄家驹":
                        b="黄家驹（1962年6月10日-1993年6月30日），出生于中国香港，中国香港男歌手、原创音乐人、吉他手、摇滚乐队Beyond的主唱、节奏吉他手及创队成员。1983年以歌曲《大厦》出道，并组建Beyond乐队，担任主唱。1988年凭借专辑《秘密警察》在香港歌坛获得关注，其中由黄家驹创作的歌曲《大地》获得十大劲歌金曲奖。1989年凭借歌曲《真的爱你》获得十大劲歌金曲奖以及十大中文金曲奖。"
                    elif a == "周星驰":
                        b="周星驰，1962年6月22日生于香港，祖籍浙江宁波，中国香港演员、导演、编剧、制作人、商人，毕业于无线电视艺员训练班。1980年成为丽的电视台的特约演员，从而进入演艺圈。1981年出演个人首部电视剧《IQ成熟时》。1988年将演艺事业的重心转向大银幕，并于同年出演电影处女作《捕风汉子》。1990年凭借喜剧片《一本漫画闯天涯》确立其无厘头的表演风格 [1]  ；同年，因其主演的喜剧动作片《赌圣》打破香港地区票房纪录而获得关注  。1991年主演喜剧片《逃学威龙》，并再次打破香港地区票房纪录   。1995年凭借喜剧爱情片《大话西游》奠定其在华语影坛的地位。1999年自导自演的喜剧片《喜剧之王》获得香港电影年度票房冠军 2002年凭借喜剧片《少林足球》获得第21届香港电影金像奖最佳男主角奖以及最佳导演奖   。2003年成为美国《时代周刊》封面人物   。2005年凭借喜剧动作片《功夫》获得第42届台湾电影金马奖最佳导演奖 [7]  。2008年自导自演的科幻喜剧片《长江7号》获得香港电影年度票房冠军 [8]  。2013年执导古装喜剧片《西游·降魔篇》，该片以2.18亿美元的票房成绩打破华语电影在全球的票房纪录   。2016年担任科幻喜剧片《美人鱼》的导演、编剧、制作人，该片以超过33亿元的票房创下中国内地电影票房纪录 演艺事业外，周星驰还涉足商界。1989年成立星炜有限公司  。1996年成立星辉公司   。2010年出任比高集团有限公司执行董事"
                    elif a == "赵丽颖":
                        b="赵丽颖，1987年10月16日出生于河北省廊坊市，中国内地影视女演员、歌手。2006年，因获得雅虎搜星比赛冯小刚组冠军而进入演艺圈；同年，在冯小刚执导的广告片《跪族篇》中担任女主角。2011年，因在古装剧《新还珠格格》中饰演晴儿一角而被观众认识。2013年，凭借古装剧《陆贞传奇》获得更多关注。2014年10月，在第10届金鹰电视艺术节举办的投票活动中被选为“金鹰女神”；"
                    elif a == "蔡徐坤":
                        b="蔡徐坤（KUN），1998年8月2日出生于浙江省，中国内地男歌手、演员、音乐制作人。2012年4月，蔡徐坤因参加综艺节目《向上吧！少年》进入全国200强   ；同年8月，参演个人首部偶像剧《童话二分之一》   。2014年3月，参演个人首部电影《完美假妻168》。2018年1月，参加偶像男团竞演养成类真人秀《偶像练习生》，并于同年4月6日获得最高票数，以NINE PERCENT九人男团C位出道并担任队长 [3]  ；同年8月，发行个人首张EP《1》 [4]  ；随后获得出道后首个个人音乐类奖项亚洲新歌榜2018年度盛典“最受欢迎潜力男歌手”   ；同年12月，获第十二届音乐盛典咪咕汇年度“最佳彩铃销量歌手”、年度十大金曲《Wait Wait Wait》、搜狐时尚盛典“年度人气男明星”以及今日头条年度盛典“年度偶像人物”。2019年2月，首登北京台春晚便包揽词曲，为其创作歌曲《那年春天》  。2月18日，发布单曲《没有意外》   。3月22日，发布海外公演主题曲《Bigger》  。4月19日，发布单曲《Hard To Get》"
                    elif a == "迪丽热巴":
                        b="迪丽热巴（Dilraba），1992年6月3日出生于新疆乌鲁木齐市，中国内地影视女演员、歌手，毕业于上海戏剧学院。2013年，迪丽热巴因主演个人首部电视剧《阿娜尔罕》而出道。2014年，她主演了奇幻剧《逆光之恋》。2015年，迪丽热巴凭借爱情剧《克拉恋人》赢得高人气，并获得国剧盛典最受欢迎新人女演员奖。2016年，其主演的现代剧《麻辣变形计》播出；"
                    elif a == "李荣浩":
                        b="李荣浩，1985年7月11日出生于安徽省蚌埠市，中国流行乐男歌手、音乐制作人、吉他手、演员。2013年9月正式出道，至2019年，共发行5张专辑，其作品在大中华区有很高的流行度；入围9次金曲奖，并获得内地首位金曲最佳新人奖；与众多歌手合作，为他人操刀作品逾200首；举办3轮大型巡回演唱会，是首位同时登上台北小巨蛋和香港红磡的内地歌手。2019年8月，获2019福布斯中国100名人榜荣誉。"
                    elif a == "Angelababy"or a=='杨颖':
                        b="angelababy（杨颖），1989年2月28日出生于上海市，华语影视女演员、时尚模特。2003年，Angelababy以模特身份出道，此后，她因担任时尚模特而在香港崭露头角。2007年，她开始将工作重心转向大银幕。2011年，她在爱情片《夏日乐悠悠》中首次担任女主角。2012年，凭借言情片《第一次》获得第13届华语电影传媒大奖最受瞩目女演员奖。"
                    elif a == "海清":
                        b="海清，本名黄怡，1977年1月12日生于中国江苏省南京市，演员，毕业于北京电影学院表演系。2003年，通过出演电视剧《玉观音》中的钟宁一角而出道。2009年11月，出演滕华涛执导的都市情感剧《蜗居》，该剧让海清的演艺事业取得了一定的成功。2010年，凭借主演爱情电视剧《媳妇的美好时代》获得第28届中国电视剧“飞天奖”优秀女演员奖，和第25届中国电视金鹰奖观众喜爱的电视剧女演员奖。"
                    elif a == "黄磊":
                        b="黄磊，1971年12月6日出生于江西省南昌市，中国大陆男演员、导演、编剧、监制、制片人、歌手、教师、作家。1990年黄磊考入北京电影学院表演系，同年出演陈凯歌执导电影《边走边唱》。1996年凭借电影《夜半歌声》获得第3届中国长春电影节最佳男配角奖。1997年北京电影学院硕士毕业后留校任教，同年发行第一张音乐专辑《边走边唱》。1999年出演电视剧《人间四月天》，饰演徐志摩。"
                    elif a == "张信哲":
                        b="张信哲，1967年3月26日生于中国台湾云林县，中国台湾流行乐男歌手、演员、舞台剧团团长。1987年张信哲签约滚石唱片的子公司巨石音乐，1989年发行第一张专辑《说谎》。1995年成立音乐工作室潮水音乐，并加盟EMI旗下附属厂牌种子音乐，1996年凭着专辑《宽容》获得第7届台湾金曲奖最佳国语男歌手奖。1997年推出专辑《过火》、《思念》、《挚爱》、《直觉》。"
                    elif a == "牯牛降风景区":
                        b="牯牛降风景区位于石台县与祁门县交界处，是安徽南部三大高山（黄山、清凉峰、牯牛降）之一，距石台县城22公里，主峰海拔1727.6米，总面积为6700公顷。牯牛降共分五大景区:主峰景区、灵山景区、双龙谷景区、龙门景区、观音堂景区。其中前四个皆位于石台县境内，观音堂景区位于祁门县境内。牯牛降以雄、奇、险著称，是黄山山脉向西延伸的主体，古称“西黄山”，山岳风光秀美绮丽。境内有36大峰，72小峰，36大岔，72小岔。因其山形酷似一头牯牛从天而降，故名牯牛降。2014年，牯牛降旅游景点荣获“安徽名牌”产品称号。"
                    elif a == "安庆天柱山风景名胜区":
                        b="天柱山风景名胜区，位于安徽省安庆市潜山市西部，景区因主峰如“擎天一柱”而得名，被誉为“江淮第一山”，主要有天柱峰、飞来峰、天池峰，千米以上高峰有45座，主峰海拔为1488.4米，景区规划保护区面积为333平方公里，风景区面积为82.46平方公里。天柱山风景名胜区内分布有名崖、奇石、异洞、涧瀑、云海等自然景观，位列安徽省三大名山之一（黄山、九华山、天柱山）。景区宗教文化积淀深厚，是中华佛教禅宗发源地之一。禅宗第三代祖师僧璨在此驻锡弘法、传承衣钵。三祖寺多次受到历代帝王加封，享有“禅林谁第一，此地冠南州”的盛誉。保留有“解缚石”、三祖舍利塔、三祖洞等珍贵文物。1982年，被国务院批准为首批国家重点风景名胜区。1992年，被批准为国家森林公园。2000年，被评为国家AAAAA级旅游景区、 2011年，被批准为世界地质公园。"
                    elif a == "沙巴州":
                        b="沙巴州（Negeri Sabah）简称沙州，旧称北婆罗洲，有“风下之地”之美誉，是马来西亚十三个州之一，首府亚庇（旧称哥打京那峇鲁）。位于加里曼丹岛东北部，面积74500平方公里，人口共385.38万（2017年）  ，属于热带雨林气候。沙巴州下设5省，即西海岸省、内陆省、古达省、山打根省、及斗湖省。  2016年沙巴州生产总值达到738亿令吉，人均收入21081令吉，低于马来西亚人均收入38887令吉。  沙巴于1881年至1963年间被英国人统治，直到1963年8月31日起自治（国防、外交、财政、内政等事务仍由英国殖民政府掌管）。1963年9月16日，沙巴加入马来西亚。1984年，沙巴州政府将纳闽分割出来设立成联邦直辖区，是马来西亚唯一的岸外金融中心。"
                    elif a == "亚庇国际机场":
                        b="亚庇国际机场（IATA：BKI，ICAO：WBKK）是马来西亚沙巴最繁忙的国际机场，也是继吉隆坡国际机场全国第二繁忙的机场。位于亚庇市中心附近，是亚洲航空、马来西亚航空的重点城市。机场分为两个航厦，分为第一航厦（Terminal 1）和第二航厦（Terminal 2）。 2006年服务200万名乘客。"
                    elif a == "贝勒大学":
                        b="（Baylor University）创立于1845年, 是德克萨斯州历史上最悠久的大学，也是美国密西西比河以西的第一批教育机构之一。 该大学位于达拉斯 - 沃斯堡大都会区和奥斯汀之间，沿着布拉佐斯河畔而建，占地1000英亩(约4平方公里)。它是一所世界享有盛誉的私立研究型大学，也是世界上最大的浸信会大学校园。"
                    elif a == "君主立宪制":
                        b="君主立宪制（英语：Constitutional monarchy），亦即“有限君主制”，是相对于君主专制的一种国家体制。君主立宪是在保留君主制的前提下，通过立宪，树立人民主权、限制君主权力、实现事务上的共和主义理想但不采用共和政体。可分为二元制君主立宪制、议会制君主立宪制。英国的“光荣革命”为君主立宪制国家开启了先例。一般君主是终身制的，君主的地位从定义上就已经高于国家的其他公民（这是君主与一些其他元首如独裁者的一个区别），往往君主属于一个特别的阶层（贵族），此外世袭制也往往是君主的一个特点。君主虽然是国家元首（head of state），但君主的产生方式与权力范围，会依各个国家的制度而不同；纵使是同一个国家，往往在不同时期，君主的产生方式与权力范围也各不相同。君主立宪制与一个国家的国情和文化传统有着密切关系，它具有一定的进步性，同时也有一定的妥协性，局限性。英国在革命后通过《权利法案》首先确定。"
                    elif a == "佛罗里达大学":
                        b="佛罗里达大学（University of Florida，简称UF，也称作UFL）是位于美国佛罗里达州盖恩斯维尔（Gainesville）的一所著名的公立研究型大学。佛罗里达大学是北美顶尖大学联盟美国大学协会（AAU）成员之一，建校可追溯至1853年。佛罗里达大学被誉为公立常春藤，在《美国新闻与世界报道（US NEWS）》2019全美综合排名中排第35位，位列全美公立大学第8位；2017年niche   全美公立大学排名第12位，在《美国新闻与世界报道（US NEWS）》2016世界大学排名中排世界第47位。在2018-2019 CWUR世界大学排名中排世界第62位   。在美国本土国家大学排名体系中位列全球第50名。世界大学学术表现排行（URAP）位列世界45名。大学作为全美最大的研究型大学之一，每年为佛罗里达州经济贡献近60亿美元，并创造近七万五千个工作职位。佛罗里达大学共获得研究资金五亿八千三百万美元，其金额超过佛州所有其他大学的总和。学校有超过40位美国国家科学院，工程院，医学院院士。著名的校友包括成功破译遗传密码的Marshall Nirenberg，最早成功提出超导体的微观理论的John Robert Schrieffer，安塔娜索夫-数字计算机之父、卡德-佳得乐饮料的发明者、女星费唐纳威、男星埃布森、佛罗里达州州长。同时贡献了多位NBA球星，如贾森威廉姆斯，阿尔霍福德，钱德勒帕森斯等。校友中至少有10位参议员，40位众议员，17位州长，2位诺贝尔奖得主，3位NASA宇航员和几十位专业运动员，及多位普利策奖和菲尔兹奖获得者。"
                    else:
                        b='词库暂时没有该词可联系作者添加'
                    message=b
                wx.MessageBox(message)  
        if __name__ == '__main__':
            app = wx.App()                      
            frame = MyFrame(parent=None,id=-1)  
            frame.Show()                       
            app.MainLoop()
            fasdasdf1()
    elif dakai == "jisuan":
        class Caluculate(wx.Frame):
            def __init__(self,*args,**kwargs):
                super(Caluculate,self).__init__(*args,**kwargs)
                self.panel = wx.Panel(self)
                self.printbtn = wx.TextCtrl(self.panel, style=wx.TE_MULTILINE | wx.HSCROLL)
                self.num1 = wx.Button(self.panel, label="1")
                self.num2 = wx.Button(self.panel, label="2")
                self.num3 = wx.Button(self.panel, label="3")
                self.num4 = wx.Button(self.panel, label="+")
                self.num5 = wx.Button(self.panel, label="4")
                self.num6 = wx.Button(self.panel, label="5")
                self.num7 = wx.Button(self.panel, label="6")
                self.num8 = wx.Button(self.panel, label="-")
                self.num9 = wx.Button(self.panel, label="7")
                self.num10 = wx.Button(self.panel, label="8")
                self.num11 = wx.Button(self.panel, label="9")
                self.num12 = wx.Button(self.panel, label="*")
                self.num13 = wx.Button(self.panel, label="0")
                self.num14 = wx.Button(self.panel, label=".")
                self.num15 = wx.Button(self.panel, label="=")
                self.num16 = wx.Button(self.panel, label="/")

                self.Boxset()
                self.Event_bind()
                self.Show()

            def Boxset(self):
                sbox1 = wx.BoxSizer()
                sbox2 = wx.BoxSizer()
                sbox3 = wx.BoxSizer()
                sbox4 = wx.BoxSizer()
                sbox5 = wx.BoxSizer()
                vbox = wx.BoxSizer(wx.VERTICAL)
                sbox1.Add(self.printbtn,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.DOWN,border=5)
                sbox2.Add(self.num1,proportion=1,flag=wx.EXPAND|wx.LEFT,border=5)
                sbox2.Add(self.num2,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox2.Add(self.num3,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox2.Add(self.num4,proportion=1,flag=wx.EXPAND|wx.RIGHT,border=5)
                sbox3.Add(self.num5,proportion=1,flag=wx.EXPAND|wx.LEFT,border=5)
                sbox3.Add(self.num6,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox3.Add(self.num7,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox3.Add(self.num8,proportion=1,flag=wx.EXPAND|wx.RIGHT,border=5)
                sbox4.Add(self.num9,proportion=1,flag=wx.EXPAND|wx.LEFT,border=5)
                sbox4.Add(self.num10,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox4.Add(self.num11,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox4.Add(self.num12,proportion=1,flag=wx.EXPAND|wx.RIGHT,border=5)
                sbox5.Add(self.num13,proportion=1,flag=wx.EXPAND|wx.LEFT,border=5)
                sbox5.Add(self.num14,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox5.Add(self.num15,proportion=1,flag=wx.EXPAND|wx.LEFT|wx.RIGHT,border=2)
                sbox5.Add(self.num16,proportion=1,flag=wx.EXPAND|wx.RIGHT,border=5)
                vbox.Add(sbox1,proportion=1,flag=wx.EXPAND|wx.ALL,border=2)
                vbox.Add(sbox2,proportion=1,flag=wx.EXPAND|wx.ALL,border=2)
                vbox.Add(sbox3,proportion=1,flag=wx.EXPAND|wx.ALL,border=2)
                vbox.Add(sbox4,proportion=1,flag=wx.EXPAND|wx.ALL,border=2)
                vbox.Add(sbox5,proportion=1,flag=wx.EXPAND|wx.ALL,border=2)
                self.panel.SetSizer(vbox)

            def test1appd(self,event):
                prv_result = self.printbtn.GetValue()
                self.printbtn.AppendText("1")
            def test2appd(self,event):
                self.printbtn.AppendText("2")
            def test3appd(self,event):
                self.printbtn.AppendText("3")
            def test4appd(self,event):
                self.printbtn.AppendText("+")
            def test5appd(self,event):
                self.printbtn.AppendText("4")
            def test6appd(self,event):
                self.printbtn.AppendText("5")
            def test7appd(self,event):
                self.printbtn.AppendText("6")
            def test8appd(self,event):
                self.printbtn.AppendText("-")

            def test9appd(self,event):
                self.printbtn.AppendText("7")
            def test10appd(self,event):
                self.printbtn.AppendText("8")
            def test11appd(self,event):
                self.printbtn.AppendText("9")
            def test12appd(self,event):
                self.printbtn.AppendText("*")
            def test13appd(self,event):
                self.printbtn.AppendText("0")
            def test14appd(self,event):
                self.printbtn.AppendText(".")
            def test15appd(self,event):
                pre_result = str(self.printbtn.GetValue())
                result = eval(pre_result)
                self.printbtn.SetValue(str(result))
            def test16appd(self,event):
                self.printbtn.AppendText("/")
            def Event_bind(self):
                self.num1.Bind(wx.EVT_BUTTON,self.test1appd)
                self.num2.Bind(wx.EVT_BUTTON,self.test2appd)
                self.num3.Bind(wx.EVT_BUTTON,self.test3appd)
                self.num4.Bind(wx.EVT_BUTTON,self.test4appd)
                self.num5.Bind(wx.EVT_BUTTON,self.test5appd)
                self.num6.Bind(wx.EVT_BUTTON,self.test6appd)
                self.num7.Bind(wx.EVT_BUTTON,self.test7appd)
                self.num8.Bind(wx.EVT_BUTTON,self.test8appd)
                self.num9.Bind(wx.EVT_BUTTON,self.test9appd)
                self.num10.Bind(wx.EVT_BUTTON, self.test10appd)
                self.num11.Bind(wx.EVT_BUTTON, self.test11appd)
                self.num12.Bind(wx.EVT_BUTTON, self.test12appd)
                self.num13.Bind(wx.EVT_BUTTON, self.test13appd)
                self.num14.Bind(wx.EVT_BUTTON, self.test14appd)
                self.num15.Bind(wx.EVT_BUTTON, self.test15appd)
                self.num16.Bind(wx.EVT_BUTTON, self.test16appd)
        app = wx.App()
        Caluculate(None,title="计算器")
        app.MainLoop()
        fasdasdf1()
    #     suyinshu,sb,list3,List1,r_list,bilishu = [],{},[],[],[],[]
    #     global zuida,x_x,x_x2,x_x3,chooseuser
    #     global jieguo1
    #     jieguo1 = 0
    #     zuida = 0
    #     import webbrowser
    #     def jitutonglong(toushu,tuishu):
    #         tuishu = tuishu - toushu * 2
    #         a = int(tuishu / 2)
    #         if a % 1 == 0 and (toushu - a) % 1 == 0:
    #             return "兔" + str(a) + "只鸡" + str(toushu - a) + "只"
    #         else:
    #             return "无解"
    #     def youxi(mode,a,b):
    #         if mode == "1":
    #             return a ** b
    #         elif mode == "2":
    #             a = a ** (1 / b)
    #             return a
    #         elif mode == "3":
    #             return log(b,a)
    #     def hunxunhuan(a,xunhuanjie):
    #         if a[0] == "0":
    #             nima = ""
    #             for i in range(len(xunhuanjie)):
    #                 nima = nima + "9"
    #             for i in range(len(a) - 2 - len(xunhuanjie)):
    #                 nima = nima + "0"
    #             a = int(a.replace("0.",""))
    #             nima2 = int(str(a).replace(xunhuanjie,""))
    #             b = a - nima2
    #             a = int(nima)
    #             zuida = 0
    #             suyinshu.clear()
    #             if a % b == 0:
    #                 zuida = b
    #             elif b % a == 0:
    #                 zuida = a
    #             else:
    #                 d = a
    #                 e = b
    #                 list3.clear()
    #                 if d > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if d % 2 == 0:
    #                         o = d / 2
    #                     else:
    #                         o = (d - 1) / 2
    #                 for i in range(1,int(o + 1)):
    #                     if d % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             if i != 1:
    #                                 list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if d > e:
    #                         if e % 2 == 0:
    #                             o = e / 2
    #                         else:
    #                             o = (e - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = d / 2
    #                         else:
    #                             o = (d - 1) / 2
    #                     for i in range(2,int(o + 1)):
    #                         if d % i == 0 and e % i == 0:
    #                             if zhihe(i) == "N":
    #                                 suyinshu.append(i)
    #                                 list3.append(i)
    #                                 d = d / i
    #                                 e = e / i
    #                 d = 1
    #                 for i in range(len(suyinshu)):
    #                     if i != len(suyinshu) - 1:
    #                         d = d * suyinshu[i]
    #                     else:
    #                         zuida = suyinshu[i] * d
    #                 if zuida == 0:
    #                     zuida = 1
    #             return str(a // zuida) + "分之" + str(b // zuida)
    #         else:
    #             nima2 = ""
    #             i = 1
    #             while a.index(".") - i != -1:
    #                 nima2 = a[a.index(".") - i] + nima2
    #                 i += 1
    #             nima = ""
    #             for i in range(len(xunhuanjie)):
    #                 nima = nima + "9"
    #             for i in range(len(a) - len(nima2) - 1 - len(xunhuanjie)):
    #                 nima = nima + "0"
    #             a = int(a.replace(nima2 + ".",""))
    #             nima2 = int(str(a).replace(xunhuanjie,""))
    #             b = a - nima2
    #             a = int(nima)
    #             zuida = 0
    #             suyinshu.clear()
    #             if a % b == 0:
    #                 zuida = b
    #             elif b % a == 0:
    #                 zuida = a
    #             else:
    #                 d = a
    #                 e = b
    #                 list3.clear()
    #                 if d > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if d % 2 == 0:
    #                         o = d / 2
    #                     else:
    #                         o = (d - 1) / 2
    #                 for i in range(1,int(o + 1)):
    #                     if d % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             if i != 1:
    #                                 list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if d > e:
    #                         if e % 2 == 0:
    #                             o = e / 2
    #                         else:
    #                             o = (e - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = d / 2
    #                         else:
    #                             o = (d - 1) / 2
    #                     for i in range(2,int(o + 1)):
    #                         if d % i == 0 and e % i == 0:
    #                             if zhihe(i) == "N":
    #                                 suyinshu.append(i)
    #                                 list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #                 d = 1
    #                 for i in range(len(suyinshu)):
    #                     if i != len(suyinshu) - 1:
    #                         d = d * suyinshu[i]
    #                     else:
    #                         zuida = suyinshu[i] * d
    #                 if zuida == 0:
    #                     zuida = 1
    #                 return str(nima2) + "又" + str(a // zuida) + "分之" + str(b // zuida)
    #     def jueduizhi(a):
    #         return abs(a)
    #     def abaabaaba(hahaha):
    #         List1.clear()
    #         if hahaha.count("/") == 2:
    #             if "+" in hahaha:
    #                 nima = hahaha[hahaha.index("+") - 1]
    #                 i = 2
    #                 while hahaha[hahaha.index("+") - i] != "/":
    #                     nima = hahaha[hahaha.index("+") - i] + nima
    #                     i += 1
    #                 nima = float(nima)
    #                 nima2 = hahaha[hahaha.index("=") - 1]
    #                 i = 2
    #                 while hahaha[hahaha.index("=") - i] != "/":
    #                     nima2 = hahaha[hahaha.index("=") - i] + nima2
    #                     i += 1
    #                 nima2 = float(nima2)
    #                 zonghe = hahaha[len(hahaha) - 1]
    #                 i = 2
    #                 while hahaha[len(hahaha) - i] != "=":
    #                     zonghe = hahaha[len(hahaha) - i] + zonghe
    #                     i += 1
    #                 zonghe = int(zonghe)
    #                 for i in range(int(zonghe * nima * nima2)):
    #                     if i % nima == 0:
    #                         if i not in List1 and (zonghe - i / nima) * nima not in List1:
    #                             if i >= 0 and (zonghe - i / nima) * nima2 >= 0:
    #                                 List1.append(i)
    #                                 List1.append(int((zonghe - i / nima) * nima2))
    #                 return List1
    #             nima = hahaha[hahaha.index("-") - 1]
    #             i = 2
    #             while hahaha[hahaha.index("-") - i] != "/":
    #                 nima = hahaha[hahaha.index("-") - i] + nima
    #                 i += 1
    #             nima = float(nima)
    #             nima2 = hahaha[hahaha.index("=") - 1]
    #             i = 2
    #             while hahaha[hahaha.index("=") - i] != "/":
    #                 nima2 = hahaha[hahaha.index("=") - i] + nima2
    #                 i += 1
    #             nima2 = float(nima2)
    #             zonghe = hahaha[len(hahaha) - 1]
    #             i = 2
    #             while hahaha[len(hahaha) - i] != "=":
    #                 zonghe = hahaha[len(hahaha) - i] + zonghe
    #                 i += 1
    #             zonghe = int(zonghe)
    #             i = 0
    #             while True:
    #                 if i % nima == 0:
    #                     if i not in List1 and (zonghe - i / nima) * nima2 not in List1:
    #                         if i >= 0 and (zonghe - i / nima) * nima3 >= 0:
    #                             list1.append(i)
    #                             list1.append(int((zonghe - i / nima) * nima2))
    #                             break
    #             for i in range(1,11):
    #                 list1.append(list1[0] + nima * i)
    #                 list1.append(list1[1] + nima2 * i)
    #             return list1
    #         elif hahaha.count("/") == 0:
    #             if "+" in hahaha:
    #                 nima = hahaha[hahaha.index("*") - 1]
    #                 i = 2
    #                 while hahaha.index("*") - i != -1:
    #                     nima = hahaha[hahaha.index("*") - i] + nima
    #                     i += 1
    #                 nima = float(nima)
    #                 hahaha = hahaha.replace(str(nima) + "*x+","")
    #                 nima2 = hahaha[hahaha.index("*") - 1]
    #                 i = 2
    #                 while hahaha.index("*") - i != -1:
    #                     nima2 = hahaha[hahaha.index("*") - i] + nima2
    #                     i += 1
    #                 nima2 = float(nima2)
    #                 zonghe = hahaha[len(hahaha) - 1]
    #                 i = 2
    #                 while hahaha[len(hahaha) - i] != "=":
    #                     zonghe = hahaha[len(hahaha) - i] + nima
    #                     i += 1
    #                 zonghe = int(zonghe)
    #                 for i in range(int(round(zonghe / nima,0))):
    #                     if zonghe - i * nima % nima2 == 0:
    #                         list1.append(i)
    #                         list1.append(int((zonghe - i / nima) / nima2))
    #                 return list1
    #             nima = hahaha[hahaha.index("*") - 1]
    #             i = 2
    #             while hahaha.index("*") - i != -1:
    #                 nima = hahaha[hahaha.index("*") - i] + nima
    #                 i += 1
    #             nima = float(nima)
    #             hahaha = hahaha.replace(str(nima) + "*x+","")
    #             nima2 = hahaha[hahaha.index("*") - 1]
    #             i = 2
    #             while hahaha.index("*") - i != -1:
    #                 nima2 = hahaha[hahaha.index("*") - i] + nima2
    #                 i += 1
    #             nima2 = float(nima2)
    #             zonghe = hahaha[len(hahaha) - 1]
    #             i = 2
    #             while hahaha[len(hahaha) - i] != "=":
    #                 zonghe = hahaha[len(hahaha) - i] + nima
    #                 i += 1
    #             zonghe = int(zonghe)
    #             for i in range(int(round(zonghe / nima,0))):
    #                 if i * nima - zonghe % nima2 == 0:
    #                     list1.append(i)
    #                     list1.append(int((i / nima - zonghe) / nima2))
    #             return list1
    #         elif hahaha.count("/") == 1:
    #             if hahaha.index("*") > hahaha.index("/") and "+" in hahaha:
    #                 nima = hahaha[hahaha.index("+") - 1]
    #                 i = 2
    #                 while hahaha[hahaha.index("+") - i] != "/":
    #                     nima = hahaha[hahaha.index("+") - i] + nima
    #                     i += 1
    #                 nima = float(nima)
    #                 nima2 = hahaha[hahaha.index("=") - 1]
    #                 i = 2
    #                 while hahaha[hahaha.index("=") - i] != "/":
    #                     nima2 = hahaha[hahaha.index("=") - i] + nima2
    #                     i += 1
    #                 nima2 = float(nima2)
    #                 zonghe = hahaha[len(hahaha) - 1]
    #                 i = 2
    #                 while hahaha[len(hahaha) - i] != "=":
    #                     zonghe = hahaha[len(hahaha) - i] + nima
    #                     i += 1
    #                 zonghe = int(zonghe)
    #                 for i in range(zonghe * nima * nima2):
    #                     if i % nima == 0:
    #                         list1.append(i)
    #                         list1.append(int((zonghe - i / nima) * nima2))
    #                 return list1
    #     def yiyuanerci(a):
    #         x_x = a[a.index("x") - 1]
    #         i = 2
    #         while a.index("x") - i != -1:
    #             x_x = a[a.index("x") - i] + x_x
    #             i += 1
    #         a = a.replace(x_x + "x^2","")
    #         x_x2 = a[a.index("x") - 1]
    #         i = 2
    #         while a.index("x") - i != -1:
    #             x_x2 = a[a.index("x") - i] + x_x2
    #             i += 1
    #         a = a.replace(x_x2 + "x","")
    #         x_x3 = a[a.index("=") - 1]
    #         i = 2
    #         while a.index("=") - i != -1:
    #             x_x3 = a[a.index("=") - i] + x_x3
    #             i += 1
    #         x_x,x_x2,x_x3 = float(x_x),float(x_x2),float(x_x3)
    #         try:
    #             haha = (-x_x2 + sqrt(x_x2 ** 2 - 4 * x_x * x_x3)) / (2 * x_x)
    #             if haha % 1 == 0:
    #                 haha = int(haha)
    #             if "." in str(haha):
    #                 a = ""
    #                 i = 2
    #                 while haha.index(".") - i != -1:
    #                     a = str(haha)[haha.index(".") - i] + a
    #                     i += 1
    #                 if len(haha) - len(a) - 1 < 5:
    #                     haha = str(2 * x_x) + "分之" + str(-x_x2) + "+" + str(x_x2 ** 2 - 4 * x_x * x_x3) + "的平方根"
    #             ahah = (-x_x2 - sqrt(x_x2 ** 2 - 4 * x_x * x_x3)) / (2 * x_x)
    #             if ahah % 1 == 0:
    #                 ahah = int(ahah)
    #             if "." in str(ahah):
    #                 a = ""
    #                 i = 2
    #                 while ahah.index(".") - i != -1:
    #                     a = str(ahah)[ahah.index(".") - i] + a
    #                     i += 1
    #                 if len(ahah) - len(a) - 1 < 5:
    #                     ahah = str(2 * x_x) + "分之" + str(-x_x2) + "-" + str(x_x2 ** 2 - 4 * x_x * x_x3) + "的平方根"
    #             return "x=" + str(haha) + "和" + str(ahah)
    #         except:
    #             print("这个方程没有解！")
    #     def chunxunhuan(a):
    #         if a[0] == "0":
    #             nima = "9"
    #             for i in range(len(a) - 3):
    #                 nima = nima + "9"
    #             b = a[2]
    #             for i in range(3,len(a)):
    #                 b = b + a[i]
    #             b = int(b)
    #             a = int(nima)
    #             zuida = 0
    #             suyinshu.clear()
    #             if a % b == 0:
    #                 zuida = b
    #             elif b % a == 0:
    #                 zuida = a
    #             else:
    #                 d = a
    #                 e = b
    #                 list3.clear()
    #                 if d > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if d % 2 == 0:
    #                         o = d / 2
    #                     else:
    #                         o = (d - 1) / 2
    #                 for i in range(1,int(o + 1)):
    #                     if d % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             if i != 1:
    #                                 list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if d > e:
    #                         if e % 2 == 0:
    #                             o = e / 2
    #                         else:
    #                             o = (e - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = d / 2
    #                         else:
    #                             o = (d - 1) / 2
    #                     for i in range(2,int(o + 1)):
    #                         if d % i == 0 and e % i == 0:
    #                             if zhihe(i) == "N":
    #                                 suyinshu.append(i)
    #                                 list3.append(i)
    #                                 d = d / i
    #                                 e = e / i
    #                 d = 1
    #                 for i in range(len(suyinshu)):
    #                     if i != len(suyinshu) - 1:
    #                         d = d * suyinshu[i]
    #                     else:
    #                         zuida = suyinshu[i] * d
    #                 if zuida == 0:
    #                     zuida = 1
    #             return str(a // zuida) + "分之" + str(b // zuida)
    #         else:
    #             nima2 = a
    #             nima = "9"
    #             for i in range(len(a) - 2 - a.index(".")):
    #                 nima = nima + "9"
    #             b = a[a.index(".") + 1]
    #             for i in range(a.index(".") + 2,len(a)):
    #                 b = b + a[i]
    #             b = int(b)
    #             a = int(nima)
    #             zuida = 0
    #             suyinshu.clear()
    #             if a % b == 0:
    #                 zuida = b
    #             elif b % a == 0:
    #                 zuida = a
    #             else:
    #                 d = a
    #                 e = b
    #                 list3.clear()
    #                 if d > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if d % 2 == 0:
    #                         o = d / 2
    #                     else:
    #                         o = (d - 1) / 2
    #                 for i in range(1,int(o + 1)):
    #                     if d % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             if i != 1:
    #                                 list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if d > e:
    #                         if e % 2 == 0:
    #                             o = e / 2
    #                         else:
    #                             o = (e - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = d / 2
    #                         else:
    #                             o = (d - 1) / 2
    #                     for i in range(2,int(o + 1)):
    #                         if d % i == 0 and e % i == 0:
    #                             if zhihe(i) == "N":
    #                                 suyinshu.append(i)
    #                                 list3.append(i)
    #                                 d = d / i
    #                                 e = e / i
    #                 d = 1
    #                 for i in range(len(suyinshu)):
    #                     if i != len(suyinshu) - 1:
    #                         d = d * suyinshu[i]
    #                     else:
    #                         zuida = suyinshu[i] * d
    #                 if zuida == 0:
    #                     zuida = 1
    #             return str(nima2) + "又" + str(a // zuida) + "分之" + str(b // zuida)
    #     def find_all(data,s):
    #         r_list = []
    #         for i in range(len(data)):
    #             if data[i] == s:
    #                 break
    #             r_list.append(data[i])
    #         return r_list
    #     def bili(mode,a,bilishu):
    #         zuida = 0
    #         for i in bilishu:
    #             zuida += i
    #         zuida = a / zuida
    #         for i in range(len(bilishu)):
    #             bilishu[i] = bilishu[i] * zuida
    #         return bilishu
    #     def erjiedengcha(mode,shouxiang,dierxiang,gongcha,a):
    #         if mode == 1:
    #             if a == 1:
    #                 return shouxiang
    #             nima = dierxiang - shouxiang
    #             nima2 = shouxiang
    #             for i in range(a - 2):
    #                 nima2 += nima
    #                 nima += gongcha
    #             nima = nima2 + nima
    #             i = 0
    #             while True:
    #                 if not i < nima:
    #                     break
    #                 i += 1
    #             if nima - i == 0:
    #                 return int(nima)
    #             else:
    #                 return nima
    #         else:
    #             if a == shouxiang:
    #                 return 1
    #             nima = dierxiang - shouxiang
    #             nima2 = shouxiang
    #             i = 3
    #             while True:
    #                 nima2 += nima
    #                 nima += gongcha
    #                 if nima2 == a:
    #                     return i
    #                 if nima2 > a:
    #                     return "N"
    #                 i += 1
    #     def denbishulie(mode,shouxiang,gongbi,a):
    #         if mode == 1:
    #             return shouxiang * gongbi ** (a - 1)
    #         if mode == 2:
    #             if a == shouxiang:
    #                 return a
    #             else:
    #                 ia = shouxiang
    #                 ai = shouxiang * gongbi
    #                 i = 3
    #                 while True:
    #                     if i % 2 == 1:
    #                         ia = ai * gongbi
    #                     else:
    #                         ai = ia * gongbi
    #                     if ia == a or ai == a:
    #                         return i
    #                     if ia > a or ai > a:
    #                         return "N"
    #                     i += 1
    #     def dengchashulie(mode,shouxiang,gongcha,a):
    #         if mode == 1:
    #             nima = shouxiang + gongcha * (a - 1)
    #             if nima % 1 == 0:
    #                 return int(nima)
    #             else:
    #                 return nima
    #         if mode == 2:
    #             nima = (a - shouxiang) / gongcha + 1
    #             if nima % 1 == 0:
    #                 return int(nima)
    #             else:
    #                 return "N"
    #         elif mode == 3:
    #             nima = (shouxiang * 2 + gongcha * (a - 1)) * a / 2
    #             if nima % 1 == 0:
    #                 return int(nima)
    #             else:
    #                 return nima
    #     def feibonaqi(mode,a):
    #         if mode == "1":
    #             if a == 1:
    #                 return 1
    #             ia = 1
    #             ai = 1
    #             for i in range(a - 2):
    #                 if i % 2 == 0:
    #                     ia += ai
    #                 else:
    #                     ai += ia
    #             if i % 2 == 0:
    #                 return ia
    #             return ai
    #         else:
    #             if a == 1:
    #                 return 1
    #             else:
    #                 i = 3
    #                 ia = 1
    #                 ai = 1
    #                 while True:
    #                     if i % 2 == 1:
    #                         ia += ai
    #                     else:
    #                         ai += ia
    #                     if ia == a or ai == a:
    #                         return i
    #                     if ia > a or ai > a:
    #                         return "N"
    #                     i += 1
    #     def fenshudaxiao(a,b,c,d):
    #         zuida = 0
    #         suyinshu.clear()
    #         if a % b == 0:
    #             zuida = b
    #         elif b % a == 0:
    #             zuida = a
    #         else:
    #             z = a
    #             e = b
    #             list3.clear()
    #             if z > e:
    #                 if e % 2 == 0:
    #                     o = e / 2
    #                 else:
    #                     o = (e - 1) / 2 
    #             else:
    #                 if z % 2 == 0:
    #                     o = z / 2
    #                 else:
    #                     o = (z - 1) / 2
    #             for i in range(2,int(o + 1)):
    #                 if z % i == 0 and e % i == 0:
    #                     if zhihe(i) == "N":
    #                         suyinshu.append(i)
    #                         if i != 1:    
    #                             list3.append(i)
    #                         z = z / i
    #                         e = e / i
    #             while True:
    #                 if len(list3) == 0:
    #                     break
    #                 list3.clear()
    #                 if z > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if z % 2 == 0:
    #                         o = z / 2
    #                     else:
    #                         o = (z - 1) / 2
    #                 for i in range(2,int(o + 1)):
    #                     if z % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             list3.append(i)
    #                             z = z / i
    #                             e = e / i
    #             z = 1
    #             for i in range(len(suyinshu)):
    #                 if i != len(suyinshu) - 1:
    #                     d = d * suyinshu[i]
    #                 else:
    #                     zuida = suyinshu[i] * z
    #             if zuida == 0:
    #                 zuida = 1
    #         c = c * (b / zuida)
    #         d = d * (a / zuida)
    #         if c > d:
    #             return 1
    #         elif d > c:
    #             return 2
    #         else:
    #             return "="
    #     def zhihe(a):
    #         if a == 1 or a == 0:
    #             return "既不是素数也不是合数"
    #         if a != 2 and a % 2 == 0:
    #             return 2
    #         for i in range(2,int(a / 2)):
    #             if a == 2:
    #                 return "N"
    #             if a % i == 0:
    #                 return i
    #         return "N"
    #     def fenjie(a):
    #         suyinshu,d,sb,list3 = [],a,{},[]
    #         for i in range(2,d):
    #             if a % i == 0 and zhihe(i) == "N":
    #                 suyinshu.append(i)
    #                 list3.append(i)
    #                 d = d // i
    #         while len(list3) != 0:
    #             list3.clear()
    #             for j in range(2,int(d) + 1):
    #                 if d % j == 0 and zhihe(j) == "N":
    #                     suyinshu.append(j)
    #                     list3.append(j)
    #                     d = d / j
    #         if len(suyinshu) == 0:
    #             print("这是个质数！")
    #         else:
    #             for i in suyinshu:
    #                 if i not in sb:
    #                     sb[i] = suyinshu.count(i)
    #             nima3 = ""
    #             for nima in sb:
    #                 for i in range(sb[nima]):
    #                     nima3 = nima3 + str(nima) + "×"
    #             nima3 = nima3[:-1]
    #             return str(a) + "=" + nima3
    #     def common_factor(a,b):
    #         zuida = 0
    #         suyinshu.clear()
    #         if a % b == 0:
    #             return b
    #         if b % a == 0:
    #             return a
    #         d = a
    #         e = b
    #         list3.clear()
    #         if d > e:
    #             if e % 2 == 0:
    #                 o = e / 2
    #             else:
    #                 o = (e - 1) / 2 
    #         else:
    #             if d % 2 == 0:
    #                 o = d / 2
    #             else:
    #                 o = (d - 1) / 2
    #         for i in range(1,int(o + 1)):
    #             if d % i == 0 and e % i == 0:
    #                 if zhihe(i) == "N":
    #                     suyinshu.append(i)
    #                     if i != 1:
    #                         list3.append(i)
    #                     d = d / i
    #                     e = e / i
    #         while True:
    #             if len(list3) == 0:
    #                 break
    #             list3.clear()
    #             if d > e:
    #                 if e % 2 == 0:
    #                     o = e / 2
    #                 else:
    #                     o = (e - 1) / 2 
    #             else:
    #                 if d % 2 == 0:
    #                     o = d / 2
    #                 else:
    #                     o = (d - 1) / 2
    #             for i in range(2,int(o + 1)):
    #                 if d % i == 0 and e % i == 0:
    #                     if zhihe(i) == "N":
    #                         suyinshu.append(i)
    #                         list3.append(i)
    #                         d = d / i
    #                         e = e / i
    #         d = 1
    #         for i in range(len(suyinshu)):
    #             if i != len(suyinshu) - 1:
    #                 d = d * suyinshu[i]
    #             else:
    #                 zuida = suyinshu[i] * d
    #         if zuida == 0:
    #             zuida = 1
    #         return zuida  
    #     def zuixiao(a,b):
    #         zuida = 0
    #         suyinshu.clear()
    #         if a % b == 0:
    #             zuida = b
    #         elif b % a == 0:
    #             zuida = a
    #         else:
    #             d = a
    #             e = b
    #             list3.clear()
    #             if d > e:
    #                 if e % 2 == 0:
    #                     o = e / 2
    #                 else:
    #                     o = (e - 1) / 2 
    #             else:
    #                 if d % 2 == 0:
    #                     o = d / 2
    #                 else:
    #                     o = (d - 1) / 2
    #             for i in range(1,int(o + 1)):
    #                 if d % i == 0 and e % i == 0:
    #                     if zhihe(i) == "N":
    #                         suyinshu.append(i)
    #                         if i != 1:
    #                             list3.append(i)
    #                         d = d / i
    #                         e = e / i
    #             while True:
    #                 if len(list3) == 0:
    #                     break
    #                 list3.clear()
    #                 if d > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if d % 2 == 0:
    #                         o = d / 2
    #                     else:
    #                         o = (d - 1) / 2
    #                 for i in range(2,int(o + 1)):
    #                     if d % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #             d = 1
    #             for i in range(len(suyinshu)):
    #                 if i != len(suyinshu) - 1:
    #                     d = d * suyinshu[i]
    #                 else:
    #                     zuida = suyinshu[i] * d
    #             if zuida == 0:
    #                 zuida = 1
    #         return zuida * (a / zuida) * (b / zuida)
    #     def fenshuyunsuan(mode,a,b,c,d):
    #         if mode == "1":
    #             zuida = 0
    #             suyinshu.clear()
    #             if a % b == 0:
    #                 zuida = b
    #             elif b % a == 0:
    #                 zuida = a
    #             else:
    #                 z = a
    #                 e = b
    #                 list3.clear()
    #                 if z > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if z % 2 == 0:
    #                         o = z / 2
    #                     else:
    #                         o = (z - 1) / 2
    #                 for i in range(2,int(o + 1)):
    #                     if z % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             if i != 1:    
    #                                 list3.append(i)
    #                             z = z / i
    #                             e = e / i
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if z > e:
    #                         if e % 2 == 0:
    #                             o = e / 2
    #                         else:
    #                             o = (e - 1) / 2 
    #                     else:
    #                         if z % 2 == 0:
    #                             o = z / 2
    #                         else:
    #                             o = (z - 1) / 2
    #                     for i in range(2,int(o + 1)):
    #                         if z % i == 0 and e % i == 0:
    #                             if zhihe(i) == "N":
    #                                 suyinshu.append(i)
    #                                 list3.append(i)
    #                                 z = z / i
    #                                 e = e / i
    #                 z = 1
    #                 for i in range(len(suyinshu)):
    #                     if i != len(suyinshu) - 1:
    #                         d = d * suyinshu[i]
    #                     else:
    #                         zuida = suyinshu[i] * z
    #                 if zuida == 0:
    #                     zuida = 1
    #             e = zuida * (a / zuida) * (b / zuida)
    #             f = c * (b / zuida) + d * (a / zuida)
    #             zuida = 0
    #             suyinshu.clear()
    #             if e % f == 0:
    #                 zuida = f
    #             elif f % e == 0:
    #                 zuida = e
    #             else:
    #                 h = e
    #                 i = f
    #                 list3.clear()
    #                 if i > h:
    #                     if h % 2 == 0:
    #                         o = h / 2
    #                     else:
    #                         o = (h - 1) / 2 
    #                 else:
    #                     if i % 2 == 0:
    #                         o = i / 2
    #                     else:
    #                         o = (i - 1) / 2
    #                 for j in range(1,int(o + 1)):
    #                     if h % j == 0 and i % j == 0:
    #                         if zhihe(j) == "N":
    #                             suyinshu.append(j)
    #                             if j != 1:
    #                                 list3.append(j)
    #                             h = h / j
    #                             i = i / j
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if h > i:
    #                         if e % 2 == 0:
    #                             o = i / 2
    #                         else:
    #                             o = (i - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = h / 2
    #                         else:
    #                             o = (h - 1) / 2
    #                     for j in range(2,int(o + 1)):
    #                         if h % j == 0 and i % j == 0:
    #                             if zhihe(j) == "N":
    #                                 suyinshu.append(j)
    #                                 list3.append(j)
    #                                 h = h / j
    #                                 i = i / j
    #                 i = 1
    #                 for j in range(len(suyinshu)):
    #                     if j != len(suyinshu) - 1:
    #                         i = i * suyinshu[j]
    #                     else:
    #                         zuida = suyinshu[j] * i
    #                 if zuida == 0:
    #                     zuida = 1
    #             return str(int(e / zuida)) + "分之" + str(int(f / zuida))
    #         elif mode == "2":
    #             nima = fenshudaxiao(a,b,c,d)
    #             if nima == "=":
    #                 return 0
    #             else:
    #                 zuida = 0
    #                 suyinshu.clear()
    #                 if a % b == 0:
    #                     zuida = b
    #                 elif b % a == 0:
    #                     zuida = a
    #                 else:
    #                     z = a
    #                     e = b
    #                     list3.clear()
    #                     if z > e:
    #                         if e % 2 == 0:
    #                             o = e / 2
    #                         else:
    #                             o = (e - 1) / 2 
    #                     else:
    #                         if z % 2 == 0:
    #                             o = z / 2
    #                         else:
    #                             o = (z - 1) / 2
    #                     for i in range(1,int(o + 1)):
    #                         if z % i == 0 and e % i == 0:
    #                             if zhihe(i) == "N":
    #                                 suyinshu.append(i)
    #                                 if i != 1:
    #                                     list3.append(i)
    #                                 z = z / i
    #                                 e = e / i
    #                     while True:
    #                         if len(list3) == 0:
    #                             break
    #                         list3.clear()
    #                         if z > e:
    #                             if e % 2 == 0:
    #                                 o = e / 2
    #                             else:
    #                                 o = (e - 1) / 2 
    #                         else:
    #                             if z % 2 == 0:
    #                                 o = z / 2
    #                             else:
    #                                 o = (z - 1) / 2
    #                         for i in range(2,int(o + 1)):
    #                             if z % i == 0 and e % i == 0:
    #                                 if zhihe(i) == "N":
    #                                     suyinshu.append(i)
    #                                     list3.append(i)
    #                                     z = z / i
    #                                     e = e / i
    #                 z = 1
    #                 for i in range(len(suyinshu)):
    #                     if i != len(suyinshu) - 1:
    #                         d = d * suyinshu[i]
    #                     else:
    #                         zuida = suyinshu[i] * z
    #                 if zuida == 0:
    #                     zuida = 1
                    
    #                 e = zuida * (a / zuida) * (b / zuida)
    #                 f = c * (b / zuida) - d * (a / zuida)
    #                 zuida = 0
    #                 suyinshu.clear()
    #                 if e % f == 0:
    #                     zuida = f
    #                 elif f % e == 0:
    #                     zuida = e
    #                 else:
    #                     h = e
    #                     i = f
    #                     list3.clear()
    #                     if i > h:
    #                         if h % 2 == 0:
    #                             o = h / 2
    #                         else:
    #                             o = (h - 1) / 2 
    #                     else:
    #                         if i % 2 == 0:
    #                             o = i / 2
    #                         else:
    #                             o = (i - 1) / 2
    #                     for j in range(1,int(o + 1)):
    #                         if h % j == 0 and i % j == 0:
    #                             if zhihe(j) == "N":
    #                                 suyinshu.append(j)
    #                                 if j != 1:
    #                                     list3.append(j)
    #                                 h = h / j
    #                                 i = i / j
    #                     while True:
    #                         if len(list3) == 0:
    #                             break
    #                         list3.clear()
    #                         if h > i:
    #                             if e % 2 == 0:
    #                                 o = i / 2
    #                             else:
    #                                 o = (i - 1) / 2 
    #                         else:
    #                             if d % 2 == 0:
    #                                 o = h / 2
    #                             else:
    #                                 o = (h - 1) / 2
    #                         for j in range(2,int(o + 1)):
    #                             if h % j == 0 and i % j == 0:
    #                                 if zhihe(j) == "N":
    #                                     suyinshu.append(j)
    #                                     list3.append(j)
    #                                     h = h / j
    #                                     i = i / j
    #                     i = 1
    #                     for j in range(len(suyinshu)):
    #                         if j != len(suyinshu) - 1:
    #                             i = i * suyinshu[j]
    #                         else:
    #                             zuida = suyinshu[j] * i
    #                     if zuida == 0:
    #                         zuida = 1
    #                 return str(int(e / zuida)) + "分之" + str(int(f / zuida))
    #         if mode == "3":
    #             e = a * b
    #             f = c * d
    #             zuida = 0
    #             suyinshu.clear()
    #             if e % f == 0:
    #                 zuida = f
    #             elif f % e == 0:
    #                 zuida = e
    #             else:
    #                 h = e
    #                 i = f
    #                 list3.clear()
    #                 if i > h:
    #                     if h % 2 == 0:
    #                         o = h / 2
    #                     else:
    #                         o = (h - 1) / 2 
    #                 else:
    #                     if i % 2 == 0:
    #                         o = i / 2
    #                     else:
    #                         o = (i - 1) / 2
    #                 for j in range(1,int(o + 1)):
    #                     if h % j == 0 and i % j == 0:
    #                         if zhihe(j) == "N":
    #                             suyinshu.append(j)
    #                             if j != 1:
    #                                 list3.append(j)
    #                             h = h / j
    #                             i = i / j
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if h > i:
    #                         if e % 2 == 0:
    #                             o = i / 2
    #                         else:
    #                             o = (i - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = h / 2
    #                         else:
    #                             o = (h - 1) / 2
    #                     for j in range(2,int(o + 1)):
    #                         if h % j == 0 and i % j == 0:
    #                             if zhihe(j) == "N":
    #                                 suyinshu.append(j)
    #                                 list3.append(j)
    #                                 h = h / j
    #                                 i = i / j
    #                 i = 1
    #                 for j in range(len(suyinshu)):
    #                     if j != len(suyinshu) - 1:
    #                         i = i * suyinshu[j]
    #                     else:
    #                         zuida = suyinshu[j] * i
    #                 if zuida == 0:
    #                     zuida = 1
    #             return str(int(e / zuida)) + "分之" + str(int(f / zuida))
    #         if mode == "4":
    #             e = a * d
    #             f = b * c
    #             zuida = 0
    #             suyinshu.clear()
    #             if e % f == 0:
    #                 zuida = f
    #             elif f % e == 0:
    #                 zuida = e
    #             else:
    #                 h = e
    #                 i = f
    #                 list3.clear()
    #                 if i > h:
    #                     if h % 2 == 0:
    #                         o = h / 2
    #                     else:
    #                         o = (h - 1) / 2 
    #                 else:
    #                     if i % 2 == 0:
    #                         o = i / 2
    #                     else:
    #                         o = (i - 1) / 2
    #                 for j in range(1,int(o + 1)):
    #                     if h % j == 0 and i % j == 0:
    #                         if zhihe(j) == "N":
    #                             suyinshu.append(j)
    #                             if j != 1:
    #                                 list3.append(j)
    #                             h = h / j
    #                             i = i / j
    #                 while True:
    #                     if len(list3) == 0:
    #                         break
    #                     list3.clear()
    #                     if h > i:
    #                         if e % 2 == 0:
    #                             o = i / 2
    #                         else:
    #                             o = (i - 1) / 2 
    #                     else:
    #                         if d % 2 == 0:
    #                             o = h / 2
    #                         else:
    #                             o = (h - 1) / 2
    #                     for j in range(2,int(o + 1)):
    #                         if h % j == 0 and i % j == 0:
    #                             if zhihe(j) == "N":
    #                                 suyinshu.append(j)
    #                                 list3.append(j)
    #                                 h = h / j
    #                                 i = i / j
    #                 i = 1
    #                 for j in range(len(suyinshu)):
    #                     if j != len(suyinshu) - 1:
    #                         i = i * suyinshu[j]
    #                     else:
    #                         zuida = suyinshu[j] * i
    #                 if zuida == 0:
    #                     zuida = 1
    #             return str(int(e / zuida)) + "分子" + str(int(f / zuida))
    #     def fenshudagongyin(a,b,c,d):
    #         zuida = 0
    #         suyinshu.clear()
    #         if a % b == 0:
    #             zuida = b
    #         elif b % a == 0:
    #             zuida = a
    #         else:
    #             z = a
    #             e = b
    #             list3.clear()
    #             if z > e:
    #                 if e % 2 == 0:
    #                     o = e / 2
    #                 else:
    #                     o = (e - 1) / 2 
    #             else:
    #                 if z % 2 == 0:
    #                     o = z / 2
    #                 else:
    #                     o = (z - 1) / 2
    #             for i in range(2,int(o + 1)):
    #                 if z % i == 0 and e % i == 0:
    #                     if zhihe(i) == "N":
    #                         suyinshu.append(i)
    #                         if i != 1:    
    #                             list3.append(i)
    #                         z = z / i
    #                         e = e / i
    #             while True:
    #                 if len(list3) == 0:
    #                     break
    #                 list3.clear()
    #                 if z > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if z % 2 == 0:
    #                         o = z / 2
    #                     else:
    #                         o = (z - 1) / 2
    #                 for i in range(2,int(o + 1)):
    #                     if z % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             list3.append(i)
    #                             z = z / i
    #                             e = e / i
    #         z = 1
    #         for i in range(len(suyinshu)):
    #             if i != len(suyinshu) - 1:
    #                 d = d * suyinshu[i]
    #             else:
    #                 zuida = suyinshu[i] * z
    #         if zuida == 0:
    #             zuida = 1
    #         a1 = a * (b / zuida)
    #         b1 = a1
    #         c = c * (b / zuida)
    #         d = d * (a / zuida)
    #         zuida = 0
    #         suyinshu.clear()
    #         if c % d == 0:
    #             zuida = d
    #         elif d % c == 0:
    #             zuida = c
    #         else:
    #             h = c
    #             i = d
    #             list3.clear()
    #             if h > i:
    #                 if i % 2 == 0:
    #                     o = i / 2
    #                 else:
    #                     o = (i - 1) / 2 
    #             else:
    #                 if h % 2 == 0:
    #                     o = h / 2
    #                 else:
    #                     o = (h - 1) / 2
    #             for j in range(1,int(o + 1)):
    #                 if h % j == 0 and i % j == 0:
    #                     if zhihe(j) == "N":
    #                         suyinshu.append(j)
    #                         if j != 1:
    #                             list3.append(j)
    #                         h = h / j
    #                         i = i / j
    #             while True:
    #                 if len(list3) == 0:
    #                     break
    #                 list3.clear()
    #                 if h > i:
    #                     if i % 2 == 0:
    #                         o = i / 2
    #                     else:
    #                         o = (i - 1) / 2 
    #                 else:
    #                     if h % 2 == 0:
    #                         o = h / 2
    #                     else:
    #                         o = (h - 1) / 2
    #                 for j in range(2,int(o + 1)):
    #                     if h % j == 0 and i % j == 0:
    #                         if zhihe(j) == "N":
    #                             suyinshu.append(j)
    #                             list3.append(j)
    #                             h = h / j
    #                             i = i / j
    #             z = 1
    #             for j in range(len(suyinshu)):
    #                 if j != len(suyinshu) - 1:
    #                     z = z * suyinshu[j]
    #                 else:
    #                     zuida = suyinshu[j] * z
    #             if zuida == 0:
    #                 zuida = 1
    #         b = zuida
    #         zuida = 0
    #         suyinshu.clear()
    #         if a1 % b == 0:
    #             zuida = b
    #         elif b % a1 == 0:
    #             zuida = a1
    #         else:
    #             d = a1
    #             e = b
    #             list3.clear()
    #             if d > e:
    #                 if e % 2 == 0:
    #                     o = e / 2
    #                 else:
    #                     o = (e - 1) / 2 
    #             else:
    #                 if d % 2 == 0:
    #                     o = d / 2
    #                 else:
    #                     o = (d - 1) / 2
    #             for i in range(1,int(o + 1)):
    #                 if d % i == 0 and e % i == 0:
    #                     if zhihe(i) == "N":
    #                         suyinshu.append(i)
    #                         if i != 1:
    #                             list3.append(i)
    #                         d = d / i
    #                         e = e / i
    #             while True:
    #                 if len(list3) == 0:
    #                     break
    #                 list3.clear()
    #                 if d > e:
    #                     if e % 2 == 0:
    #                         o = e / 2
    #                     else:
    #                         o = (e - 1) / 2 
    #                 else:
    #                     if d % 2 == 0:
    #                         o = d / 2
    #                     else:
    #                         o = (d - 1) / 2
    #                 for i in range(2,int(o + 1)):
    #                     if d % i == 0 and e % i == 0:
    #                         if zhihe(i) == "N":
    #                             suyinshu.append(i)
    #                             list3.append(i)
    #                             d = d / i
    #                             e = e / i
    #             d = 1
    #             for i in range(len(suyinshu)):
    #                 if i != len(suyinshu) - 1:
    #                     d = d * suyinshu[i]
    #                 else:
    #                     zuida = suyinshu[i] * d
    #             if zuida == 0:
    #                 zuida = 1
    #         return str(a1 // zuida) + "分之" + str(b // zuida)
    #     def pingmianjihe(mode,a,b,c):
    #         if mode == "等边三角形":
    #             return sqrt(3) / 4 * a ** 2
    #         if mode == "梯形":
    #             return (a + b) * c / 2
    #         if mode == "三角形":
    #             return a * b / 2
    #         if mode == "圆形面积":
    #             return a ** 2 * 3.14
    #         if mode == "圆形周长":
    #             return a * 2 * 3.14
    #         if mode == "扇形面积":
    #             return a ** 2 * 3.14 / 360 * b
    #         if mode == "扇形周长":
    #             return 2 * a + a * 2 * 3.14 / 360 * b
    #         if mode == "长方形":
    #             return a * b
    #     def izhihe1():
    #         global izhihewin
    #         window.destroy()
    #         izhihewin = Tk()
    #         izhihewin.title("质数合数判断")
    #         izhihewin.geometry("400x300")
    #         wo = Label(izhihewin,text = "请输入要计算的数",width = 15)
    #         wo.pack(side = TOP)
    #         var1 = Entry(izhihewin)
    #         var1.pack(side = TOP,expand = True)
    #         def izhihe2():
    #             if "妈" in var1.get():
    #                 messagebox.showwarning("","我不是你妈，我是你爹！")
    #             else:
    #                 try:
    #                     if "妈" in var1.get():
    #                         messagebox.showwarning("","我不是你妈，我是你爹！")
    #                     else:
    #                         jieguo1 = zhihe(int(var1.get()))
    #                         if jieguo1 == "既不是素数也不是合数":
    #                             jiegu1 = "既不是素数也不是合数"
    #                         elif jieguo1 == "N":
    #                             jieguo1 = "是质数"
    #                         else:
    #                             jieguo1 = "是合数，因数：" + str(jieguo1)
    #                     messagebox.showwarning("",jieguo1)
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #         def sbsb1():
    #             izhihewin.destroy()
    #             main()
    #         izhihewin.protocol("WM_DELETE_WINDOW",sbsb1)
    #         Button(izhihewin,text = "计算",command = izhihe2).pack(fill = BOTH,side = TOP,expand = True)
    #         izhihewin.mainloop()

    #     def izuixiao1():
    #         global izuixiaowin
    #         window.destroy()
    #         izuixiaowin = Tk()
    #         izuixiaowin.title("最小公倍数")
    #         izuixiaowin.geometry("400x300")
    #         Label(izuixiaowin,text = "在此输入第一个数").pack(side = TOP,expand = True)
    #         var1 = Entry(izuixiaowin)
    #         var1.pack(side = TOP,expand = True)
    #         Label(izuixiaowin,text = "在此输入第二个数").pack(side = TOP,expand = True)
    #         var2 = Entry(izuixiaowin)
    #         var2.pack(side = TOP,expand = True)
    #         def izuixiao2():
    #             try:
    #                 jieguo1 = "最小公倍数是" + str(int(zuixiao(int(var1.get()),int(var2.get()))))
    #                 messagebox.showwarning("",jieguo1)
    #             except:
    #                 messagebox.showwarning("","请不要乱输")
    #         Button(izuixiaowin,text = "计算",command = izuixiao2).pack(fill = BOTH,side = BOTTOM,expand = True)
    #         def sbsb2():
    #             izuixiaowin.destroy()
    #             main()
    #         izuixiaowin.protocol("WM_DELETE_WINDOW",sbsb2)
    #         izuixiaowin.mainloop()
    #     def izuida1():
    #         global izuidawin
    #         window.destroy()
    #         izuidawin = Tk()
    #         izuidawin.title("最大公因数")
    #         izuidawin.geometry("400x300")
    #         Label(izuidawin,text = "在此输入第一个数").pack(side = TOP,expand = True)
    #         var1 = Entry(izuidawin)
    #         var1.pack(side = TOP,expand = True)
    #         Label(izuidawin,text = "在此输入第二个数").pack(side = TOP,expand = True)
    #         var2 = Entry(izuidawin)
    #         var2.pack(side = TOP,expand = True)
    #         def izuida2():
    #             try:
    #                 jieguo1 = "最大公因数是" + str(common_factor(int(var1.get()),int(var2.get())))
    #                 messagebox.showwarning("",jieguo1)
    #             except:
    #                 messagebox.showwarning("","请不要乱输")
    #         Button(izuidawin,text = "计算",command = izuida2).pack(fill = BOTH,side = BOTTOM,expand = True)
    #         def sbsb3():
    #             izuidawin.destroy()
    #             main()
    #         izuidawin.protocol("WM_DELETE_WINDOW",sbsb3)
    #         izuidawin.mainloop()
    #     def fenshu1():
    #         chooseuser = buttonbox(msg = "你要使用哪种运算？",title = "",choices = ["加法","减法","乘法","除法"])
    #         window.destroy()
    #         if chooseuser == "加法":
    #             global ijiafawin
    #             ijiafawin = Tk()
    #             ijiafawin.title("分数加法")
    #             ijiafawin.geometry("400x300")
    #             Label(ijiafawin,text = "在此输入第一个分数的分子").pack(expand = True)
    #             var1 = Entry(ijiafawin)
    #             var1.pack(expand = True)
    #             Label(ijiafawin,text = "在此输入第一个分数的分母").pack(expand = True)
    #             var2 = Entry(ijiafawin)
    #             var2.pack(expand = True)
    #             Label(ijiafawin,text = "在此输入第二个分数的分子").pack(expand = True)
    #             var3 = Entry(ijiafawin)
    #             var3.pack(expand = True)
    #             Label(ijiafawin,text = "在此输入第二个分数的分母").pack(expand = True)
    #             var4 = Entry(ijiafawin)
    #             var4.pack(expand = True)
    #             def ijiafa():
    #                 try:
    #                     jieguo1 = fenshuyunsuan("1",int(var2.get()),int(var4.get()),int(var1.get()),int(var3.get()))
    #                     jieguo1 = "运算结果是" + str(jieguo1)
    #                     messagebox.showwarning("",jieguo1)
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(ijiafawin,text = "计算",command = ijiafa).pack(fill = BOTH,side = BOTTOM,expand = True)
    #             def sbsb4():
    #                 ijiafawin.destroy()
    #                 main()
    #             ijiafawin.protocol("WM_DELETE_WINDOW",sbsb4)
    #             ijiafawin.mainloop()
    #         elif chooseuser == "减法":
    #             global ijianfawin
    #             ijianfawin = Tk()
    #             ijianfawin.title("分数减法")
    #             ijianfawin.geometry("400x300")
    #             Label(ijianfawin,text = "在此输入被减数的分子").pack(expand = True)
    #             var1 = Entry(ijianfawin)
    #             var1.pack(expand = True)
    #             Label(ijianfawin,text = "在此输入被减数的分母").pack(expand = True)
    #             var2 = Entry(ijianfawin)
    #             var2.pack(expand = True)
    #             Label(ijianfawin,text = "在此输入减数的分子").pack(expand = True)
    #             var3 = Entry(ijianfawin)
    #             var3.pack(expand = True)
    #             Label(ijianfawin,text = "在此输入减数的分母").pack(expand = True)
    #             var4 = Entry(ijianfawin)
    #             var4.pack(expand = True)
    #             def ijianfa():
    #                 try:
    #                     jieguo1 = fenshuyunsuan("2",int(var2.get()),int(var4.get()),int(var1.get()),int(var3.get()))
    #                     jieguo1 = "运算结果是" + str(jieguo1)
    #                     messagebox.showwarning("",jieguo1)
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(ijianfawin,text = "计算",command = ijianfa).pack(fill = BOTH,side = BOTTOM,expand = True)
    #             def sbsb5():
    #                 ijianfawin.destroy()
    #                 main()
    #             ijianfawin.protocol("WM_DELETE_WINDOW",sbsb5)
    #             ijianfawin.mainloop()
    #         elif chooseuser == "乘法":
    #             global ichengfawin
    #             ichengfawin = Tk()
    #             ichengfawin.title("分数乘法")
    #             ichengfawin.geometry("400x300")
    #             Label(ichengfawin,text = "在此输入第一个分数的分子").pack(expand = True)
    #             var1 = Entry(ichengfawin)
    #             var1.pack(expand = True)
    #             Label(ichengfawin,text = "在此输入第一个分数的分母").pack(expand = True)
    #             var2 = Entry(ichengfawin)
    #             var2.pack(expand = True)
    #             Label(ichengfawin,text = "在此输入第二个分数的分子").pack(expand = True)
    #             var3 = Entry(ichengfawin)
    #             var3.pack(expand = True)
    #             Label(ichengfawin,text = "在此输入第二个分数的分母").pack(expand = True)
    #             var4 = Entry(ichengfawin)
    #             var4.pack(expand = True)
    #             def ichengfa():
    #                 try:
    #                     jieguo1 = fenshuyunsuan("3",int(var2.get()),int(var4.get()),int(var1.get()),int(var3.get()))
    #                     jieguo1 = "运算结果是" + str(jieguo1)
    #                     messagebox.showwarning("",jieguo1)
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(ichengfawin,text = "计算",command = ichengfa).pack(fill = BOTH,side = BOTTOM,expand = True)
    #             def sbsb6():
    #                 ichengfawin.destroy()
    #                 main()
    #             ichengfawin.protocol("WM_DELETE_WINDOW",sbsb6)
    #             ichengfawin.mainloop()
    #         elif chooseuser == "除法":
    #             global ichufawin
    #             ichufawin = Tk()
    #             ichufawin.title("分数除法")
    #             ichufawin.geometry("400x300")
    #             Label(ichufawin,text = "在此输入被除数的分子").pack(expand = True)
    #             var1 = Entry(ichufawin)
    #             var1.pack(expand = True)
    #             Label(ichufawin,text = "在此输入被除数的分母").pack(expand = True)
    #             var2 = Entry(ichufawin)
    #             var2.pack(expand = True)
    #             Label(ichufawin,text = "在此输入除数的分子").pack(expand = True)
    #             var3 = Entry(ichufawin)
    #             var3.pack(expand = True)
    #             Label(ichufawin,text = "在此输入除数的分母").pack(expand = True)
    #             var4 = Entry(ichufawin)
    #             var4.pack(expand = True)
    #             def ichufa():
    #                 try:
    #                     jieguo1 = fenshuyunsuan("4",int(var2.get()),int(var4.get()),int(var1.get()),int(var3.get()))
    #                     jieguo1 = "运算结果是" + jieguo1
    #                     messagebox.showwarning("",jieguo1)
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(ichufawin,text = "计算",command = ichufa).pack(fill = BOTH,side = BOTTOM,expand = True)
    #             def sbsb7():
    #                 ichufawin.destroy()
    #                 main()
    #             ichufawin.protocol("WM_DELETE_WINDOW",sbsb7)
    #             ichufawin.mainloop()
    #         else:
    #             main()
    #     def fenshu():
    #         global ifenshuwin
    #         window.destroy()
    #         ifenshuwin = Tk()
    #         ifenshuwin.title("分数比较大小")
    #         ifenshuwin.geometry("400x300")
    #         Label(ifenshuwin,text = "请输入第一个分数的分子").pack(expand = True)
    #         var1 = Entry(ifenshuwin)
    #         var1.pack()
    #         Label(ifenshuwin,text = "请输入第一个分数的分母").pack(expand = True)
    #         var2 = Entry(ifenshuwin)
    #         var2.pack()
    #         Label(ifenshuwin,text = "请输入第二个分数的分子").pack(expand = True)
    #         var3 = Entry(ifenshuwin)
    #         var3.pack()
    #         Label(ifenshuwin,text = "请输入第二个分数的分母").pack(expand = True)
    #         var4 = Entry(ifenshuwin)
    #         var4.pack()
    #         def bijiao():
    #             try:
    #                 jieguo1 = fenshudaxiao(int(var2.get()),int(var4.get()),int(var1.get()),int(var3.get()))
    #                 if jieguo1 == 1:
    #                     messagebox.showwarning("",var2.get() + "分之" + var1.get() + "大")
    #                 elif jieguo1 == 2:
    #                     messagebox.showwarning("",var4.get() + "分之" + var3.get() + "大")
    #                 else:
    #                     messagebox.showwarning("两个数一样大")
    #             except:
    #                 messagebox.showwarning("请不要乱输")
    #         Button(ifenshuwin,text = "计算",command = bijiao).pack(fill = BOTH,side = BOTTOM)
    #         def sbsb8():
    #             ifenshuwin.destroy()
    #             main()
    #         ifenshuwin.protocol("WM_DELETE_WINDOW",sbsb8)
    #         ifenshuwin.mainloop()
    #     def ifeibonaqi():
    #         chooseuser = buttonbox(msg = "你要用哪个功能",title = "",choices = ["求某一项","求某个数是第几项"])
    #         window.destroy()
    #         if chooseuser == "求某一项":
    #             global feibowin1
    #             feibowin1 = Tk()
    #             feibowin1.geometry("400x300")
    #             feibowin1.title("求斐波那契数列的某一项")
    #             Label(feibowin1,text = "你想求第").pack(fill = BOTH,side = TOP,expand = True)
    #             var1 = Entry(feibowin1)
    #             var1.pack(fill = BOTH,side = TOP,expand = True)
    #             Label(feibowin1,text = "项").pack(fill = BOTH,side = TOP,expand = True)
    #             def ifeibo1():
    #                 try:
    #                     messagebox.showwarning("","第" + var1.get() + "项是" + str(feibonaqi("1",int(var1.get()))))
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(feibowin1,text = "计算",command = ifeibo1).pack(fill = BOTH,side = BOTTOM)
    #             def sbsb9():
    #                 feibowin1.destroy()
    #             feibowin1.protocol("WM_DELETE_WINDOW",sbsb9)
    #             feibowin1.mainloop()
    #         elif chooseuser == "求某个数是第几项":
    #             global feibowin2
    #             feibowin2 = Tk()
    #             feibowin2.geometry("400x300")
    #             feibowin2.title("求某个数在数列中的位置")
    #             Label(feibowin2,text = "你想求").pack(side = TOP)
    #             var1 = Entry(feibowin2)
    #             var1.pack(side = TOP,expand = True)
    #             Label(feibowin2,text = "在斐波那契数列中的位置").pack(side = TOP)
    #             def ifeibo2():
    #                 try:
    #                     jieguo1 = feibonaqi("2",int(var1.get()))
    #                     if jieguo1 == "N":
    #                         messagebox.showwarning("","这个数不在斐波那契数列中！")
    #                     else:
    #                         messagebox.showwarning("",var1.get() + "是第" + str(jieguo1) + "项")
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(feibowin2,text = "计算",command = ifeibo2).pack(fill = BOTH,side = BOTTOM)
    #             def sbsb10():
    #                 feibowin2.destroy()
    #                 main()
    #             feibowin2.protocol("WM_DELETE_WINDOW",sbsb10)
    #             feibowin2.mainloop()
    #         else:
    #             main()
    #     def dengcha():
    #         chooseuser = buttonbox(msg = "你要哪个功能？",title = "",choices = ["求某一项","求某个数的位置","求和"])
    #         window.destroy()
    #         if chooseuser == "求某一项":
    #             global dengchawin1
    #             dengchawin1 = Tk()
    #             dengchawin1.title("求等差数列的某一项")
    #             dengchawin1.geometry("400x300")
    #             Label(dengchawin1,text = "在此输入首项").pack()
    #             var1 = Entry(dengchawin1)
    #             var1.pack()
    #             Label(dengchawin1,text = "在此输入公差").pack()
    #             var2 = Entry(dengchawin1)
    #             var2.pack()
    #             Label(dengchawin1,text = "你想求第几项？").pack()
    #             var3 = Entry(dengchawin1)
    #             var3.pack()
    #             def idengcha1():
    #                 try:
    #                     messagebox.showwarning("","第" + var3.get() + "项是" + str(dengchashulie(1,int(var1.get()),int(var2.get()),int(var3.get()))))
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(dengchawin1,text = "计算",command = idengcha1).pack(fill = BOTH,side = BOTTOM)
    #             def sbsb11():
    #                 dengchawin1.destroy()
    #                 main()
    #             dengchawin1.protocol("WM_DELETE_WINDOW",sbsb11)
    #             dengchawin1.mainloop()
    #         elif chooseuser == "求某个数的位置":
    #             global dengchawin2
    #             dengchawin2 = Tk()
    #             dengchawin2.title("求某个数在等差数列的位置")
    #             dengchawin2.geometry("400x300")
    #             Label(dengchawin2,text = "请输入首项").pack()
    #             var1 = Entry(dengchawin2)
    #             var1.pack()
    #             Label(dengchawin2,text = "请输入公差").pack()
    #             var2 = Entry(dengchawin2)
    #             var2.pack()
    #             Label(dengchawin2,text = "你想求哪个数的位置？").pack()
    #             var3 = Entry(dengchawin2)
    #             var3.pack()
    #             def idengcha2():
    #                 try:
    #                     jieguo1 = dengchashulie(2,int(var1.get()),int(var2.get()),int(var3.get()))
    #                     if jieguo1 == "N":
    #                         messagebox.showwarning("","这个数不在等差数列中！")
    #                     else:
    #                         messagebox.showwarning("",var3.get() + "是第" + str(jieguo1) + "项")
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             Button(dengchawin2,text = "计算",command = idengcha2).pack(fill = BOTH,side = BOTTOM)
    #             def sbsb12():
    #                 dengchawin2.destroy()
    #                 main()
    #             dengchawin2.protocol("WM_DELETE_WINDOW",sbsb12)
    #             dengchawin2.mainloop()
    #         elif chooseuser == "求和":
    #             global dengchawin3
    #             dengchawin3 = Tk()
    #             dengchawin3.title("等差数列求和")
    #             dengchawin3.geometry("400x300")
    #             Label(dengchawin3,text = "请输入首项").pack()
    #             var1 = Entry(dengchawin3)
    #             var1.pack()
    #             Label(dengchawin3,text = "请输入公差").pack()
    #             var2 = Entry(dengchawin3)
    #             var2.pack()
    #             Label(dengchawin3,text = "请输入项数").pack()
    #             var3 = Entry(dengchawin3)
    #             var3.pack()
    #             def idengcha3():
    #                 try:
    #                     jieguo1 = dengchashulie(3,int(var1.get()),int(var2.get()),int(var3.get()))
    #                     messagebox.showwarning("","等差数列值和是" + str(jieguo1))
    #                 except:
    #                     messagebox.showwarning("","请不要乱输")
    #             def sbsb13():
    #                 dengchawin3.destroy()
    #                 main()
    #             dengchawin3.protocol("WM_DELETE_WINDOW",sbsb13)
    #             Button(dengchawin3,text = "计算",command = idengcha3).pack(fill = BOTH,side = BOTTOM)        
    #             dengchawin3.mainloop()
    #         else:
    #             main()
    #     def size():
    #         global sizewin
    #         window.destroy()
    #         sizewin = Tk()
    #         sizewin.title("四则运算")
    #         sizewin.geometry("400x300")
    #         var1 = Entry(sizewin)
    #         Label(sizewin,text = "在此输入算式").pack()
    #         var1.pack()
    #         def jj():
    #             try:
    #                 a = var1.get()
    #                 if "^" in a:
    #                     a = a.replace("^","**")
    #                 messagebox.showwarning("","运算结果为" + str(eval(a)))
    #             except:
    #                 messagebox.showwarning("","请不要乱输")
    #         def sbsb14():
    #             sizewin.destroy()
    #             main()
    #         sizewin.protocol("WM_DELETE_WINDOW",sbsb14)
    #         Button(sizewin,text = "计算",command = jj).pack(side = BOTTOM)
    #         sizewin.mainloop()
    #     afsd = {
    #     "质数合数判断":izhihe1,
    #     "最大公因数（整数）":izuida1,
    #     "最小公倍数（整数）":izuixiao1,
    #     "分数运算":fenshu1,
    #     "分数比较大小":fenshu,
    #     "斐波那契数列计算":ifeibonaqi,
    #     "等差数列":dengcha,
    #     "四则运算":size
    #     }
    #     def main():
    #         global window
    #         window = Tk()
    #         window.title("数学作业神器")
    #         window.geometry("400x300")
    #         window.iconbitmap("金星.ico")
    #         for k in afsd:
    #             Button(window,text = k,command = afsd[k]).pack(fill = BOTH,side = TOP,expand = True)
    #         def fanhui():
    #             if messagebox.askokcancel("确定退出？","您确定要退出？（关闭主窗口后所有窗口将关闭）"):
    #                 window.destroy()
    #                 fasdasdf1()
    #         window.protocol("WM_DELETE_WINDOW",fanhui)
    #         window.mainloop()
    #     main()
    elif dakai == "huatu":
        messagebox.showinfo("提示","该功能维护中，暂不开放")
        fasdasdf1()
        # def fasdasdf():
        #     mainwin.destroy()
        #     fasdasdf1()
        # choose = buttonbox(msg = "你要使用哪种画图",title = "",choices = ["函数画图","折线统计图"])
        # if choose == "折线统计图":
        #     global s
        #     mainwin = Tk()
        #     mainwin.title("Night Star画图器")
        #     mainwin.geometry("400x500")
        #     mainwin.iconbitmap("金星.ico")
        #     def lj(q):
        #         mod = q % 10
        #         if mod == 0:
        #             return q
        #         elif q > 0:
        #             i = 1
        #             while i * 10 < q:
        #                 i += 1
        #             return i * 10
        #         else:
        #             i = -1
        #             while i * 10 > q:
        #                 i -= 1
        #             return (i + 1) * 10
        #     def jl(q):
        #         mod = q % 10
        #         if mod == 0:
        #             return q
        #         elif q > 0:
        #             i = 1
        #             while i * 10 < q:
        #                 i += 1
        #             return (i - 1) * 10
        #         else:
        #             i = -1
        #             while i * 10 > q:
        #                 i -= 1
        #             return i * 10
        #     try:
        #         sq = []
        #         s = Label(mainwin,text = "在次输入第1个元素")
        #         var = Entry(mainwin,widt = 20)
        #         var.place(x = 150,y = 150,anchor = "center")
        #         s.pack()
        #         def a0458():
        #             global s
        #             sq.append(int(var.get()))
        #             s.forget()
        #             s = Label(mainwin,text = "在此输入第" + str(len(sq) + 1) + "个元素")
        #             s.pack()
        #         Button(mainwin,text = "添加",command = a0458).place(x = 300,y = 150,anchor = "center")
        #         def hua():
        #             plt.plot(sq)
        #             plt.axis([0,len(sq) - 1,jl(min(sq)),lj(max(sq))])
        #             plt.show()
        #         Button(mainwin,text = "画图",command = hua).place(x = 200,y = 425,anchor = "center")
        #         mainwin.protocol("WM_DELETE_WINDOW",fasdasdf)
        #         mainwin.mainloop()
        #     except:
        #         messagebox.showerror("","matplotlib库未安装")
        # elif choose == "函数画图":
        #     mainwin = Tk()
        #     mainwin.title("Night Star画图器")
        #     mainwin.geometry("400x500")
        #     mainwin.iconbitmap("金星.ico")
        #     Label(mainwin,text = "y=").place(x = 125,y = 100,anchor = "center")
        #     var = Entry(mainwin,width = 2)
        #     var.place(x = 150,y = 100,anchor = "center")
        #     Label(mainwin,text = "x²+").place(x = 175,y = 100,anchor = "center")
        #     var2 = Entry(mainwin,width = 2)
        #     var2.place(x = 200,y = 100,anchor = "center")
        #     Label(mainwin,text = "x+").place(x = 225,y = 100,anchor = "center")
        #     var3 = Entry(mainwin,width = 2)
        #     var3.place(x = 250,y = 100,anchor = "center")
        #     def hua():
        #         x = np.arange(-10,11)
        #         y = int(var.get()) * x ** 2 + int(var2.get()) * x + int(var3.get())
        #         plt.plot(x,y)
        #         plt.xlabel("x")
        #         plt.ylabel("y")
        #         plt.show()
        #     Button(mainwin,text = "画图",command = hua).pack(side = BOTTOM)
        #     mainwin.protocol("WM_DELETE_WINDOW",fasdasdf)
        #     mainwin.mainloop()
        # else:
        #     fasdasdf1()
    elif dakai == "qq":
        app = wx.App(False)  # Create a new app, don't redirect stdout/stderr to a window.  
        liaotianwin = wx.Frame(None, wx.ID_ANY, "聊天机器人") # A Frame is a top-level window.  
        liaotianwin.Show(True)
        global aba
        var = wx.TextCtrl(liaotianwin,size = (200,20),pos = (100,15))
        import json
        import requests

        api_url = "http://openapi.tuling123.com/openapi/api/v2"
        def huifu(event):
            global aba,first
            try:
                if first:
                    wx.StaticText(liaotianwin, label='聊天机器人的回复',pos = (100,50))
                    first = False
            except:
                wx.StaticText(liaotianwin, label='聊天机器人的回复',pos = (100,50))
                first = False
            data = {
                "reqType": 0,
                "perception":
                {
                    "inputText":
                    {
                        "text": var.GetValue()
                    },
                    # 可选参数
                    # "inputImage": {
                    #     "url": "imageUrl"
                    # },
                    # 可选参数
                    # "selfInfo":
                    # {
                    #     "location":
                    #     {
                    #         "city": "上海",
                    #         "province": "上海",
                    #         "street": "文汇路"
                    #     }
                    #  }
                },
                "userInfo":
                {
                    "apiKey": "57e8a35bf9f349a1bb49f2da6d48d518",
                    "userId": "586065"
                }
            }   
            data = json.dumps(data).encode('utf8')
            response_str = requests.post(api_url, data=data, headers={'content-type': 'application/json'})
            response_dic = response_str.json()
            # print('返回结果：' + response_str.text)
            results_text = response_dic['results'][0]['values']['text']
            try:
                aba.forget()
            except:
                pass
            aba = wx.StaticText(liaotianwin,label = results_text,pos = (100,50))
            
        btn = wx.Button(liaotianwin,label = "确定",pos = (300,10))
        btn.Bind(wx.EVT_BUTTON, huifu)
        app.MainLoop()
        fasdasdf1()
    elif dakai == "bmi":
        bmi = Tk()
        bmi.title("Night Star System")  # 设置标题
        bmi.geometry("400x300")
        Label(bmi, text="请输入你的体重（公斤kg为单位）").pack(expand=True)
        var = Entry(bmi)
        var.pack(expand=True)
        Label(bmi, text="请输入你的身高（厘米cm为单位）").pack(expand=True)
        var1 = Entry(bmi)
        var1.pack(expand=True)
        def jj():
            try:
                a = float(var.get())
                jie = a * 10000 / (float(var1.get()) ** 2)
                messagebox.showinfo("", "你的健康指数是" + str(jie))
                if jie < 18.5:
                    messagebox.showwarning("", "<18.5  偏瘦(建议多吃饭，保持营养均衡)")
                elif jie <= 23.9:
                    messagebox.showinfo("", ">=18.5~<=23.9  健康(坚持下去)")
                else:
                    messagebox.showwarning("", ">23.9  肥胖(管住嘴，迈开腿)")
            except:
                messagebox.showwarning("", "再乱输头给你拧歪了")

        Button(bmi, text="计算", command=jj).pack()
        bmi.mainloop()
    elif dakai == "wuziqi":
        
        Chessman = namedtuple('Chessman', 'Name Value Color')
        Point = namedtuple('Point', 'X Y')

        BLACK_CHESSMAN = Chessman('黑子', 1, (50, 50, 50))
        WHITE_CHESSMAN = Chessman('白子', 2, (220, 220, 220))

        offset = [(1, 0), (0, 1), (1, 1), (1, -1),(-1, 1)]


        class Checkerboard:
            def __init__(self, line_points):
                self._line_points = line_points
                self._checkerboard = [[0] * line_points for _ in range(line_points)]

            def _get_checkerboard(self):
                return self._checkerboard

            checkerboard = property(_get_checkerboard)

            # 判断是否可落子
            def can_drop(self, point):
                return self._checkerboard[point.Y][point.X] == 0

            def drop(self, chessman, point):
                """
                落子
                :param chessman:
                :param point:落子位置
                :return:若该子落下之后即可获胜，则返回获胜方，否则返回 None
                """
                 
                print(f'{chessman.Name} ({point.X}, {point.Y})')
                self._checkerboard[point.Y][point.X] = chessman.Value

                 
                if self._win(point):
                    print(f'{chessman.Name}获胜')
                    return chessman

             
            def _win(self, point):
                cur_value = self._checkerboard[point.Y][point.X]
                for os in offset:
                    if self._get_count_on_direction(point, cur_value, os[0], os[1]):
                        return True

             
            def _get_count_on_direction(self, point, value, x_offset, y_offset):
                count = 1
                for step in range(1, 5):
                    x = point.X + step * x_offset
                    y = point.Y + step * y_offset
                    if 0 <= x < self._line_points and 0 <= y < self._line_points and self._checkerboard[y][x] == value:
                        count += 1
                    else:
                        break
                for step in range(1, 5):
                    x = point.X - step * x_offset
                    y = point.Y - step * y_offset
                    if 0 <= x < self._line_points and 0 <= y < self._line_points and self._checkerboard[y][x] == value:
                        count += 1
                    else:
                        break

                return count >= 5


        SIZE = 30  
        Line_Points = 19   
        Outer_Width = 20  
        Border_Width = 4 
        Inside_Width = 4  
        Border_Length = SIZE * (Line_Points - 1) + Inside_Width * 2 + Border_Width  
        Start_X = Start_Y = Outer_Width + int(Border_Width / 2) + Inside_Width  
        SCREEN_HEIGHT = SIZE * (Line_Points - 1) + Outer_Width * 2 + Border_Width + Inside_Width * 2  
        SCREEN_WIDTH = SCREEN_HEIGHT + 200  

        Stone_Radius = SIZE // 2 - 3  
        Stone_Radius2 = SIZE // 2 + 3
        Checkerboard_Color = (0xE3, 0x92, 0x65)  
        BLACK_COLOR = (0, 0, 0)
        WHITE_COLOR = (255, 255, 255)
        RED_COLOR = (200, 30, 30)
        BLUE_COLOR = (30, 30, 200)

        RIGHT_INFO_POS_X = SCREEN_HEIGHT + Stone_Radius2 * 2 + 10


        def print_text(screen, font, x, y, text, fcolor=(255, 255, 255)):
            imgText = font.render(text, True, fcolor)
            screen.blit(imgText, (x, y))


        def main():
            pygame.init()
            screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.display.set_caption('五子棋')

            font1 = pygame.font.SysFont('SimHei', 32)  
            font2 = pygame.font.SysFont('SimHei', 72)  
            fwidth, fheight = font2.size('黑方获胜')

            checkerboard = Checkerboard(Line_Points)
            cur_runner = BLACK_CHESSMAN
            winner = None
            computer = AI(Line_Points, WHITE_CHESSMAN)

         
            black_win_count = 0
            white_win_count = 0

            while True:
                for event in pygame.event.get():
                    if event.type == QUIT:
                        pygame.quit()
                        fasdasdf1()
                    elif event.type == KEYDOWN  :
                        if winner is None:
                            print("清空")
                            time.sleep(0.5)
                            white_win_count += 1
                        winner = None
                        cur_runner = BLACK_CHESSMAN
                        checkerboard = Checkerboard(Line_Points)
                        computer = AI(Line_Points, WHITE_CHESSMAN)
                    elif event.type == pygame.MOUSEBUTTONDOWN:  
                        if winner is None:  
                            pressed_array = pygame.mouse.get_pressed()
                            if pressed_array[0]:
                                mouse_pos = pygame.mouse.get_pos()
                                click_point = _get_clickpoint(mouse_pos)
                                if click_point is not None:   
                                    if checkerboard.can_drop(click_point):
                                        winner = checkerboard.drop(cur_runner, click_point)
                                        if winner is None:   
                                             
                                            cur_runner = _get_next(cur_runner)
                                            computer.get_opponent_drop(click_point)
                                            AI_point = computer.AI_drop()
                                            winner = checkerboard.drop(cur_runner, AI_point)
                                            if winner is not None:
                                                white_win_count += 1
                                            cur_runner = _get_next(cur_runner)
                                        else:
                                            black_win_count += 1
                                else:
                                    print('超出棋盘区域')

          
                _draw_checkerboard(screen)

                for i, row in enumerate(checkerboard.checkerboard):
                    for j, cell in enumerate(row):
                        if cell == BLACK_CHESSMAN.Value:
                            _draw_chessman(screen, Point(j, i), BLACK_CHESSMAN.Color)
                        elif cell == WHITE_CHESSMAN.Value:
                            _draw_chessman(screen, Point(j, i), WHITE_CHESSMAN.Color)

                _draw_left_info(screen, font1, cur_runner, black_win_count, white_win_count)

                if winner:
                    print_text(screen, font2, (SCREEN_WIDTH - fwidth) // 2, (SCREEN_HEIGHT - fheight) // 2, winner.Name + '获胜',
                               RED_COLOR)

                pygame.display.flip()


        def _get_next(cur_runner):
            if cur_runner == BLACK_CHESSMAN:
                return WHITE_CHESSMAN
            else:
                return BLACK_CHESSMAN



        def _draw_checkerboard(screen):
           
            screen.fill(Checkerboard_Color)
            
            pygame.draw.rect(screen, BLACK_COLOR, (Outer_Width, Outer_Width, Border_Length, Border_Length), Border_Width)
            
            for i in range(Line_Points):
                pygame.draw.line(screen, BLACK_COLOR,
                                 (Start_Y, Start_Y + SIZE * i),
                                 (Start_Y + SIZE * (Line_Points - 1), Start_Y + SIZE * i),
                                 1)
            for j in range(Line_Points):
                pygame.draw.line(screen, BLACK_COLOR,
                                 (Start_X + SIZE * j, Start_X),
                                 (Start_X + SIZE * j, Start_X + SIZE * (Line_Points - 1)),
                                 1)
          
            for i in (3, 9, 15):
                for j in (3, 9, 15):
                    if i == j == 9:
                        radius = 5
                    else:
                        radius = 3
                     
                    pygame.gfxdraw.aacircle(screen, Start_X + SIZE * i, Start_Y + SIZE * j, radius, BLACK_COLOR)
                    pygame.gfxdraw.filled_circle(screen, Start_X + SIZE * i, Start_Y + SIZE * j, radius, BLACK_COLOR)


         
        def _draw_chessman(screen, point, stone_color):
            # pygame.draw.circle(screen, stone_color, (Start_X + SIZE * point.X, Start_Y + SIZE * point.Y), Stone_Radius)
            pygame.gfxdraw.aacircle(screen, Start_X + SIZE * point.X, Start_Y + SIZE * point.Y, Stone_Radius, stone_color)
            pygame.gfxdraw.filled_circle(screen, Start_X + SIZE * point.X, Start_Y + SIZE * point.Y, Stone_Radius, stone_color)


         
        def _draw_left_info(screen, font, cur_runner, black_win_count, white_win_count):
            _draw_chessman_pos(screen, (SCREEN_HEIGHT + Stone_Radius2, Start_X + Stone_Radius2), BLACK_CHESSMAN.Color)
            _draw_chessman_pos(screen, (SCREEN_HEIGHT + Stone_Radius2, Start_X + Stone_Radius2 * 4), WHITE_CHESSMAN.Color)

            print_text(screen, font, RIGHT_INFO_POS_X, Start_X + 3, '玩家', BLUE_COLOR)
            print_text(screen, font, RIGHT_INFO_POS_X, Start_X + Stone_Radius2 * 3 + 3, '电脑', BLUE_COLOR)

            print_text(screen, font, SCREEN_HEIGHT, SCREEN_HEIGHT - Stone_Radius2 * 8, '战况：', BLUE_COLOR)
            _draw_chessman_pos(screen, (SCREEN_HEIGHT + Stone_Radius2, SCREEN_HEIGHT - int(Stone_Radius2 * 4.5)),
                               BLACK_CHESSMAN.Color)
            _draw_chessman_pos(screen, (SCREEN_HEIGHT + Stone_Radius2, SCREEN_HEIGHT - Stone_Radius2 * 2), WHITE_CHESSMAN.Color)
            print_text(screen, font, RIGHT_INFO_POS_X, SCREEN_HEIGHT - int(Stone_Radius2 * 5.5) + 3, f'{black_win_count} 胜',
                       BLUE_COLOR)
            print_text(screen, font, RIGHT_INFO_POS_X, SCREEN_HEIGHT - Stone_Radius2 * 3 + 3, f'{white_win_count} 胜',
                       BLUE_COLOR)


        def _draw_chessman_pos(screen, pos, stone_color):
            pygame.gfxdraw.aacircle(screen, pos[0], pos[1], Stone_Radius2, stone_color)
            pygame.gfxdraw.filled_circle(screen, pos[0], pos[1], Stone_Radius2, stone_color)



        def _get_clickpoint(click_pos):
            pos_x = click_pos[0] - Start_X
            pos_y = click_pos[1] - Start_Y
            if pos_x < -Inside_Width or pos_y < -Inside_Width:
                return None
            x = pos_x // SIZE
            y = pos_y // SIZE
            if pos_x % SIZE > Stone_Radius:
                x += 1
            if pos_y % SIZE > Stone_Radius:
                y += 1
            if x >= Line_Points or y >= Line_Points:
                return None

            return Point(x, y)


        class AI:
            def __init__(self, line_points, chessman):
                self._line_points = line_points
                self._my = chessman
                self._opponent = BLACK_CHESSMAN if chessman == WHITE_CHESSMAN else WHITE_CHESSMAN
                self._checkerboard = [[0] * line_points for _ in range(line_points)]

            def get_opponent_drop(self, point):
                self._checkerboard[point.Y][point.X] = self._opponent.Value

            def AI_drop(self):
                point = None
                score = 0
                for i in range(self._line_points):
                    for j in range(self._line_points):
                        if self._checkerboard[j][i] == 0:
                            _score = self._get_point_score(Point(i, j))
                            if _score > score:
                                score = _score
                                point = Point(i, j)
                            elif _score == score:
                                score = _score
                                r = random.randint(0, 20)
                                if r % 2 == 0:
                                    point = Point(i, j)
                self._checkerboard[point.Y][point.X] = self._my.Value
                return point

            def _get_point_score(self, point):
                score = 0
                for os in offset:
                    score += self._get_direction_score(point, os[0], os[1])
                return score

            def _get_direction_score(self, point, x_offset, y_offset):
                count = 0  
                _count = 0  
                space = None   
                _space = None   
                both = 0  
                _both = 0   

                 
                flag = self._get_stone_color(point, x_offset, y_offset, True)
                if flag != 0:
                    for step in range(1, 6):
                        x = point.X + step * x_offset
                        y = point.Y + step * y_offset
                        if 0 <= x < self._line_points and 0 <= y < self._line_points:
                            if flag == 1:
                                if self._checkerboard[y][x] == self._my.Value:
                                    count += 1
                                    if space is False:
                                        space = True
                                elif self._checkerboard[y][x] == self._opponent.Value:
                                    _both += 1
                                    break
                                else:
                                    if space is None:
                                        space = False
                                    else:
                                        break   
                            elif flag == 2:
                                if self._checkerboard[y][x] == self._my.Value:
                                    _both += 1
                                    break
                                elif self._checkerboard[y][x] == self._opponent.Value:
                                    _count += 1
                                    if _space is False:
                                        _space = True
                                else:
                                    if _space is None:
                                        _space = False
                                    else:
                                        break
                        else:
                             
                            if flag == 1:
                                both += 1
                            elif flag == 2:
                                _both += 1

                if space is False:
                    space = None
                if _space is False:
                    _space = None

                _flag = self._get_stone_color(point, -x_offset, -y_offset, True)
                if _flag != 0:
                    for step in range(1, 6):
                        x = point.X - step * x_offset
                        y = point.Y - step * y_offset
                        if 0 <= x < self._line_points and 0 <= y < self._line_points:
                            if _flag == 1:
                                if self._checkerboard[y][x] == self._my.Value:
                                    count += 1
                                    if space is False:
                                        space = True
                                elif self._checkerboard[y][x] == self._opponent.Value:
                                    _both += 1
                                    break
                                else:
                                    if space is None:
                                        space = False
                                    else:
                                        break   
                            elif _flag == 2:
                                if self._checkerboard[y][x] == self._my.Value:
                                    _both += 1
                                    break
                                elif self._checkerboard[y][x] == self._opponent.Value:
                                    _count += 1
                                    if _space is False:
                                        _space = True
                                else:
                                    if _space is None:
                                        _space = False
                                    else:
                                        break
                        else:
                             
                            if _flag == 1:
                                both += 1
                            elif _flag == 2:
                                _both += 1

                
                score = 0
                if count == 4:
                    score = 10000
                elif _count == 4:
                    score = 9000
                elif count == 3:
                    if both == 0:
                        score = 1000
                    elif both == 1:
                        score = 100
                    else:
                        score = 0
                elif _count == 3:
                    if _both == 0:
                        score = 900
                    elif _both == 1:
                        score = 90
                    else:
                        score = 0
                elif count == 2:
                    if both == 0:
                        score = 100
                    elif both == 1:
                        score = 10
                    else:
                        score = 0
                elif _count == 2:
                    if _both == 0:
                        score = 90
                    elif _both == 1:
                        score = 9
                    else:
                        score = 0
                elif count == 1:
                    score = 10
                elif _count == 1:
                    score = 9
                else:
                    score = 0

                if space or _space:
                    score /= 2
                return score
            def _get_stone_color(self, point, x_offset, y_offset, next):
                x = point.X + x_offset
                y = point.Y + y_offset
                if 0 <= x < self._line_points and 0 <= y < self._line_points:
                    if self._checkerboard[y][x] == self._my.Value:
                        return 1
                    elif self._checkerboard[y][x] == self._opponent.Value:
                        return 2
                    else:
                        if next:
                            return self._get_stone_color(Point(x, y), x_offset, y_offset, False)
                        else:
                            return 0
                else:
                    return 0
        if __name__ == '__main__':
            print("-------------------------------")
            main()


    elif dakai == "minecraft":


        # 每秒帧数
        TICKS_PER_SEC = 120

        # 你可以走的大小
        SECTOR_SIZE =5000

        # 行走速度与飞行速度
        WALKING_SPEED = 5.5
        FLYING_SPEED = 15

        # 重力与跳跃高度
        GRAVITY = 20
        MAX_JUMP_HEIGHT =1

        # About the height of a block.
        # To derive the formula for calculating jump speed, first solve
        #    v_t = v_0 + a * t
        # for the time at which you achieve maximum height, where a is the acceleration
        # due to gravity and v_t = 0. This gives:
        #    t = - v_0 / a
        # Use t and the desired MAX_JUMP_HEIGHT to solve for v_0 (jump speed) in
        #    s = s_0 + v_0 * t + (a * t^2) / 2
        JUMP_SPEED = math.sqrt(2 * GRAVITY * MAX_JUMP_HEIGHT)
        TERMINAL_VELOCITY = 50

        PLAYER_HEIGHT = 2

        if sys.version_info[0] >= 3:
            xrange = range

        def cube_vertices(x, y, z, n):
            """ Return the vertices of the cube at position x, y, z with size 2*n.

            """
            return [
                x-n,y+n,z-n, x-n,y+n,z+n, x+n,y+n,z+n, x+n,y+n,z-n,  # top
                x-n,y-n,z-n, x+n,y-n,z-n, x+n,y-n,z+n, x-n,y-n,z+n,  # bottom
                x-n,y-n,z-n, x-n,y-n,z+n, x-n,y+n,z+n, x-n,y+n,z-n,  # left
                x+n,y-n,z+n, x+n,y-n,z-n, x+n,y+n,z-n, x+n,y+n,z+n,  # right
                x-n,y-n,z+n, x+n,y-n,z+n, x+n,y+n,z+n, x-n,y+n,z+n,  # front
                x+n,y-n,z-n, x-n,y-n,z-n, x-n,y+n,z-n, x+n,y+n,z-n,  # back
            ]


        def tex_coord(x, y, n=4):
            """ 
            Return the bounding vertices of the texture square.

            """
            m = 1.0 / n
            dx = x * m
            dy = y * m
            return dx, dy, dx + m, dy, dx + m, dy + m, dx, dy + m


        def tex_coords(top, bottom, side):
            """ 
            Return a list of the texture squares for the top, bottom and side.

            """
            top = tex_coord(*top)
            bottom = tex_coord(*bottom)
            side = tex_coord(*side)
            result = []
            result.extend(top)
            result.extend(bottom)
            result.extend(side * 4)
            return result


        TEXTURE_PATH = 'texture.png'

        GRASS = tex_coords((1, 0), (0, 1), (0, 0))
        SAND = tex_coords((1, 1), (1, 1), (1, 1))
        BRICK = tex_coords((2, 0), (2, 0), (2, 0))
        STONE = tex_coords((2, 1), (2, 1), (2, 1))
        PURPLE = tex_coords((3, 1), (3, 1), (3, 1))
        RED = tex_coords((3, 0), (3, 0), (3, 0))
        GREEN = tex_coords((3, 2), (3, 2), (3, 2))
        BLUE = tex_coords((1, 2), (1, 2), (1, 2))
        BLACK = tex_coords((2, 2), (2, 2), (2, 2))
        ORANGE = tex_coords((3, 2), (3, 2), (3, 2))

        FACES = [
            ( 0, 1, 0),
            ( 0,-1, 0),
            (-1, 0, 0),
            ( 1, 0, 0),
            ( 0, 0, 1),
            ( 0, 0,-1),
        ]


        def normalize(position):
            """ Accepts `position` of arbitrary precision and returns the block
            containing that position.

            Parameters
            ----------
            position : tuple of len 3

            Returns
            -------
            block_position : tuple of ints of len 3

            """
            x, y, z = position
            x, y, z = (int(round(x)), int(round(y)), int(round(z)))
            return (x, y, z)


        def sectorize(position):
            """ Returns a tuple representing the sector for the given `position`.

            Parameters
            ----------
            position : tuple of len 3

            Returns
            -------
            sector : tuple of len 3

            """
            x, y, z = normalize(position)
            x, y, z = x // SECTOR_SIZE, y // SECTOR_SIZE, z // SECTOR_SIZE
            return (x, 0, z)


        class Model(object):

            def __init__(self):

                # A Batch is a collection of vertex lists for batched rendering.
                self.batch = pyglet.graphics.Batch()

                # A TextureGroup manages an OpenGL texture.
                self.group = TextureGroup(image.load(TEXTURE_PATH).get_texture())

                # A mapping from position to the texture of the block at that position.
                # This defines all the blocks that are currently in the world.
                self.world = {}

                # Same mapping as `world` but only contains blocks that are shown.
                self.shown = {}

                # Mapping from position to a pyglet `VertextList` for all shown blocks.
                self._shown = {}

                # Mapping from sector to a list of positions inside that sector.
                self.sectors = {}

                # Simple function queue implementation. The queue is populated with
                # _show_block() and _hide_block() calls
                self.queue = deque()

                self._initialize()

            def _initialize(self):
                """ Initialize the world by placing all the blocks.

                """
                n = 200 # 1/2 width and height of world
                s = 1  # step size
                y =0   # initial y height
                for x in xrange(-n, n + 1, s):
                    for z in xrange(-n, n + 1, s):
                        # create a layer stone an grass everywhere.
                        self.add_block((x, y - 2, z), GRASS, immediate=False)
                        self.add_block((x, y - 3, z), STONE, immediate=False)
                        if x in (-n, n) or z in (-n, n):
                            # create outer walls.
                            for dy in xrange(-2, 3):
                                self.add_block((x, y + dy, z), STONE, immediate=False)

                # generate the hills randomly
                o = n -15
                for _ in xrange(120):
                    a = random.randint(-o, o)  # x position of the hill
                    b = random.randint(-o, o)  # z position of the hill
                    c = -1  # base of the hill
                    h = random.randint(2,6) # height of the hill
                    s = random.randint(4,12)  # 2 * s is the side length of the hill
                    d = 1  # how quickly to taper off the hills
                    t = random.choice([GRASS, SAND,STONE])
                    for y in xrange(c, c + h):
                        for x in xrange(a - s, a + s + 1):
                            for z in xrange(b - s, b + s + 1):
                                if (x - a) ** 2 + (z - b) ** 2 > (s + 1) ** 2:
                                    continue
                                if (x - 0) ** 2 + (z - 0) ** 2 < 5 ** 2:
                                    continue
                                self.add_block((x, y, z), t, immediate=False)
                        s -= d  # decrement side lenth so hills taper off

            def hit_test(self, position, vector, max_distance=8):
                """ Line of sight search from current position. If a block is
                intersected it is returned, along with the block previously in the line
                of sight. If no block is found, return None, None.

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position to check visibility from.
                vector : tuple of len 3
                    The line of sight vector.
                max_distance : int
                    How many blocks away to search for a hit.

                """
                m = 8
                x, y, z = position
                dx, dy, dz = vector
                previous = None
                for _ in xrange(max_distance * m):
                    key = normalize((x, y, z))
                    if key != previous and key in self.world:
                        return key, previous
                    previous = key
                    x, y, z = x + dx / m, y + dy / m, z + dz / m
                return None, None

            def exposed(self, position):
                """ Returns False is given `position` is surrounded on all 6 sides by
                blocks, True otherwise.

                """
                x, y, z = position
                for dx, dy, dz in FACES:
                    if (x + dx, y + dy, z + dz) not in self.world:
                        return True
                return False

            def add_block(self, position, texture, immediate=True):
                """ Add a block with the given `texture` and `position` to the world.

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position of the block to add.
                texture : list of len 3
                    The coordinates of the texture squares. Use `tex_coords()` to
                    generate.
                immediate : bool
                    Whether or not to draw the block immediately.

                """
                if position in self.world:
                    self.remove_block(position, immediate)
                self.world[position] = texture
                self.sectors.setdefault(sectorize(position), []).append(position)
                if immediate:
                    if self.exposed(position):
                        self.show_block(position)
                    self.check_neighbors(position)

            def remove_block(self, position, immediate=True):
                """ Remove the block at the given `position`.

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position of the block to remove.
                immediate : bool
                    Whether or not to immediately remove block from canvas.

                """
                del self.world[position]
                self.sectors[sectorize(position)].remove(position)
                if immediate:
                    if position in self.shown:
                        self.hide_block(position)
                    self.check_neighbors(position)

            def check_neighbors(self, position):
                """ Check all blocks surrounding `position` and ensure their visual
                state is current. This means hiding blocks that are not exposed and
                ensuring that all exposed blocks are shown. Usually used after a block
                is added or removed.

                """
                x, y, z = position
                for dx, dy, dz in FACES:
                    key = (x + dx, y + dy, z + dz)
                    if key not in self.world:
                        continue
                    if self.exposed(key):
                        if key not in self.shown:
                            self.show_block(key)
                    else:
                        if key in self.shown:
                            self.hide_block(key)

            def show_block(self, position, immediate=True):
                """ Show the block at the given `position`. This method assumes the
                block has already been added with add_block()

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position of the block to show.
                immediate : bool
                    Whether or not to show the block immediately.

                """
                texture = self.world[position]
                self.shown[position] = texture
                if immediate:
                    self._show_block(position, texture)
                else:
                    self._enqueue(self._show_block, position, texture)

            def _show_block(self, position, texture):
                """ Private implementation of the `show_block()` method.

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position of the block to show.
                texture : list of len 3
                    The coordinates of the texture squares. Use `tex_coords()` to
                    generate.

                """
                x, y, z = position
                vertex_data = cube_vertices(x, y, z, 0.5)
                texture_data = list(texture)
                # create vertex list
                # FIXME Maybe `add_indexed()` should be used instead
                self._shown[position] = self.batch.add(24, GL_QUADS, self.group,
                    ('v3f/static', vertex_data),
                    ('t2f/static', texture_data))

            def hide_block(self, position, immediate=True):
                """ Hide the block at the given `position`. Hiding does not remove the
                block from the world.

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position of the block to hide.
                immediate : bool
                    Whether or not to immediately remove the block from the canvas.

                """
                self.shown.pop(position)
                if immediate:
                    self._hide_block(position)
                else:
                    self._enqueue(self._hide_block, position)

            def _hide_block(self, position):
                """ Private implementation of the 'hide_block()` method.

                """
                self._shown.pop(position).delete()

            def show_sector(self, sector):
                """ Ensure all blocks in the given sector that should be shown are
                drawn to the canvas.

                """
                for position in self.sectors.get(sector, []):
                    if position not in self.shown and self.exposed(position):
                        self.show_block(position, False)

            def hide_sector(self, sector):
                """ Ensure all blocks in the given sector that should be hidden are
                removed from the canvas.

                """
                for position in self.sectors.get(sector, []):
                    if position in self.shown:
                        self.hide_block(position, False)

            def change_sectors(self, before, after):
                """ Move from sector `before` to sector `after`. A sector is a
                contiguous x, y sub-region of world. Sectors are used to speed up
                world rendering.

                """
                before_set = set()
                after_set = set()
                pad = 4
                for dx in xrange(-pad, pad + 1):
                    for dy in [0]:  # xrange(-pad, pad + 1):
                        for dz in xrange(-pad, pad + 1):
                            if dx ** 2 + dy ** 2 + dz ** 2 > (pad + 1) ** 2:
                                continue
                            if before:
                                x, y, z = before
                                before_set.add((x + dx, y + dy, z + dz))
                            if after:
                                x, y, z = after
                                after_set.add((x + dx, y + dy, z + dz))
                show = after_set - before_set
                hide = before_set - after_set
                for sector in show:
                    self.show_sector(sector)
                for sector in hide:
                    self.hide_sector(sector)

            def _enqueue(self, func, *args):
                """ Add `func` to the internal queue.

                """
                self.queue.append((func, args))

            def _dequeue(self):
                """ Pop the top function from the internal queue and call it.

                """
                func, args = self.queue.popleft()
                func(*args)

            def process_queue(self):
                """ Process the entire queue while taking periodic breaks. This allows
                the game loop to run smoothly. The queue contains calls to
                _show_block() and _hide_block() so this method should be called if
                add_block() or remove_block() was called with immediate=False

                """
                # start = time.time
                # while self.queue and time.time < 1 / TICKS_PER_SEC:
                #     self._dequeue()
                pass
            def process_entire_queue(self):
                """ Process the entire queue with no breaks.

                """
                while self.queue:
                    self._dequeue()


        class Window(pyglet.window.Window):

            def __init__(self, *args, **kwargs):
                super(Window, self).__init__(*args, **kwargs)

                # Whether or not the window exclusively captures the mouse.
                self.exclusive = False

                # When flying gravity has no effect and speed is increased.
                self.flying = False

                # Strafing is moving lateral to the direction you are facing,
                # e.g. moving to the left or right while continuing to face forward.
                #
                # First element is -1 when moving forward, 1 when moving back, and 0
                # otherwise. The second element is -1 when moving left, 1 when moving
                # right, and 0 otherwise.
                self.strafe = [0, 0]

                # Current (x, y, z) position in the world, specified with floats. Note
                # that, perhaps unlike in math class, the y-axis is the vertical axis.
                self.position = (0, 0, 0)

                # First element is rotation of the player in the x-z plane (ground
                # plane) measured from the z-axis down. The second is the rotation
                # angle from the ground plane up. Rotation is in degrees.
                #
                # The vertical plane rotation ranges from -90 (looking straight down) to
                # 90 (looking straight up). The horizontal rotation range is unbounded.
                self.rotation = (0, 0)

                # Which sector the player is currently in.
                self.sector = None

                # The crosshairs at the center of the screen.
                self.reticle = None

                # Velocity in the y (upward) direction.
                self.dy = 0

                # A list of blocks the player can place. Hit num keys to cycle.
                self.inventory = [BRICK, GRASS, SAND,STONE,RED,PURPLE,GREEN,BLUE,BLACK,ORANGE]

                # The current block the user can place. Hit num keys to cycle.
                self.block = self.inventory[0]

                # Convenience list of num keys.
                self.num_keys = [
                    key._1, key._2, key._3, key._4, key._5,
                    key._6, key._7, key._8, key._9, key._0,key.E,key.R]

                # Instance of the model that handles the world.
                self.model = Model()

                # The label that is displayed in the top left of the canvas.
                self.label = pyglet.text.Label('', font_name='Arial', font_size=18,
                    x=10, y=self.height - 10, anchor_x='left', anchor_y='top',
                    color=(0, 0, 0, 255))

                # This call schedules the `update()` method to be called
                # TICKS_PER_SEC. This is the main game event loop.
                pyglet.clock.schedule_interval(self.update, 1.0 / TICKS_PER_SEC)

            def set_exclusive_mouse(self, exclusive):
                """ If `exclusive` is True, the game will capture the mouse, if False
                the game will ignore the mouse.

                """
                super(Window, self).set_exclusive_mouse(exclusive)
                self.exclusive = exclusive

            def get_sight_vector(self):
                """ Returns the current line of sight vector indicating the direction
                the player is looking.

                """
                x, y = self.rotation
                # y ranges from -90 to 90, or -pi/2 to pi/2, so m ranges from 0 to 1 and
                # is 1 when looking ahead parallel to the ground and 0 when looking
                # straight up or down.
                m = math.cos(math.radians(y))
                # dy ranges from -1 to 1 and is -1 when looking straight down and 1 when
                # looking straight up.
                dy = math.sin(math.radians(y))
                dx = math.cos(math.radians(x - 90)) * m
                dz = math.sin(math.radians(x - 90)) * m
                return (dx, dy, dz)

            def get_motion_vector(self):
                """ Returns the current motion vector indicating the velocity of the
                player.

                Returns
                -------
                vector : tuple of len 3
                    Tuple containing the velocity in x, y, and z respectively.

                """
                if any(self.strafe):
                    x, y = self.rotation
                    strafe = math.degrees(math.atan2(*self.strafe))
                    y_angle = math.radians(y)
                    x_angle = math.radians(x + strafe)
                    if self.flying:
                        m = math.cos(y_angle)
                        dy = math.sin(y_angle)
                        if self.strafe[1]:
                            # Moving left or right.
                            dy = 0.0
                            m = 1
                        if self.strafe[0] > 0:
                            # Moving backwards.
                            dy *= -1
                        # When you are flying up or down, you have less left and right
                        # motion.
                        dx = math.cos(x_angle) * m
                        dz = math.sin(x_angle) * m
                    else:
                        dy = 0.0
                        dx = math.cos(x_angle)
                        dz = math.sin(x_angle)
                else:
                    dy = 0.0
                    dx = 0.0
                    dz = 0.0
                return (dx, dy, dz)

            def update(self, dt):
                """ This method is scheduled to be called repeatedly by the pyglet
                clock.

                Parameters
                ----------
                dt : float
                    The change in time since the last call.

                """
                self.model.process_queue()
                sector = sectorize(self.position)
                if sector != self.sector:
                    self.model.change_sectors(self.sector, sector)
                    if self.sector is None:
                        self.model.process_entire_queue()
                    self.sector = sector
                m = 8
                dt = min(dt, 0.2)
                for _ in xrange(m):
                    self._update(dt / m)

            def _update(self, dt):
                """ Private implementation of the `update()` method. This is where most
                of the motion logic lives, along with gravity and collision detection.

                Parameters
                ----------
                dt : float
                    The change in time since the last call.

                """
                # walking
                speed = FLYING_SPEED if self.flying else WALKING_SPEED
                d = dt * speed # distance covered this tick.
                dx, dy, dz = self.get_motion_vector()
                # New position in space, before accounting for gravity.
                dx, dy, dz = dx * d, dy * d, dz * d
                # gravity
                if not self.flying:
                    # Update your vertical speed: if you are falling, speed up until you
                    # hit terminal velocity; if you are jumping, slow down until you
                    # start falling.
                    self.dy -= dt * GRAVITY
                    self.dy = max(self.dy, -TERMINAL_VELOCITY)
                    dy += self.dy * dt
                # collisions
                x, y, z = self.position
                x, y, z = self.collide((x + dx, y + dy, z + dz), PLAYER_HEIGHT)
                self.position = (x, y, z)

            def collide(self, position, height):
                """ Checks to see if the player at the given `position` and `height`
                is colliding with any blocks in the world.

                Parameters
                ----------
                position : tuple of len 3
                    The (x, y, z) position to check for collisions at.
                height : int or float
                    The height of the player.

                Returns
                -------
                position : tuple of len 3
                    The new position of the player taking into account collisions.

                """
                # How much overlap with a dimension of a surrounding block you need to
                # have to count as a collision. If 0, touching terrain at all counts as
                # a collision. If .49, you sink into the ground, as if walking through
                # tall grass. If >= .5, you'll fall through the ground.
                pad = 0
                p = list(position)
                np = normalize(position)
                for face in FACES:  # check all surrounding blocks
                    for i in xrange(3):  # check each dimension independently
                        if not face[i]:
                            continue
                        # How much overlap you have with this dimension.
                        d = (p[i] - np[i]) * face[i]
                        if d < pad:
                            continue
                        for dy in xrange(height):  # check each height
                            op = list(np)
                            op[1] -= dy
                            op[i] += face[i]
                            if tuple(op) not in self.model.world:
                                continue
                            p[i] -= (d - pad) * face[i]
                            if face == (0, -1, 0) or face == (0, 1, 0):
                                # You are colliding with the ground or ceiling, so stop
                                # falling / rising.
                                self.dy = 0
                            break
                return tuple(p)

            def on_mouse_press(self, x, y, button, modifiers):
                """ Called when a mouse button is pressed. See pyglet docs for button
                amd modifier mappings.

                Parameters
                ----------
                x, y : int
                    The coordinates of the mouse click. Always center of the screen if
                    the mouse is captured.
                button : int
                    Number representing mouse button that was clicked. 1 = left button,
                    4 = right button.
                modifiers : int
                    Number representing any modifying keys that were pressed when the
                    mouse button was clicked.

                """
                if self.exclusive:
                    vector = self.get_sight_vector()
                    block, previous = self.model.hit_test(self.position, vector)
                    if (button == mouse.RIGHT) or \
                            ((button == mouse.LEFT) and (modifiers & key.MOD_CTRL)):
                        # ON OSX, control + left click = right click.
                        if previous:
                            self.model.add_block(previous, self.block)
                    elif button == pyglet.window.mouse.LEFT and block:
                        texture = self.model.world[block]
                        self.model.remove_block(block)
                else:
                    self.set_exclusive_mouse(True)

            def on_mouse_motion(self, x, y, dx, dy):
                """ Called when the player moves the mouse.

                Parameters
                ----------
                x, y : int
                    The coordinates of the mouse click. Always center of the screen if
                    the mouse is captured.
                dx, dy : float
                    The movement of the mouse.

                """
                if self.exclusive:
                    m = 0.15
                    x, y = self.rotation
                    x, y = x + dx * m, y + dy * m
                    y = max(-90, min(90, y))
                    self.rotation = (x, y)

            def on_key_press(self, symbol, modifiers):
                """ Called when the player presses a key. See pyglet docs for key
                mappings.

                Parameters
                ----------
                symbol : int
                    Number representing the key that was pressed.
                modifiers : int
                    Number representing any modifying keys that were pressed.

                """
                if symbol == key.W:
                    self.strafe[0] -= 1
                elif symbol == key.S:
                    self.strafe[0] += 1
                elif symbol == key.A:
                    self.strafe[1] -= 1
                elif symbol == key.D:
                    self.strafe[1] += 1
                elif symbol == key.SPACE:
                    if self.dy == 0:
                        self.dy = JUMP_SPEED
                elif symbol == key.ESCAPE:
                    self.set_exclusive_mouse(False)
                elif symbol == key.TAB:
                    self.flying = not self.flying
                elif symbol in self.num_keys:
                    index = (symbol - self.num_keys[0]) % len(self.inventory)
                    self.block = self.inventory[index]

            def on_key_release(self, symbol, modifiers):
                """ Called when the player releases a key. See pyglet docs for key
                mappings.

                Parameters
                ----------
                symbol : int
                    Number representing the key that was pressed.
                modifiers : int
                    Number representing any modifying keys that were pressed.

                """
                if symbol == key.W:
                    self.strafe[0] += 1
                elif symbol == key.S:
                    self.strafe[0] -= 1
                elif symbol == key.A:
                    self.strafe[1] += 1
                elif symbol == key.D:
                    self.strafe[1] -= 1


            def on_resize(self, width, height):
                """ Called when the window is resized to a new `width` and `height`.

                """
                # label
                self.label.y = height - 10
                # reticle
                if self.reticle:
                    self.reticle.delete()
                x, y = self.width // 2, self.height // 2
                n = 10
                self.reticle = pyglet.graphics.vertex_list(4,
                    ('v2i', (x - n, y, x + n, y, x, y - n, x, y + n))
                )

            def set_2d(self):
                """ Configure OpenGL to draw in 2d.

                """
                width, height = self.get_size()
                glDisable(GL_DEPTH_TEST)
                viewport = self.get_viewport_size()
                glViewport(0, 0, max(1, viewport[0]), max(1, viewport[1]))
                glMatrixMode(GL_PROJECTION)
                glLoadIdentity()
                glOrtho(0, max(1, width), 0, max(1, height), -1, 1)
                glMatrixMode(GL_MODELVIEW)
                glLoadIdentity()

            def set_3d(self):
                """ Configure OpenGL to draw in 3d.

                """
                width, height = self.get_size()
                glEnable(GL_DEPTH_TEST)
                viewport = self.get_viewport_size()
                glViewport(0, 0, max(1, viewport[0]), max(1, viewport[1]))
                glMatrixMode(GL_PROJECTION)
                glLoadIdentity()
                gluPerspective(65.0, width / float(height), 0.1, 60.0)
                glMatrixMode(GL_MODELVIEW)
                glLoadIdentity()
                x, y = self.rotation
                glRotatef(x, 0, 1, 0)
                glRotatef(-y, math.cos(math.radians(x)), 0, math.sin(math.radians(x)))
                x, y, z = self.position
                glTranslatef(-x, -y, -z)

            def on_draw(self):
                """ Called by pyglet to draw the canvas.

                """
                self.clear()
                self.set_3d()
                glColor3d(1, 1, 1)
                self.model.batch.draw()
                self.draw_focused_block()
                self.set_2d()
                self.draw_label()
                self.draw_reticle()

            def draw_focused_block(self):
                """ Draw black edges around the block that is currently under the
                crosshairs.

                """
                vector = self.get_sight_vector()
                block = self.model.hit_test(self.position, vector)[0]
                if block:
                    x, y, z = block
                    vertex_data = cube_vertices(x, y, z, 0.51)
                    glColor3d(0, 0, 0)
                    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                    pyglet.graphics.draw(24, GL_QUADS, ('v3f/static', vertex_data))
                    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

            def draw_label(self):
                """ Draw the label in the top left of the screen.

                """
                x, y, z = self.position
                self.label.text = '%02d (%.2f, %.2f, %.2f) %d / %d' % (
                    pyglet.clock.get_fps(), x, y, z,
                    len(self.model._shown), len(self.model.world))
                self.label.draw()

            def draw_reticle(self):
                """ Draw the crosshairs in the center of the screen.

                """
                glColor3d(0, 0, 0)
                self.reticle.draw(GL_LINES)


        def setup_fog():
            """ Configure the OpenGL fog properties.

            """
            # Enable fog. Fog "blends a fog color with each rasterized pixel fragment's
            # post-texturing color."
            glEnable(GL_FOG)
            # Set the fog color.
            glFogfv(GL_FOG_COLOR, (GLfloat * 4)(0.5, 0.69, 1.0, 0))
            # Say we have no preference between rendering speed and quality.
            glHint(GL_FOG_HINT, GL_DONT_CARE)
            # Specify the equation used to compute the blending factor.
            glFogi(GL_FOG_MODE, GL_LINEAR)
            # How close and far away fog starts and ends. The closer the start and end,
            # the denser the fog in the fog range.
            glFogf(GL_FOG_START, 20.0)
            glFogf(GL_FOG_END, 60.0)


        def setup():
            """ Basic OpenGL configuration.

            """
            # Set the color of "clear", i.e. the sky, in rgba.
            glClearColor(0.5, 0.69, 1.0, 1)
            # Enable culling (not rendering) of back-facing facets -- facets that aren't
            # visible to you.
            glEnable(GL_CULL_FACE)
            # Set the texture minification/magnification function to GL_NEAREST (nearest
            # in Manhattan distance) to the specified texture coordinates. GL_NEAREST
            # "is generally faster than GL_LINEAR, but it can produce textured images
            # with sharper edges because the transition between texture elements is not
            # as smooth."
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
            setup_fog()


        def main():
            window = Window(width=800, height=450, caption='Pyglet', resizable=True)
            # Hide the mouse cursor and prevent the mouse from leaving the window.
            window.set_exclusive_mouse(True)
            setup()
            pyglet.app.run()


        if __name__ == '__main__':
            main()
    elif dakai == "snake":
        #!/usr/bin/env python 
        # -*- coding:utf-8 -*- 
         
        """ 
        @version: v1.0 
        @author: Harp
        @contact: liutao25@baidu.com 
        @software: PyCharm 
        @file: MySnake.py 
        @time: 2018/1/15 0015 23:40 
        """
         
         

         
         
        def direction_check(moving_direction, change_direction):
          directions = [['up', 'down'], ['left', 'right']]
          if moving_direction in directions[0] and change_direction in directions[1]:
            return change_direction
          elif moving_direction in directions[1] and change_direction in directions[0]:
            return change_direction
          return moving_direction
         
         
        class Snake:
         
          colors = list(product([0, 64, 128, 192, 255], repeat=3))[1:-1]
         
          def __init__(self):
            self.map = {(x, y): 0 for x in range(32) for y in range(24)}
            self.body = [[100, 100], [120, 100], [140, 100]]
            self.head = [140, 100]
            self.food = []
            self.food_color = []
            self.moving_direction = 'right'
            self.speed = 4
            self.generate_food()
            self.game_started = False
         
          def check_game_status(self):
            if self.body.count(self.head) > 1:
              return True
            if self.head[0] < 0 or self.head[0] > 620 or self.head[1] < 0 or self.head[1] > 460:
              return True
            return False
         
          def move_head(self):
            moves = {
              'right': (20, 0),
              'up': (0, -20),
              'down': (0, 20),
              'left': (-20, 0)
            }
            step = moves[self.moving_direction]
            self.head[0] += step[0]
            self.head[1] += step[1]
         
          def generate_food(self):
            self.speed = len(self.body) // 16 if len(self.body) // 16 > 4 else self.speed
            for seg in self.body:
              x, y = seg
              self.map[x//20, y//20] = 1
            empty_pos = [pos for pos in self.map.keys() if not self.map[pos]]
            result = choice(empty_pos)
            self.food_color = list(choice(self.colors))
            self.food = [result[0]*20, result[1]*20]
         
         
        def main():
          key_direction_dict = {
            119: 'up', # W
            115: 'down', # S
            97: 'left', # A
            100: 'right', # D
            273: 'up', # UP
            274: 'down', # DOWN
            276: 'left', # LEFT
            275: 'right', # RIGHT
          }
         
          fps_clock = pygame.time.Clock()
          pygame.init()
          pygame.mixer.init()
          snake = Snake()
          sound = False
          if path.exists('eat.wav'):
            sound_wav = pygame.mixer.Sound("eat.wav")
            sound = True
          title_font = pygame.font.SysFont('arial', 32)
          welcome_words = title_font.render('Welcome to My Snake', True, (0, 0, 0), (255, 255, 255))
          tips_font = pygame.font.SysFont('arial', 24)
          start_game_words = tips_font.render('Click to Start Game', True, (0, 0, 0), (255, 255, 255))
          close_game_words = tips_font.render('Press ESC to Close', True, (0, 0, 0), (255, 255, 255))
          gameover_words = title_font.render('GAME OVER', True, (205, 92, 92), (255, 255, 255))
          win_words = title_font.render('THE SNAKE IS LONG ENOUGH AND YOU WIN!', True, (0, 0, 205), (255, 255, 255))
          screen = pygame.display.set_mode((640, 480), 0, 32)
          pygame.display.set_caption('My Snake')
          new_direction = snake.moving_direction
          while 1:
            for event in pygame.event.get():
              if event.type == QUIT:
                pygame.quit()
                fasdasdf1()
              elif event.type == KEYDOWN:
                if event.key == 27:
                  exit()
                if snake.game_started and event.key in key_direction_dict:
                  direction = key_direction_dict[event.key]
                  new_direction = direction_check(snake.moving_direction, direction)
              elif (not snake.game_started) and event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                if 213 <= x <= 422 and 304 <= y <= 342:
                  snake.game_started = True
            screen.fill((255, 255, 255))
            if snake.game_started:
              snake.moving_direction = new_direction # 在这里赋值，而不是在event事件的循环中赋值，避免按键太快
              snake.move_head()
              snake.body.append(snake.head[:])
              if snake.head == snake.food:
                if sound:
                  sound_wav.play()
                snake.generate_food()
              else:
                snake.body.pop(0)
              for seg in snake.body:
                pygame.draw.rect(screen, [0, 0, 0], [seg[0], seg[1], 20, 20], 0)
              pygame.draw.rect(screen, snake.food_color, [snake.food[0], snake.food[1], 20, 20], 0)
              if snake.check_game_status():
                screen.blit(gameover_words, (241, 310))
                pygame.display.update()
                snake = Snake()
                new_direction = snake.moving_direction
                sleep(3)
              elif len(snake.body) == 512:
                screen.blit(win_words, (33, 210))
                pygame.display.update()
                snake = Snake()
                new_direction = snake.moving_direction
                sleep(3)
            else:
              screen.blit(welcome_words, (188, 100))
              screen.blit(start_game_words, (236, 310))
              screen.blit(close_game_words, (233, 350))
            pygame.display.update()
            fps_clock.tick(snake.speed)
         
         
        if __name__ == '__main__':
          main()
    elif dakai == "eluosi":

        block_initial_position,score,times,gameover,press,all_block,background=[20,5],[0],0,[],False,[[[0,0],[0,-1],[0,1],[0,2]],[[0,0],[0,1],[-1,1],[-1,0]],[[0,0],[0,-1],[-1,0],[-1,1]],[[0,0],[0,1],[-1,-1],[-1,0]],[[0,0],[0,1],[1,0],[0,-1]],[[0,0],[1,0],[-1,0],[1,-1]],[[0,0],[1,0],[-1,0],[1,1]]],[[0 for column in range(0,10)]for row in range(0,22)]
        background[0],select_block=[1 for column in range(0,10)],list(random.choice(all_block))
        def move(n):
            if n==100:
                for row,column in select_block:
                    pygame.draw.rect(screen,(255,165,0),((column+block_initial_position[1])*40,800-(row+block_initial_position[0])*40,38,38))
                for row in range(0,20):
                    for column in range(0,10):
                        if background[row][column]:pygame.draw.rect(screen,(0,0,255),(column*40,800-row*40,38,38))
            y_drop,x_move=block_initial_position
            if n==1 or n==-1:
                x_move+=n
                for row,column in select_block:
                    if (column+x_move)<0 or (column+x_move)>9 or background[row+y_drop][column+x_move]:break
                else:block_initial_position.clear(),block_initial_position.extend([y_drop,x_move])
            if n==0:
                rotating_position=[(-column,row)for row,column in select_block]
                for row,column in rotating_position:
                    if (column+x_move)<0 or (column+x_move)>9 or background[row+y_drop][column+x_move]:break
                else:select_block.clear(),select_block.extend(rotating_position)
            if n==10:
                y_drop-=1
                for row,column in select_block:
                    if background[row+y_drop][column+x_move]==1:break
                else:
                    block_initial_position.clear()
                    block_initial_position.extend([y_drop,x_move])
                    return
                for row,column in select_block:background[block_initial_position[0]+row][block_initial_position[1]+column]=1
                complete_row=[]
                for row in range(1,21):
                    if 0 not in background[row]:complete_row.append(row)
                complete_row.sort(reverse=True)
                for row in complete_row:
                    background.pop(row)
                    background.append([0 for column in range(0,10)])
                score[0]+=len(complete_row)
                pygame.display.set_caption('Tetris,Score:'+str(score[0])+' Robin5')
                select_block.clear(),select_block.extend(list(random.choice(all_block)))
                block_initial_position.clear(),block_initial_position.extend([20,4])
                for row,column in select_block:
                    if background[row+block_initial_position[0]][column+block_initial_position[1]]:gameover.append(1)
        pygame.init()
        screen=pygame.display.set_mode((400,800))   #set_mode((400,800)) 修改数值可以修改窗口大小 但第7行和第10行要做相应的改动
        while True:
            screen.fill((255,255,255))
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    pygame.quit()
                    fasdasdf1()
                elif event.type==pygame.KEYDOWN and event.key==pygame.K_LEFT:move(-1)
                elif event.type==pygame.KEYDOWN and event.key==pygame.K_RIGHT:move(1)
                elif event.type==pygame.KEYDOWN and event.key==pygame.K_UP:move(0)
                elif event.type==pygame.KEYDOWN and event.key==pygame.K_DOWN:press=True
                elif event.type==pygame.KEYUP and event.key==pygame.K_DOWN:press=False
            if press:times+=10
            if times>=50:
                move(10)
                times=0
            else:times+=1
            if gameover:sys.exit()
            move(100)
            pygame.time.Clock().tick(200)   #tick(200)修改数字可以修改游戏的整体速率
            pygame.display.flip()
         
        #记分系统在窗口标题上
    elif dakai == "twofour":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/898bc70929aa00fcadb7311fc7f02013.html")
        fasdasdf1()
    elif dakai == "huarong":


        FPS = 60
        SHAPE = 4         # 棋盘shape
        CELL_SIZE = 100   # 方格大小
        CELL_GAP_SIZE = 10  # 方格间距
        MARGIN = 10  # 方格的margin
        PADDING = 10  # 方格的padding
        SCREEN_WIDTH = (CELL_SIZE + MARGIN) * SHAPE + MARGIN  # 屏幕宽度
        SCREEN_HEIGHT = (CELL_SIZE + MARGIN) * SHAPE + MARGIN  # 屏幕高度

        BACKGROUND_COLOR = "#92877d"  # 背景颜色
        BACKGROUND_EMPTY_CELL_COLOR = "#9e948a"  # 空方格颜色
        BACKGROUND_CELL_COLOR = "#edc22e"  # 方格颜色

        # 定义两个元组相加
        def tuple_add(t1, t2):
            return (t1[0] + t2[0], t1[1] + t2[1])
        class Logic:
            def __init__(self, shape=4):
                self.shape = int(shape) if shape > 2 else 4  # 初始化形状
                self.tiles = OrderedDict()  # 初始化数据
                self.neighbors = [  # 定义方向矢量
                    [1, 0],  # 下
                    [-1, 0],  # 上
                    [0, 1],  # 右
                    [0, -1],  # 左
                ]
                self.click_dict = {'x': {}, 'y': {}}  # 定义鼠标点击坐标转换下标的数据
                self.init_load()  # 初始化加载

            def init_load(self):
                count = 1
                # 生成正确的序列
                for x in range(self.shape):
                    for y in range(self.shape):
                        mark = tuple([x, y])
                        self.tiles[mark] = count
                        count += 1
                self.tiles[mark] = 0

                for count in range(1000):  # 随机移动一千次
                    neighbor = random.choice(self.neighbors)
                    spot = tuple_add(mark, neighbor)

                    if spot in self.tiles:
                        number = self.tiles[spot]
                        self.tiles[spot] = 0
                        self.tiles[mark] = number
                        mark = spot

                self.init_click_dict()

            def init_click_dict(self):
                # 初始化点击坐标转换下标的数据
                for r in range(self.shape):
                    for c in range(self.shape):
                        x = MARGIN * (c + 1) + c * CELL_SIZE
                        x1 = x + CELL_SIZE
                        click_x = tuple(range(x, x1))

                        self.click_dict['x'][click_x] = c
                        y = MARGIN * (r + 1) + r * CELL_SIZE
                        y1 = y + CELL_SIZE
                        click_y = tuple(range(y, y1))
                        self.click_dict['y'][click_y] = r

            def move(self, mark):
                # 移动数据
                for neighbor in self.neighbors:
                    spot = tuple_add(mark, neighbor)

                    if spot in self.tiles and self.tiles[spot] == 0:
                        self.tiles[spot], self.tiles[mark] = self.tiles[
                            mark], self.tiles[spot]
                        break

            def click_to_move(self, x, y):
                # 点击移动
                x1 = None
                for k, v in self.click_dict['x'].items():
                    if x in k:
                        x1 = v

                if x1 is None:
                    return
                y1 = None
                for k, v in self.click_dict['y'].items():
                    if y in k:
                        y1 = v

                if y1 is None:
                    return
                self.move((y1, x1))

            def is_win(self):
                # 游戏结束判定
                if self.tiles[(self.shape - 1, self.shape - 1)] != 0:
                    return False
                values = list(self.tiles.values())
                for index in range(values.__len__() - 1):
                    if index + 1 != values[index]:
                        return False
                return True
        def init_game():
            # 初始化游戏
            pygame.init()
            screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.display.set_caption('数字华容道 -- 0')
            return screen


        def draw_num(logic, screen):
            for r in range(logic.shape):
                for c in range(logic.shape):
                    num = logic.tiles[(r, c)]
                    if num != 0:
                        color = pygame.Color(BACKGROUND_CELL_COLOR)
                    else:
                        color = pygame.Color(BACKGROUND_EMPTY_CELL_COLOR)

                    x = MARGIN * (c + 1) + c * CELL_SIZE
                    y = MARGIN * (r + 1) + r * CELL_SIZE
                    pygame.draw.rect(screen, color, (x, y, CELL_SIZE, CELL_SIZE))
                    if num != 0:
                        font_size = int((CELL_SIZE - PADDING) / 1.3)
                        font = pygame.font.SysFont('arialBlod', font_size)
                        font_width, font_height = font.size(str(num))
                        screen.blit(font.render(str(num), True, (255, 255, 255)),
                                    (x + (CELL_SIZE - font_width) / 2, y +
                                     (CELL_SIZE - font_height) / 2 + 5))
        def press(is_game_over, logic, COUNT, counts):
            for event in pygame.event.get():
                if event.type == COUNT and not is_game_over:  # 设置定时器，记录时间
                    counts += 1
                    pygame.display.set_caption('数字华容道 -- {}'.format(counts))
                if event.type == pygame.QUIT:  # 点击关闭按钮退出
                    pygame.quit()
                    fasdasdf1()
                elif event.type == pygame.MOUSEBUTTONUP:  # 鼠标点击
                    if event.button == 1 and not is_game_over:
                        x, y = event.pos
                        logic.click_to_move(int(x), int(y))  # 点击移动
                elif event.type == pygame.KEYDOWN and event.key == 13:  # 游戏结束，回车重开
                    return True
            if COUNT:
                return counts


        def game_win(screen, logic, clock, text='You Win!'):
            font = pygame.font.SysFont('Blod', int(SCREEN_WIDTH / 4))
            font_width, font_height = font.size(str(text))
            while True:
                if press(True, logic, None, None):
                    break
                screen.fill(pygame.Color(BACKGROUND_COLOR))
                draw_num(logic, screen)
                screen.blit(font.render(str(text), True, (0, 0, 0)),
                            ((SCREEN_WIDTH - font_width) / 2,
                             (SCREEN_HEIGHT - font_height) / 2))
                pygame.display.update()
                clock.tick(FPS)
        def main():
            screen = init_game()
            clock = pygame.time.Clock()
            logic = Logic(SHAPE)
            COUNT = pygame.USEREVENT + 1
            pygame.time.set_timer(COUNT, 1000)
            seconds = 0  # 记录时间
            while True:
                if logic.is_win():  # 判断游戏是否胜利
                    break
                seconds = press(False, logic, COUNT, seconds)  # 监控按键
                screen.fill(pygame.Color(BACKGROUND_COLOR))  # 填充背景
                draw_num(logic, screen)  # 画数字
                pygame.display.update()
                clock.tick(FPS)
            game_win(screen, logic, clock, text='Time:' + str(seconds))


        if __name__ == "__main__":
            while True:
                main()
    elif dakai == "shudu":



        def print_matrix(matrix):
            print('—'*19)
            for row in matrix:
                print('|'+' '.join([str(col) for col in row])+'|')
            print('—'*19)


        def shuffle_number(_list):
            random.shuffle(_list)
            return _list


        def check(matrix,i,j,number):
            if number in matrix[i]:
                return False
            if number in [row[j] for row in matrix]:
                return False
            group_i,group_j = int(i/3),int(j/3)
            if number in [matrix[i][j] for i in range(group_i*3,(group_i+1)*3) for j in range(group_j*3,(group_j+1)*3)]:
                return False
            return True


        def build_game(matrix,i,j,number):
            if i>8 or j>8:
                return matrix
            if check(matrix,i,j,number):
                _matrix = [[col for col in row] for row in matrix]
                _matrix[i][j] = number
                next_i,next_j = (i+1,0) if j==8 else (i,j+1)
                for _number in shuffle_number(number_list):
                    #_matrixs.append(build_game(_matrix,next_i,next_j,_number))
                    __matrix = build_game(_matrix,next_i,next_j,_number)
                    if __matrix and sum([sum(row) for row in __matrix])==(sum(range(1,10))*9):
                        return __matrix
            #return _matrixs
            return None


        def give_me_a_game(blank_size=9):
            matrix_all = build_game(matrix,0,0,random.choice(number_list))
            set_ij = set()
            while len(list(set_ij))<blank_size:
                set_ij.add(str(random.choice([0,1,2,3,4,5,6,7,8]))+','+str(random.choice([0,1,2,3,4,5,6,7,8])))
            matrix_blank = [[col for col in row] for row in matrix_all]
            blank_ij = []
            for ij in list(set_ij):
                i,j = int(ij.split(',')[0]),int(ij.split(',')[1])
                blank_ij.append((i,j))
                matrix_blank[i][j] = 0
            return matrix_all,matrix_blank,blank_ij


        number_list = [1,2,3,4,5,6,7,8,9]
        matrix = [([0]*9) for i in range(9)]
        if __name__ == "__main__":
            print_matrix(build_game(matrix,0,0,random.choice(number_list)))





        def draw_background():
            BG_COLOR = (40, 40, 60)  
            screen.fill(BG_COLOR)
            pygame.display.set_caption('数独游戏')
            pygame.draw.rect(screen, COLORS['black'], (0, 0, 300, 900), 5)
            pygame.draw.rect(screen, COLORS['black'], (300, 0, 300, 900), 5)
            pygame.draw.rect(screen, COLORS['black'], (600, 0, 300, 900), 5)
            pygame.draw.rect(screen, COLORS['black'], (0, 0, 900, 300), 5)
            pygame.draw.rect(screen, COLORS['black'], (0, 300, 900, 300), 5)
            pygame.draw.rect(screen, COLORS['black'], (0, 600, 900, 300), 5)




        def draw_choose():
            BLOCK_COLOR = (20, 128, 200)  
            pygame.draw.rect(screen, BLOCK_COLOR, (cur_j * 100 + 5, cur_i * 100 + 5, 100 - 10, 100 - 10), 0)




        def check_win(matrix_all, matrix):
            if matrix_all == matrix:
                return True
            return False




        def check_color(matrix, i, j):
            _matrix = [[col for col in row] for row in matrix]
            _matrix[i][j] = 0
            if check(_matrix, i, j, matrix[i][j]):
                return COLORS['green']
            return COLORS['red']




        def draw_number():
            for i in range(len(MATRIX)):
                for j in range(len(MATRIX[0])):
                    _color = check_color(MATRIX, i, j) if (i, j) in BLANK_IJ else COLORS['gray']
                    txt = font80.render(str(MATRIX[i][j] if MATRIX[i][j] not in [0, '0'] else ''), True, _color)
                    x, y = j * 100 + 30, i * 100 + 10
                    screen.blit(txt, (x, y))




        def draw_context():
            txt = font100.render('Blank:' + str(cur_blank_size) + '   Change:' + str(cur_change_size), True, COLORS['black'])
            x, y = 10, 900
            screen.blit(txt, (x, y))




        if __name__ == "__main__":

            pygame.init()
            font80 = pygame.font.SysFont('Times', 80)
            font100 = pygame.font.SysFont('Times', 90)
            screen = pygame.display.set_mode((900,1000))


            cur_i, cur_j = 0, 0
            cur_blank_size = 5 
            cur_change_size = 0


            MATRIX_ANSWER, MATRIX, BLANK_IJ = give_me_a_game(blank_size=cur_blank_size)
            print(BLANK_IJ)
            print_matrix(MATRIX)


            running = True
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        break
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        cur_j, cur_i = int(event.pos[0] / 100), int(event.pos[1] / 100)
                    elif event.type == event.type == pygame.KEYUP:
                        if chr(event.key) in ['1', '2', '3', '4', '5', '6', '7', '8', '9'] and (cur_i, cur_j) in BLANK_IJ:
                            MATRIX[cur_i][cur_j] = int(chr(event.key))
                            cur_blank_size = sum([1 if col == 0 or col == '0' else 0 for row in MATRIX for col in row])
                            cur_change_size += 1
                            
                draw_background()
                draw_choose()
                draw_number()
                draw_context()
                pygame.display.flip()


                if check_win(MATRIX_ANSWER, MATRIX):
                    print('You win, smarty ass!!!')
                    break


            pygame.quit()
            fasdasdf1()
    elif dakai == "shapan":


        # 设定每一个角色的宽度
        image_width = 80
        # 屏幕大小宽为8个角色宽度，高为8个角色宽度
        width_num = 8
        height_num = 9
        WIDTH, HEIGHT = width_num * image_width, height_num * image_width
        # 初始化方格计数器
        counts_x = 0
        counts_y = 0
        # 初始化标志
        flag = 0
        # 初始化选中的图形
        img_show = 0
        # 初始化沙盘，使用字典避免格子重复,字典键为元组，存储空位置，99表示该位置为空，0表示该位置没有汽车
        sandbox = {}
        for i in range(width_num):
            for j in range(height_num - 1):
                sandbox[(i, j)] = [99,0]
        # 占位计数器，用于将要占据的格子是否为空
        count = 0


        # #字典定义每个物体大小,使用两个数据，代表宽和高
        img_size = {0: [2, 2], 1: [1, 1], 2: [1, 1], 3: [2, 2], 4: [3, 3], 5: [3, 3], 6: [3, 3], 7: [1, 1]}

        pygame.init()
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        # 加载图片
        background = pygame.image.load("background.png")
        background = pygame.transform.scale(background, (WIDTH, HEIGHT))
        img_list = []
        for i in range(8):
            img = pygame.image.load("{}1.png".format(i)).convert_alpha()
            # #加载图片后，调整为需要的方格大小
            img = pygame.transform.scale(img, (image_width * img_size[i][0], image_width * img_size[i][1]))
            img_list.append(img)

        def mouse_square(x, y):
            """
            判断鼠标位于哪个方格中，x/y为鼠标坐标
            """
            # 判断鼠标位于哪个方格
            conuts_x = (x // image_width)
            conuts_y = (y // image_width)
            return conuts_x, conuts_y


        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    fasdasdf1()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    # 如果鼠标在最下方，将标志设为1，可以拖动图形
                    if counts_y == (height_num - 1):
                        flag = 1
                        # 固定选中的图案不变化
                        img_show = counts_x
                    # else:
                    #     flag = 2
                    #     # 如果选中沙盘中的图案进行移动
                    #     if (counts_x,counts_y) in sandbox.keys():
                    #         img_show = sandbox[(counts_x,counts_y)]
                    #         del sandbox[(counts_x,counts_y)]

                # 按下鼠标之后检测鼠标抬起
                if flag == 1 or flag == 2:
                    if event.type == pygame.MOUSEBUTTONUP:
                        flag = 3

            # 获取鼠标位置，获得格子坐标
            x, y = pygame.mouse.get_pos()
            counts_x, counts_y = mouse_square(x, y)

            screen.blit(background, (0, 0))
            # 刷新沙盒中已经放置的图案
            for k, values in sandbox.items():
                if values[0] < 20:
                    screen.blit(img_list[values[0]], (k[0] * image_width, k[1] * image_width))
                # #刷新汽车
                if values[1] == 1:
                    screen.blit(img_list[7], (k[0] * image_width, k[1] * image_width))

            # 标志为1或者2时图案跟随鼠标移动
            if flag == 1 or flag == 2:
                screen.blit(img_list[img_show], (int(x - image_width / 2), int(y - image_width / 2)))

            # 标志为3时，表明鼠标松开，将当前位置和选中的图形存储到字典中
            elif flag == 3:
                # #如果放置的到沙盘外，取消之
                if ((counts_y + img_size[img_show][1])<height_num)  and ((counts_x + img_size[img_show][0])<(width_num+1)):
                    #判断所有要填入的格子是否为空
                    for i in range(img_size[img_show][0]):
                        for j in range(img_size[img_show][1]):
                            if sandbox[(counts_x + i, counts_y + j)][0] == 99:
                                count += 1


                    # #如果所有要占据的格子都为空，那么填充沙盘
                    if img_show != 7:
                        if count ==  img_size[img_show][0]**2:
                            for i in range(img_size[img_show][0]):
                                for j in range(img_size[img_show][1]):
                                    if i or j:
                                        sandbox[(counts_x + i, counts_y + j)][0] = img_show + 20
                            sandbox[(counts_x, counts_y)][0] = img_show
                    else:
                    # #汽车只能放置在路上
                        if  sandbox[(counts_x, counts_y)][0] == 1:
                            sandbox[(counts_x, counts_y)][1] = 1
                    count = 0

                # 初始化标志
                flag = 0
            # print(sandbox)
            pygame.display.flip()
            pygame.time.Clock().tick(120)
    elif dakai == "flybird":
        num=0
        score=0
        
        class Bird(object):
            
            def __init__(self):
                self.birdRect=pygame.Rect(65,50,50,50)
                a=random.choice([1,4,7])
                self.birdStatus=[pygame.image.load(str(a)+".png"),
                                pygame.image.load(str(a+1)+".png"),
                                pygame.image.load(str(a+2)+".png")]
                self.dead=False
                self.status=0
                self.birdX=120
                self.birdY=350
                self.jump=False
                self.jumpSpeed=10
                self.gravity=5
                
                
            def birdUpdate(self):
                global num
                num1 = 0
                self.birdStatus
                num1+=1
                self.status=num1%3
                if self.jump:
                    self.jumpSpeed-=0.5
                    self.birdY-=self.jumpSpeed
                else:
                    self.gravity+=0.2
                    self.birdY+=self.gravity
                    
                self.birdRect[1]=self.birdY



        class Pipeline(object):

            def __init__(self):
                self.wallx=400
                self.wally=random.randint(-100,0)
                s=random.randint(1,2)
                aUp=pygame.image.load("p"+str(s)+".png")
                self.pineUp=pygame.transform.flip(aUp,False,True)
                self.pineDown=pygame.image.load("p"+str(s)+".png")

                
            def updatePipeline(self):
                global score
                global score1
                score1 = 0

                self.wallx-=5
                if self.wallx==20 and not Bird.dead:
                    score1+=1
                    
                if self.wallx<-80:
                    self.wally=random.randint(-100,0)
                    self.wallx=400
                    

        def createMap():
            
            screen.fill((255,255,255))
            screen.blit(background,(0,0)) 
            #管道
            screen.blit(Pipeline.pineUp,(Pipeline.wallx,Pipeline.wally))
            screen.blit(Pipeline.pineDown,(Pipeline.wallx,Pipeline.wally+500))
            Pipeline.updatePipeline()
            #鸟
            if Bird.dead:
                Bird.status=2
            screen.blit(Bird.birdStatus[Bird.status],(Bird.birdX,Bird.birdY))
            Bird.birdUpdate()
            #分数

            # screen.blit(font.render(str(score1),-1,(255,255,255)),(190,50))
            pygame.display.update()

        def checkDead():
            upRect=pygame.Rect(Pipeline.wallx,Pipeline.wally,Pipeline.pineDown.get_width()-20,Pipeline.pineDown.get_height()-5)
            downRect=pygame.Rect(Pipeline.wallx,Pipeline.wally+500,Pipeline.pineDown.get_width()-20,Pipeline.pineDown.get_height()-5)
            if upRect.colliderect(Bird.birdRect) or downRect.colliderect(Bird.birdRect):
                Bird.dead=True
            if not 0<Bird.birdRect[1]<height:
                Bird.dead=True
                
                return True
            else:
                return False

        def getResult():
            final_text1="Good game"
            final_text2="Your final score is:"+str(score1)
            ft1_font=pygame.font.SysFont("微软雅黑",70)
            ft1_surf=font.render(final_text1,1,(242,3,36))
            ft2_font=pygame.font.SysFont("微软雅黑",50)
            ft2_surf=font.render(final_text2,1,(253,177,6))
            screen.blit(ft1_surf,[(screen.get_width()-ft1_surf.get_width())/2,100])
            # screen.blit(ft2_surf,[(screen.get_width()-ft2_surf.get_width())/2,200])
            pygame.display.flip()
        ##
        def nice(emoji_str):
            return ''.join(c if c <= '\uffff' else ''.join(chr(x) for x in struct.unpack('>2H', c.encode('utf-16be'))) for c in emoji_str)
        def run_app(pid):
            pid=pid.split("&")[1].split("=")[1]
            import requests,time,random,os
            def load(url,name):
                import requests as req
                response = req.get(url)
                try:
                    a=open(name,"wb")
                    a.write(response.content)
                    a.close()
                except:
                    a=open(name,"w")
                    a.write(response.text)
                    a.close()
            def enter(k):
                url="http://code.xueersi.com/api/compilers/"+k+"?id="+k
                headers = {'Content-Type':'application/json'}
                a=requests.get(url=url, headers=headers)
                z=eval(a.text.replace("false","False").replace("true","True").replace("null","None"))
                return nice(z["data"]["xml"])
            def load_img(k):
                url="http://code.xueersi.com/api/compilers/"+k+"?id="+k
                headers = {'Content-Type':'application/json'}
                a=requests.get(url=url, headers=headers)
                z=eval(a.text.replace("false","False").replace("true","True").replace("null","None"))

                k=z["data"]["assets"]["assets"]
                for x in k:
                    load(("https://livefile.xesimg.com/programme/python_assets/"+x["md5ext"]),x["name"])
            import time
            load_img(pid)
            time.sleep(1)
            clear_os()
            
            return enter(pid)
        def clear_os():
            import sys
            sys.stdout.write("\033[2J\033[00H")
        ##
            
        flag=True
        if __name__=="__main__":
            
            pygame.init()
            font=pygame.font.SysFont(None,50)
            size=width,height=400,650
            screen=pygame.display.set_mode(size)
            pygame.display.set_caption("小饼干")
            clock=pygame.time.Clock()
            Pipeline=Pipeline()
            Bird=Bird()
            
            
            ss=random.randint(1,2)
            
            key=False
            while True:
                clock.tick(60)
                for event in pygame.event.get():
                    if event.type==pygame.QUIT:
                        pygame.quit()
                        fasdasdf1()
                    if(event.type==pygame.KEYDOWN or event.type==pygame.MOUSEBUTTONDOWN) and not Bird.dead:
                        key =True
                        Bird.jump=True
                        Bird.gravity=5
                        Bird.jumpSpeed=10
                if key:
                    background=pygame.image.load("bg"+str(ss)+".png")
                    background=pygame.transform.scale(background,(400,650))
                    if checkDead():
                        getResult()
                        if flag:
                            
                            flag=not flag
                    else:
                        createMap()
                else:
                    a=pygame.image.load("bg"+str(ss)+".png")
                    background1=pygame.transform.scale(a,(400,650))
                    b=pygame.image.load("message.png")
                    background=pygame.transform.scale(b,(184,267))
                    screen.blit(background1,(0,0))
                    screen.blit(background,((400-184)/2,(650-267)/2))
                    screen.blit(Bird.birdStatus[Bird.status],(Bird.birdX,Bird.birdY))
                    pygame.display.update()
            
    elif dakai == "huihua":
        
        

        # 2011/08/27 Version 1, first imported

        class Brush():
         def __init__(self, screen):
          self.screen = screen
          self.color = (0, 0, 0)
          self.size = 1
          self.drawing = False
          self.last_pos = None
          self.space = 1
          # if style is True, normal solid brush
          # if style is False, png brush
          self.style = False
          # load brush style png
          self.brush = pygame.image.load("brush.png").convert_alpha()
          # set the current brush depends on size
          self.brush_now = self.brush.subsurface((0,0), (1, 1))

         def start_draw(self, pos):
          self.drawing = True
          self.last_pos = pos
         def end_draw(self):
          self.drawing = False

         def set_brush_style(self, style):
          if style == True:
            print('已开启刷子')
          if style == False:
            print('已关闭刷子')
          self.style = style
         def get_brush_style(self):
          return self.style

         def get_current_brush(self):
          return self.brush_now

         def set_size(self, size):
          if size < 1: size = 1
          elif size > 32: size = 32
          print("设置画笔大小为", size)
          self.size = size
          self.brush_now = self.brush.subsurface((0,0), (size*2, size*2))
         def get_size(self):
          return self.size

         def set_color(self, color):
          self.color = color
          for i in range(self.brush.get_width()):
           for j in range(self.brush.get_height()):
            self.brush.set_at((i, j),
              color + (self.brush.get_at((i, j)).a,))
         def get_color(self):
          return self.color

         def draw(self, pos):
          if self.drawing:
           for p in self._get_points(pos):
            # draw eveypoint between them
            if self.style == False:
             pygame.draw.circle(self.screen, self.color, p, self.size)
            else:
             self.screen.blit(self.brush_now, p)

           self.last_pos = pos

         def _get_points(self, pos):
          """ Get all points between last_point ~ now_point. """
          points = [ (self.last_pos[0], self.last_pos[1]) ]
          len_x = pos[0] - self.last_pos[0]
          len_y = pos[1] - self.last_pos[1]
          length = sqrt(len_x ** 2 + len_y ** 2)
          step_x = len_x / length
          step_y = len_y / length
          for i in range(int(length)):
           points.append(
             (points[-1][0] + step_x, points[-1][1] + step_y))
          points = map(lambda x:(int(0.5+x[0]), int(0.5+x[1])), points)
          # return light-weight, uniq integer point list
          return list(set(points))

        class Menu():
         def __init__(self, screen):
          self.screen = screen
          self.brush = None
          self.colors = [
            (0xff, 0x00, 0xff), (0x80, 0x00, 0x80),
            (0x00, 0x00, 0xff), (0x00, 0x00, 0x80),
            (0x00, 0xff, 0xff), (0x00, 0x80, 0x80),
            (0x00, 0xff, 0x00), (0x00, 0x80, 0x00),
            (0xff, 0xff, 0x00), (0x80, 0x80, 0x00),
            (0xff, 0x00, 0x00), (0x80, 0x00, 0x00),
            (0xc0, 0xc0, 0xc0), (0xff, 0xff, 0xff),
            (0x00, 0x00, 0x00), (0x80, 0x80, 0x80),
           ]
          self.colors_rect = []
          for (i, rgb) in enumerate(self.colors):
           rect = pygame.Rect(10 + i % 2 * 32, 254 + i / 2 * 32, 32, 32)
           self.colors_rect.append(rect)

          self.pens = [
            pygame.image.load("pen1.png").convert_alpha(),
            pygame.image.load("brush.png").convert_alpha()
           ]
          self.pens_rect = []
          for (i, img) in enumerate(self.pens):
           rect = pygame.Rect(10, 10 + i * 64, 64, 64)
           self.pens_rect.append(rect)

          self.sizes = [
            pygame.image.load("big.png").convert_alpha(),
            pygame.image.load("small.png").convert_alpha()
           ]
          self.sizes_rect = []
          for (i, img) in enumerate(self.sizes):
           rect = pygame.Rect(10 + i * 32, 138, 32, 32)
           self.sizes_rect.append(rect)

         def set_brush(self, brush):
          self.brush = brush

         def draw(self):
          # draw pen style button
          for (i, img) in enumerate(self.pens):
           self.screen.blit(img, self.pens_rect[i].topleft)
          # draw < > buttons
          for (i, img) in enumerate(self.sizes):
           self.screen.blit(img, self.sizes_rect[i].topleft)
          # draw current pen / color
          self.screen.fill((255, 255, 255), (10, 180, 64, 64))
          pygame.draw.rect(self.screen, (0, 0, 0), (10, 180, 64, 64), 1)
          size = self.brush.get_size()
          x = 10 + 32
          y = 180 + 32
          if self.brush.get_brush_style():
           x = x - size
           y = y - size
           self.screen.blit(self.brush.get_current_brush(), (x, y))
          else:
           pygame.draw.circle(self.screen,
             self.brush.get_color(), (x, y), size)
          # draw colors panel
          for (i, rgb) in enumerate(self.colors):
           pygame.draw.rect(self.screen, rgb, self.colors_rect[i])

         def click_button(self, pos):
          # pen buttons
          for (i, rect) in enumerate(self.pens_rect):
           if rect.collidepoint(pos):
            self.brush.set_brush_style(bool(i))
            return True
          # size buttons
          for (i, rect) in enumerate(self.sizes_rect):
           if rect.collidepoint(pos):
            if i: # i == 1, size down
             self.brush.set_size(self.brush.get_size() - 1)
            else:
             self.brush.set_size(self.brush.get_size() + 1)
            return True
          # color buttons
          for (i, rect) in enumerate(self.colors_rect):
           if rect.collidepoint(pos):
            self.brush.set_color(self.colors[i])
            return True
          return False

        class Painter():
         def __init__(self):
          self.screen = pygame.display.set_mode((800, 600))
          pygame.display.set_caption("Pygame画板")
          self.clock = pygame.time.Clock()
          self.brush = Brush(self.screen)
          self.menu = Menu(self.screen)
          self.menu.set_brush(self.brush)

         def run(self):
          self.screen.fill((255, 255, 255))
          while True:
           # max fps limit
           self.clock.tick(30)
           for event in pygame.event.get():
            if event.type == QUIT:
             return
            elif event.type == KEYDOWN:
             # press esc to clear screen
             if event.key == K_ESCAPE:
              self.screen.fill((255, 255, 255))
            elif event.type == MOUSEBUTTONDOWN:
             # <= 74, coarse judge here can save much time
             if ((event.pos)[0] <= 74 and
               self.menu.click_button(event.pos)):
              # if not click on a functional button, do drawing
              pass
             else:
              self.brush.start_draw(event.pos)
            elif event.type == MOUSEMOTION:
             self.brush.draw(event.pos)
            elif event.type == MOUSEBUTTONUP:
             self.brush.end_draw()

           self.menu.draw()
           pygame.display.update()

        if __name__ == '__main__':
         app = Painter()
         app.run()
         fasdasdf1()
    elif dakai == "wenben":


        app = wx.App()
        win = wx.Frame(None, title="TXT Editor", size=(1000, 666))

        bkg = wx.Panel(win)

        def openFile(evt):
            dlg = wx.FileDialog(
                win,
                "Open",
                "",
                "",
                "All files (*.*)|*.*",
                wx.FD_OPEN | wx.FD_FILE_MUST_EXIST)
            filepath = ''
            if dlg.ShowModal() == wx.ID_OK:
                filepath = dlg.GetPath()
            else:
                return
            filename.SetValue(filepath)
            fopen = open(filepath)
            fcontent = fopen.read()
            contents.SetValue(fcontent)
            fopen.close()


        def saveFile(evt):

            fcontent = contents.GetValue()
            fopen = open(filename.GetValue(), 'w')
            fopen.write(fcontent)
            fopen.close()
            win = wx.Frame(None, title='TXT Editor')
            button = wx.Button(win, label='保存成功')
            win.Show()

        openBtn = wx.Button(bkg, label='浏览')
        openBtn.Bind(wx.EVT_BUTTON, openFile)

        saveBtn = wx.Button(bkg, label='保存')
        saveBtn.Bind(wx.EVT_BUTTON, saveFile)

        filename = wx.TextCtrl(bkg, style=wx.TE_READONLY)
        contents = wx.TextCtrl(bkg, style=wx.TE_MULTILINE)

        hbox = wx.BoxSizer()
        hbox.Add(openBtn, proportion=0, flag=wx.LEFT | wx.ALL, border=5)
        hbox.Add(filename, proportion=1, flag=wx.EXPAND | wx.TOP | wx.BOTTOM, border=5)
        hbox.Add(saveBtn, proportion=0, flag=wx.LEFT | wx.ALL, border=5)

        bbox = wx.BoxSizer(wx.VERTICAL)
        bbox.Add(hbox, proportion=0, flag=wx.EXPAND | wx.ALL)
        bbox.Add(contents, proportion=1, flag=wx.EXPAND | wx.LEFT | wx.BOTTOM | wx.RIGHT, border=5)

        bkg.SetSizer(bbox)
        win.Show()
        app.MainLoop()
        fasdasdf1()
        # #新建根窗口
        # root=Tk()
        # #新建Menu实例
        # menu_bar=Menu(root)
        # file_menu=Menu(menu_bar,tearoff=0)
        # edit_menu=Menu(menu_bar,tearoff=0)
        # view_menu=Menu(menu_bar,tearoff=0)
        # about_menu=Menu(menu_bar,tearoff=0)
        # themes_menu=Menu(menu_bar,tearoff=0)
         
        # file_name = None
        # #获取文本行数
        # def get_line_numbers():
        #     output = ''
        #     if show_line_number.get():
        #         row, col = content_text.index("end").split('.')
        #         for i in range(1, int(row)):
        #             output +=str(i)+ '\n'
        #     return output
        # #更新文本行数
        # def update_line_numbers(event = None):
        #     line_numbers = get_line_numbers()
        #     line_number_bar.config(state='normal')
        #     line_number_bar.delete('1.0', 'end')
        #     line_number_bar.insert('1.0', line_numbers)
        #     line_number_bar.config(state='disabled')
        # #高亮当前行    
        # def highlight_line(interval=100):
        #     content_text.tag_remove("active_line", 1.0, "end")
        #     content_text.tag_add("active_line", "insert linestart", "insert lineend+1c")
        #     content_text.after(interval, toggle_highlight)
        # #非高亮当前行    
        # def undo_highlight():
        #     content_text.tag_remove("active_line", 1.0, "end")
        # #高亮状态切换
        # def toggle_highlight(event=None):
        #     if to_highlight_line.get():
        #         highlight_line()
        #     else:
        #         undo_highlight()
        # #显示光标信息
        # def show_cursor_info_bar():
        #     show_cursor_info_checked = show_cursor_info.get()
        #     if show_cursor_info_checked:
        #         cursor_info_bar.pack(expand='no', fill=None, side='right', anchor='se')
        #     else:
        #         cursor_info_bar.pack_forget()
        # #更新光标信息
        # def update_cursor_info_bar(event=None):
        #     row, col = content_text.index(INSERT).split('.')
        #     line_num, col_num = str(int(row)), str(int(col)+1) 
        #     infotext = "Line: {0} | Column: {1}".format(line_num, col_num)
        #     cursor_info_bar.config(text=infotext)
        # #当文本内容改变时触发
        # def on_content_changed(event=None):
        #     update_line_numbers()
        #     update_cursor_info_bar()
        # #打开文件
        # def open_file(event=None):
        #     input_file_name=tkinter.filedialog.askopenfilename(defaultextension=".txt", filetypes=[("All Files", "*.*"), ("Text Documents","*.txt")])
        #     if input_file_name:
        #         global file_name
        #         file_name = input_file_name
        #         root.title('{} - {}'.format(os.path.basename(file_name), PROGRAM_NAME))
        #         content_text.delete(1.0, END)
        #         with open(file_name,encoding = "utf-8") as _file:
        #             content_text.insert(1.0, _file.read())
        #         on_content_changed()
        # #保存文件
        # def save(event=None):
        #     global file_name
        #     if not file_name:
        #         save_as()
        #     else:
        #         write_to_file(file_name)
        #     return "break"
        # #保存文件为
        # def save_as(event=None):
        #     input_file_name = tkinter.filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("All Files", "*.*"), ("Text Documents", "*.txt")])
        #     if input_file_name:
        #         global file_name
        #         file_name = input_file_name
        #         write_to_file(file_name)
        #         root.title('{} - {}'.format(os.path.basename(file_name),PROGRAM_NAME))
        #     return "break"
        # #写入磁盘
        # def write_to_file(file_name):
        #     try:
        #         content = content_text.get(1.0, 'end')
        #         with open(file_name, 'w') as the_file:
        #             the_file.write(content)
        #     except IOError:
        #         pass
        # #新建文件
        # def new_file(event=None):
        #     root.title("Untitled")
        #     global file_name
        #     file_name = None
        #     content_text.delete(1.0,END)
        #     on_content_changed()
        # #退出编辑器
        # def exit_editor(event=None):
        #     if tkinter.messagebox.askokcancel("Quit?", "Really quit?"):
        #         root.destroy()
        # #剪切
        # def cut():
        #     content_text.event_generate("<<Cut>>")
        #     on_content_changed()
        # #复制
        # def copys():
        #     content_text.event_generate("<<Copy>>")
        # #粘贴
        # def paste():
        #     content_text.event_generate("<<Paste>>")
        #     on_content_changed()
        # #恢复
        # def redo(event=None):
        #     content_text.event_generate("<<Redo>>")
        #     on_content_changed()
        #     return 'break'
        # #撤销
        # def undo(event=None):
        #     content_text.event_generate("<<Undo>>")
        #     on_content_changed()
        #     return 'break'
        # #全选
        # def select_all(event=None):
        #     content_text.tag_add('sel', '1.0', 'end')
        #     return "break"
        # #查找
        # def find_text(event=None):
        #     search_toplevel=Toplevel(root)
        #     search_toplevel.title('Find Text')
        #     search_toplevel.transient(root)
        #     search_toplevel.resizable(False, False)
        #     Label(search_toplevel, text="Find All:").grid(row=0, column=0, sticky='e')
        #     search_entry_widget = Entry(search_toplevel, width=50)
        #     search_entry_widget.grid(row=0, column=1, padx=2, pady=2, sticky='we')
        #     search_entry_widget.focus_set()
        #     ignore_case_value = IntVar()
        #     Checkbutton(search_toplevel, text='Ignore  Case',variable=ignore_case_value).grid(row=1, column=1, sticky='e', padx=2, pady=2)
        #     Button(search_toplevel, text="Find All", underline=0,command=lambda: search_output( search_entry_widget.get(), ignore_case_value.get(), content_text, search_toplevel,search_entry_widget)).grid(row=0, column=2, sticky='e' +'w', padx=2, pady=2)
        # #关闭查找窗口
        # def close_search_window():
        #     content_text.tag_remove('match', '1.0', END)
        #     search_toplevel.destroy()
        #     search_toplevel.protocol('WM_DELETE_WINDOW', close_search_window)
        #     return "break"
        # #查找结果输出
        # def search_output(needle, if_ignore_case, content_text,search_toplevel, search_box):
        #     content_text.tag_remove('match', '1.0', END)
        #     matches_found = 0
        #     if needle:
        #          start_pos = '1.0'
        #          while True:
        #              start_pos = content_text.search(needle, start_pos, nocase=if_ignore_case, stopindex=END)
        #              if not start_pos:
        #                  break
        #              end_pos = '{}+{}c'.format(start_pos, len(needle))
        #              content_text.tag_add('match', start_pos, end_pos)
        #              matches_found += 1
        #              start_pos = end_pos
        #          content_text.tag_config( 'match', foreground='red', background='yellow')
        #     search_box.focus_set()
        #     search_toplevel.title('{} matches found'.format(matches_found)) 
        # #显示about
        # def display_about_messagebox(event=None):
        #     tkinter.messagebox.showinfo("About", "{}{}".format(PROGRAM_NAME, "\nTkinter GUI Application\n Development Blueprints"))
        # #显示help
        # def display_help_messagebox(event=None):
        #     tkinter.messagebox.showinfo("Help", "Help Book: \nTkinter GUI Application\n Development Blueprints", icon='question')
        # #变量初始化
        # show_cursor_info=BooleanVar()
        # to_highlight_line = BooleanVar() 
        # theme_choice=StringVar()
        # show_line_number = IntVar()
        # show_line_number.set(1)
        # #主题
        # color_schemes = { 'Default': '#000000.#FFFFFF',
        #                   'Greygarious':'#83406A.#D1D4D1',
        #                   'Aquamarine': '#5B8340.#D1E7E0',
        #                   'Bold Beige': '#4B4620.#FFF0E1',
        #                   'Cobalt Blue':'#ffffBB.#3333aa',
        #                   'Olive Green': '#D1E7E0.#5B8340',
        #                   'Night Mode': '#FFFFFF.#000000'} 
        # #更换主题
        # def change_theme(event=None):
        #     selected_theme = theme_choice.get()
        #     fg_bg_colors = color_schemes.get(selected_theme)
        #     foreground_color, background_color = fg_bg_colors.split('.')
        #     content_text.config(background=background_color,fg=foreground_color) 
        # #File
        # file_menu.add_command(label="New", accelerator='Ctrl+N',    compound='left', underline=0,command=new_file)
        # file_menu.add_command(label="Open", accelerator='Ctrl+O',    compound='left', underline=0,command=open_file)
        # file_menu.add_command(label="Save", accelerator='Ctrl+S',    compound='left', underline=0 ,command= save)
        # file_menu.add_command(label="Save as", accelerator='Shift+Ctrl+S',    compound='left', underline=0, command= save_as)
        # file_menu.add_separator()
        # file_menu.add_command(label="Exit", accelerator='Alt+F4',    compound='left', underline=0, command= exit_editor)
        # #Edit
        # edit_menu.add_command(label="Undo", accelerator='Ctrl + Z',    compound='left',command=undo)
        # edit_menu.add_command(label="Redo", accelerator='Ctrl + Y',    compound='left',command=redo)
        # edit_menu.add_separator()
        # edit_menu.add_command(label="Cut", accelerator='Ctrl + X',    compound='left',command=cut)
        # edit_menu.add_command(label="Copy", accelerator='Ctrl + C',    compound='left',command=copy)
        # edit_menu.add_command(label="Paste", accelerator='Ctrl + V',    compound='left',command=paste)
        # edit_menu.add_separator()
        # edit_menu.add_command(label="Find",underline=0, accelerator='Ctrl + F',    compound='left',command=find_text)
        # edit_menu.add_separator()
        # edit_menu.add_command(label="Select All",underline=7, accelerator='Ctrl + A',    compound='left',command=select_all)
        # #View
        # view_menu.add_checkbutton(label="Show Line Number",    variable=show_line_number)
        # view_menu.add_checkbutton(label="Show Cursor Location at Bottom",variable=show_cursor_info, command=show_cursor_info_bar)
        # view_menu.add_checkbutton(label='Highlight Current Line',    onvalue=1, offvalue=0, variable=to_highlight_line,command=toggle_highlight)
        # #Themes
        # themes_menu.add_radiobutton(label="Default",  variable=theme_choice,command=change_theme)
        # themes_menu.add_radiobutton(label="Aquamarine", variable=theme_choice,command=change_theme)
        # themes_menu.add_radiobutton(label="Bold Beige", variable=theme_choice,command=change_theme)
        # themes_menu.add_radiobutton(label="Cobalt Blue", variable=theme_choice,command=change_theme)
        # themes_menu.add_radiobutton(label="Greygarious", variable=theme_choice,command=change_theme)
        # themes_menu.add_radiobutton(label="Night Mode", variable=theme_choice,command=change_theme)
        # themes_menu.add_radiobutton(label="Olive Green", variable=theme_choice,command=change_theme)
        # view_menu.add_cascade(label="Themes", menu=themes_menu)
        # #About
        # about_menu.add_command(label="About", compound='left', command=display_about_messagebox)
        # about_menu.add_command(label="Help", compound='left', command=display_help_messagebox)
        # #主菜单栏
        # menu_bar.add_cascade(label='File',menu=file_menu)
        # menu_bar.add_cascade(label='Edit',menu=edit_menu)
        # menu_bar.add_cascade(label='View',menu=view_menu)
        # menu_bar.add_cascade(label='About',menu=about_menu)
        # #窗口名称
        # PROGRAM_NAME = " Footprint Editor "
        # root.title(PROGRAM_NAME)
        # #工具栏
        # shortcut_bar = Frame(root,  height=25, background='light sea green')
        # shortcut_bar.pack(expand='no', fill='x')
        # #图标名称
        # names = ["新建","打开","保存","剪切","复制","粘贴","撤销","恢复","查找"]
        # icons = ['new_file', 'open_file', 'save', 'cut', 'copys', 'paste','undo', 'redo', 'find_text']
        # for i in range(len(icons)):
        #     # tool_bar_icon = PhotoImage(file='icons/{}.gif'.format(icon))#图标文件路径
        #     cmd = eval(icons[i])
        #     tool_bar = Button(shortcut_bar,text = names[i],command=cmd)
            
        #     tool_bar.pack(side='left')
        # #左侧行数区    
        # line_number_bar = Text(root, width=4, padx=3, takefocus=0,    border=0, background='khaki', state='disabled', wrap='none')
        # line_number_bar.pack(side='left', fill='y')
        # #文本内容区和右侧滚动条
        # content_text = Text(root, wrap='word',undo=1)
        # content_text.tag_configure('active_line', background='ivory2')
        # content_text.bind('<Any-KeyPress>', on_content_changed)
        # content_text.pack(expand='yes', fill='both')
        # scroll_bar = Scrollbar(content_text)
        # content_text.configure(yscrollcommand=scroll_bar.set)
        # scroll_bar.config(command=content_text.yview)
        # scroll_bar.pack(side='right', fill='y')
        # #右键下拉菜单
        # popup_menu = Menu(content_text)
        # for i in ('cut', 'copy', 'paste', 'undo', 'redo'):
        #     cmd = eval(i)
        #     popup_menu.add_command(label=i, compound='left', command=cmd)
        # popup_menu.add_separator()
        # popup_menu.add_command(label='Select All', underline=7,    command=select_all)
        # def show_popup_menu(event):
        #     popup_menu.tk_popup(event.x_root, event.y_root)
        # content_text.bind('<Button-3>', show_popup_menu)
        # #右下侧光标信息显示
        # cursor_info_bar = Label(content_text, text='Line: 1 | Column: 1')
        # cursor_info_bar.pack(expand=NO, fill=None, side='right',    anchor='se')
         
        # root.config(menu=menu_bar)
        # root.mainloop()
        # fasdasdf1()
    elif dakai == "code":
        def clean(file):
            os.remove(file)
            with open(file, "w+"):
                pass
        class Saver(object):
            def __init__(self, file):
                self.file = file
                self.terminal = sys.stdout

            def write(self, message):
                self.terminal.write(message)

                with open(self.file, "a") as logger:
                    logger.write(message)

            def flush(self):
                pass


        def save(file):
            sys.stdout = Saver(file)
        def do(code):
            try:
                exec(code)
            except BaseException as Errors:
                print(Errors)
        def read(file):
            with open(file, "r+") as f:
                return f.read()
        class BaseFrame(Frame):

            def __init__(self, title, size, icon, kind="default", background_color="GREY"):
                super(BaseFrame, self).__init__(parent=None, title=title, size=size, style=DEFAULT_FRAME_STYLE ^ MAXIMIZE_BOX)

                if kind == "default":
                    self.panel = Panel(parent=self)
                elif kind == "split-v":
                    self.splitter = SplitterWindow(self, style=SP_3DSASH)
                    self.left_p = Panel(self.splitter)
                    self.right_p = Panel(self.splitter)
                    self.splitter.SplitVertically(self.left_p, self.right_p, size[0] / 5 * 3)
                    self.splitter.SetMinimumPaneSize(size[0] / 10)
                elif kind == "split-h":
                    self.splitter = SplitterWindow(self, style=SP_3DSASH)
                    self.top_panel = Panel(self.splitter)
                    self.bottom_panel = Panel(self.splitter)
                    self.splitter.SplitHorizontally(self.top_panel, self.bottom_panel, size[1] / 5 * 3)
                    self.splitter.SetMinimumPaneSize(size[1] / 10)

                icon = Icon(icon[0], icon[1])

                self.Center()
                self.SetBackgroundColour(background_color)
                self.SetIcon(icon)
                self.SetSizeHints((size[0], size[1]), (size[0], size[1]))

                self.Bind(EVT_CLOSE, self.doing_close)

            def doing_close(self, event):
                md_md = MessageDialog(None, "确定关闭?", caption="提示", style=YES_NO | ICON_EXCLAMATION)

                if md_md.ShowModal() == ID_YES:
                    self.Destroy()
                    sys.exit(0)
                else:
                    md_md.Destroy()
        class MainFrame(BaseFrame):
            def __init__(self):
                super(MainFrame, self).__init__(title="Python代码IDE工具", size=(750, 750),
                                                icon=["icon.jpg", BITMAP_TYPE_JPEG],
                                                kind="split-h", background_color="MEDIUM TURQUOISE")

                self.isrunning = True
                self.top()
                self.bottom()
            def top(self):
                global editor_tc
                top_bs_h = BoxSizer(HORIZONTAL)
                editor_tc = TextCtrl(self.top_panel, id=-1, style=TE_MULTILINE | HSCROLL)
                editor_tc.SetBackgroundColour("BLUE")
                editor_tc.SetForegroundColour("YELLOW")
                top_bs_v = BoxSizer(VERTICAL)
                run_b_b = Bitmap("run.jpg", BITMAP_TYPE_JPEG)
                stop_b_b = Bitmap("stop.jpg", BITMAP_TYPE_JPEG)
                run_b = BitmapButton(self.top_panel, id=1, bitmap=run_b_b)
                stop_b = BitmapButton(self.top_panel, id=12, bitmap=stop_b_b)
                top_bs_v.Add(run_b, proportion=1, flag=RIGHT, border=20)
                top_bs_v.Add(stop_b, proportion=1, flag=RIGHT, border=20)
                top_bs_h.Add(editor_tc, proportion=20, flag=EXPAND | LEFT | RIGHT, border=20)
                top_bs_h.Add(top_bs_v, proportion=1, flag=LEFT, border=50)
                self.top_panel.SetSizer(top_bs_h)
                self.Bind(EVT_BUTTON, MainFrame.run, id=1)
                self.Bind(EVT_BUTTON, self.stop, id=12)
            def bottom(self):
                global return_tc
                bottom_bs = BoxSizer()
                return_tc = TextCtrl(self.bottom_panel, id=-1, style=TE_READONLY | TE_MULTILINE | TE_WORDWRAP)
                return_tc.SetBackgroundColour("YELLOW")
                return_tc.SetForegroundColour("DARK STATE BLUE")
                bottom_bs.Add(return_tc, proportion=1, flag=EXPAND | ALL, border=10)
                self.bottom_panel.SetSizer(bottom_bs)
            @staticmethod
            def run(event):
                do(editor_tc.GetValue())
                return_tc.SetValue(read("result.txt"))
                clean("result.txt")
                
            def stop(self, event):
                return_tc.SetValue("EXIT")


        class MainApp(App):

            def OnInit(self):
                frame = MainFrame()
                frame.Show()
                return True


        if __name__ == "__main__":
            clean("result.txt")
            save("result.txt")

            myapp = MainApp()
            myapp.MainLoop()
            fasdasdf1()
    elif dakai == "migong":
        # class UnionSet(object):
        #     """
        #     并查集实现，构造函数中的matrix是一个numpy类型
        #     """

        #     def __init__(self, arr):
        #         self.parent = {pos: pos for pos in arr}
        #         self.count = len(arr)

        #     def find(self, root):
        #         if root == self.parent[root]:
        #             return root
        #         return self.find(self.parent[root])

        #     def union(self, root1, root2):
        #         self.parent[self.find(root1)] = self.find(root2)


        # class Maze(object):
        #     """
        #     迷宫生成类
        #     """

        #     def __init__(self, width=11, height=11):
        #         assert width >= 5 and height >= 5, "Length of width or height must be larger than 5."

        #         self.width = (width // 2) * 2 + 1
        #         self.height = (height // 2) * 2 + 1
        #         self.start = [1, 0]
        #         self.destination = [self.height - 2, self.width - 1]
        #         self.matrix = None
        #         self.path = []

        #     def print_matrix(self):
        #         matrix = deepcopy(self.matrix)
        #         for p in self.path:
        #             matrix[p[0]][p[1]] = 1
        #         for i in range(self.height):
        #             for j in range(self.width):
        #                 if matrix[i][j] == -1:
        #                     print('□', end='')
        #                 elif matrix[i][j] == 0:
        #                     print('  ', end='')
        #                 elif matrix[i][j] == 1:
        #                     print('■', end='')
        #             print('')

        #     def generate_matrix_dfs(self):
        #         # 地图初始化，并将出口和入口处的值设置为0
        #         self.matrix = -np.ones((self.height, self.width))
        #         self.matrix[self.start[0], self.start[1]] = 0
        #         self.matrix[self.destination[0], self.destination[1]] = 0

        #         visit_flag = [[0 for i in range(self.width)] for j in range(self.height)]

        #         def check(row, col, row_, col_):
        #             temp_sum = 0
        #             for d in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
        #                 temp_sum += self.matrix[row_ + d[0]][col_ + d[1]]
        #             return temp_sum <= -3

        #         def dfs(row, col):
        #             visit_flag[row][col] = 1
        #             self.matrix[row][col] = 0
        #             if row == self.start[0] and col == self.start[1] + 1:
        #                 return

        #             directions = [[0, 2], [0, -2], [2, 0], [-2, 0]]
        #             random.shuffle(directions)
        #             for d in directions:
        #                 row_, col_ = row + d[0], col + d[1]
        #                 if row_ > 0 and row_ < self.height - 1 and col_ > 0 and col_ < self.width - 1 and visit_flag[row_][
        #                     col_] == 0 and check(row, col, row_, col_):
        #                     if row == row_:
        #                         visit_flag[row][min(col, col_) + 1] = 1
        #                         self.matrix[row][min(col, col_) + 1] = 0
        #                     else:
        #                         visit_flag[min(row, row_) + 1][col] = 1
        #                         self.matrix[min(row, row_) + 1][col] = 0
        #                     dfs(row_, col_)

        #         dfs(self.destination[0], self.destination[1] - 1)
        #         self.matrix[self.start[0], self.start[1] + 1] = 0

        #     # 虽然说是prim算法，但是我感觉更像随机广度优先算法
        #     def generate_matrix_prim(self):
        #         # 地图初始化，并将出口和入口处的值设置为0
        #         self.matrix = -np.ones((self.height, self.width))

        #         def check(row, col):
        #             temp_sum = 0
        #             for d in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
        #                 temp_sum += self.matrix[row + d[0]][col + d[1]]
        #             return temp_sum < -3

        #         queue = []
        #         row, col = (np.random.randint(1, self.height - 1) // 2) * 2 + 1, (
        #                     np.random.randint(1, self.width - 1) // 2) * 2 + 1
        #         queue.append((row, col, -1, -1))
        #         while len(queue) != 0:
        #             row, col, r_, c_ = queue.pop(np.random.randint(0, len(queue)))
        #             if check(row, col):
        #                 self.matrix[row, col] = 0
        #                 if r_ != -1 and row == r_:
        #                     self.matrix[row][min(col, c_) + 1] = 0
        #                 elif r_ != -1 and col == c_:
        #                     self.matrix[min(row, r_) + 1][col] = 0
        #                 for d in [[0, 2], [0, -2], [2, 0], [-2, 0]]:
        #                     row_, col_ = row + d[0], col + d[1]
        #                     if row_ > 0 and row_ < self.height - 1 and col_ > 0 and col_ < self.width - 1 and self.matrix[row_][
        #                         col_] == -1:
        #                         queue.append((row_, col_, row, col))

        #         self.matrix[self.start[0], self.start[1]] = 0
        #         self.matrix[self.destination[0], self.destination[1]] = 0

        #     # 递归切分算法，还有问题，现在不可用
        #     def generate_matrix_split(self):
        #         # 地图初始化，并将出口和入口处的值设置为0
        #         self.matrix = -np.zeros((self.height, self.width))
        #         self.matrix[0, :] = -1
        #         self.matrix[self.height - 1, :] = -1
        #         self.matrix[:, 0] = -1
        #         self.matrix[:, self.width - 1] = -1

        #         # 随机生成位于(start, end)之间的偶数
        #         def get_random(start, end):
        #             rand = np.random.randint(start, end)
        #             if rand & 0x1 == 0:
        #                 return rand
        #             return get_random(start, end)

        #         # split函数的四个参数分别是左上角的行数、列数，右下角的行数、列数，墙壁只能在偶数行，偶数列
        #         def split(lr, lc, rr, rc):
        #             if rr - lr < 2 or rc - lc < 2:
        #                 return

        #             # 生成墙壁,墙壁只能是偶数点
        #             cur_row, cur_col = get_random(lr, rr), get_random(lc, rc)
        #             for i in range(lc, rc + 1):
        #                 self.matrix[cur_row][i] = -1
        #             for i in range(lr, rr + 1):
        #                 self.matrix[i][cur_col] = -1

        #             # 挖穿三面墙得到连通图，挖孔的点只能是偶数点
        #             wall_list = [
        #                 ("left", cur_row, [lc + 1, cur_col - 1]),
        #                 ("right", cur_row, [cur_col + 1, rc - 1]),
        #                 ("top", cur_col, [lr + 1, cur_row - 1]),
        #                 ("down", cur_col, [cur_row + 1, rr - 1])
        #             ]
        #             random.shuffle(wall_list)
        #             for wall in wall_list[:-1]:
        #                 if wall[2][1] - wall[2][0] < 1:
        #                     continue
        #                 if wall[0] in ["left", "right"]:
        #                     self.matrix[wall[1], get_random(wall[2][0], wall[2][1] + 1) + 1] = 0
        #                 else:
        #                     self.matrix[get_random(wall[2][0], wall[2][1] + 1), wall[1] + 1] = 0

        #             # self.print_matrix()
        #             # time.sleep(1)
        #             # 递归
        #             split(lr + 2, lc + 2, cur_row - 2, cur_col - 2)
        #             split(lr + 2, cur_col + 2, cur_row - 2, rc - 2)
        #             split(cur_row + 2, lc + 2, rr - 2, cur_col - 2)
        #             split(cur_row + 2, cur_col + 2, rr - 2, rc - 2)

        #             self.matrix[self.start[0], self.start[1]] = 0
        #             self.matrix[self.destination[0], self.destination[1]] = 0

        #         split(0, 0, self.height - 1, self.width - 1)

        #     # 最小生成树算法-kruskal（选边法）思想生成迷宫地图，这种实现方法最复杂。
        #     def generate_matrix_kruskal(self):
        #         # 地图初始化，并将出口和入口处的值设置为0
        #         self.matrix = -np.ones((self.height, self.width))

        #         def check(row, col):
        #             ans, counter = [], 0
        #             for d in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
        #                 row_, col_ = row + d[0], col + d[1]
        #                 if row_ > 0 and row_ < self.height - 1 and col_ > 0 and col_ < self.width - 1 and self.matrix[
        #                     row_, col_] == -1:
        #                     ans.append([d[0] * 2, d[1] * 2])
        #                     counter += 1
        #             if counter <= 1:
        #                 return []
        #             return ans

        #         nodes = set()
        #         row = 1
        #         while row < self.height:
        #             col = 1
        #             while col < self.width:
        #                 self.matrix[row, col] = 0
        #                 nodes.add((row, col))
        #                 col += 2
        #             row += 2

        #         unionset = UnionSet(nodes)
        #         while unionset.count > 1:
        #             row, col = nodes.pop()
        #             directions = check(row, col)
        #             if len(directions):
        #                 random.shuffle(directions)
        #                 for d in directions:
        #                     row_, col_ = row + d[0], col + d[1]
        #                     if unionset.find((row, col)) == unionset.find((row_, col_)):
        #                         continue
        #                     nodes.add((row, col))
        #                     unionset.count -= 1
        #                     unionset.union((row, col), (row_, col_))

        #                     if row == row_:
        #                         self.matrix[row][min(col, col_) + 1] = 0
        #                     else:
        #                         self.matrix[min(row, row_) + 1][col] = 0
        #                     break

        #         self.matrix[self.start[0], self.start[1]] = 0
        #         self.matrix[self.destination[0], self.destination[1]] = 0

        #     # 迷宫寻路算法dfs
        #     def find_path_dfs(self, destination):
        #         visited = [[0 for i in range(self.width)] for j in range(self.height)]

        #         def dfs(path):
        #             visited[path[-1][0]][path[-1][1]] = 1
        #             if path[-1][0] == destination[0] and path[-1][1] == destination[1]:
        #                 self.path = path[:]
        #                 return
        #             for d in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
        #                 row_, col_ = path[-1][0] + d[0], path[-1][1] + d[1]
        #                 if row_ > 0 and row_ < self.height - 1 and col_ > 0 and col_ < self.width and visited[row_][
        #                     col_] == 0 and self.matrix[row_][col_] == 0:
        #                     dfs(path + [[row_, col_]])

        #         dfs([[self.start[0], self.start[1]]])


        # if __name__ == '__main__':
        #     maze = Maze(51, 51)
        #     maze.generate_matrix_kruskal()
        #     maze.print_matrix()
        #     maze.find_path_dfs(maze.destination)
        #     print("answer", maze.path)
        #     maze.print_matrix()

        # import copy
        # import math


        # def draw_cell(canvas, row, col, color="#F2F2F2"):
        #     x0, y0 = col * cell_width, row * cell_width
        #     x1, y1 = x0 + cell_width, y0 + cell_width
        #     canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=color, width=0)


        # def draw_path(canvas, matrix, row, col, color, line_color):
        #     # 列
        #     if row + 1 < rows and matrix[row - 1][col] >= 1 and matrix[row + 1][col] >= 1:
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width
        #         x1, y1 = x0 + cell_width / 5, y0 + cell_width
        #     # 行
        #     elif col + 1 < cols and matrix[row][col - 1] >= 1 and matrix[row][col + 1] >= 1:
        #         x0, y0 = col * cell_width, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + cell_width, y0 + cell_width / 5
        #     # 左上角
        #     elif col + 1 < cols and row + 1 < rows and matrix[row][col + 1] >= 1 and matrix[row + 1][col] >= 1:
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + 3 * cell_width / 5, y0 + cell_width / 5
        #         canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=line_color, width=0)
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + cell_width / 5, y0 + 3 * cell_width / 5
        #     # 右上角
        #     elif row + 1 < rows and matrix[row][col - 1] >= 1 and matrix[row + 1][col] >= 1:
        #         x0, y0 = col * cell_width, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + 3 * cell_width / 5, y0 + cell_width / 5
        #         canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=line_color, width=0)
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + cell_width / 5, y0 + 3 * cell_width / 5
        #     # 左下角
        #     elif col + 1 < cols and matrix[row - 1][col] >= 1 and matrix[row][col + 1] >= 1:
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width
        #         x1, y1 = x0 + cell_width / 5, y0 + 3 * cell_width / 5
        #         canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=line_color, width=0)
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + 3 * cell_width / 5, y0 + cell_width / 5
        #     # 右下角
        #     elif matrix[row - 1][col] >= 1 and matrix[row][col - 1] >= 1:
        #         x0, y0 = col * cell_width, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + 3 * cell_width / 5, y0 + cell_width / 5
        #         canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=line_color, width=0)
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width
        #         x1, y1 = x0 + cell_width / 5, y0 + 3 * cell_width / 5
        #     else:
        #         x0, y0 = col * cell_width + 2 * cell_width / 5, row * cell_width + 2 * cell_width / 5
        #         x1, y1 = x0 + cell_width / 5, y0 + cell_width / 5
        #     canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=line_color, width=0)


        # def draw_maze(canvas, matrix, path, moves):

        #     for r in range(rows):
        #         for c in range(cols):
        #             if matrix[r][c] == 0:
        #                 draw_cell(canvas, r, c)
        #             elif matrix[r][c] == -1:
        #                 draw_cell(canvas, r, c, '#525288')
        #             elif matrix[r][c] == 1:
        #                 draw_cell(canvas, r, c)
        #                 draw_path(canvas, matrix, r, c, '#bc84a8', '#bc84a8')
        #             elif matrix[r][c] == 2:
        #                 draw_cell(canvas, r, c)
        #                 draw_path(canvas, matrix, r, c, '#ee3f4d', '#ee3f4d')
        #     for p in path:
        #         matrix[p[0]][p[1]] = 1
        #     for move in moves:
        #         matrix[move[0]][move[1]] = 2


        # def update_maze(canvas, matrix, path, moves):
        #     canvas.delete("all")
        #     matrix = copy.copy(matrix)
        #     for p in path:
        #         matrix[p[0]][p[1]] = 1
        #     for move in moves:
        #         matrix[move[0]][move[1]] = 2

        #     row, col = movement_list[-1]
        #     colors = ['#525288', '#F2F2F2', '#525288', '#F2F2F2', '#525288', '#F2F2F2', '#525288', '#F2F2F2']
        #     if level > 2:
        #         colors = ['#232323', '#252525', '#2a2a32', '#424242', '#434368', '#b4b4b4', '#525288', '#F2F2F2']

        #     for r in range(rows):
        #         for c in range(cols):
        #             distance = (row - r) * (row - r) + (col - c) * (col - c)
        #             if distance >= 100:
        #                 color = colors[0:2]
        #             elif distance >= 60:
        #                 color = colors[2:4]
        #             elif distance >= 30:
        #                 color = colors[4:6]
        #             else:
        #                 color = colors[6:8]

        #             if matrix[r][c] == 0:
        #                 draw_cell(canvas, r, c, color[1])
        #             elif matrix[r][c] == -1:
        #                 draw_cell(canvas, r, c, color[0])
        #             elif matrix[r][c] == 1:
        #                 draw_cell(canvas, r, c, color[1])
        #                 draw_path(canvas, matrix, r, c, '#bc84a8', '#bc84a8')
        #             elif matrix[r][c] == 2:
        #                 draw_cell(canvas, r, c, color[1])
        #                 draw_path(canvas, matrix, r, c, '#ee3f4d', '#ee3f4d')


        # def check_reach():
        #     global next_maze_flag
        #     if movement_list[-1] == maze.destination:
        #         print("Congratulations! You reach the goal! The step used: {}".format(click_counter))
        #         x0, y0 = width / 2 - 200, 30
        #         x1, y1 = x0 + 400, y0 + 40
        #         canvas.create_rectangle(x0, y0, x1, y1, fill='#F2F2F2', outline='#525288', width=3)
        #         canvas.create_text(width / 2, y0 + 20,
        #                            text="Congratulations! You reach the goal! Steps used: {}".format(click_counter),
        #                            fill="#525288")
        #         next_maze_flag = True


        # def _eventHandler(event):
        #     global movement_list
        #     global click_counter
        #     global next_maze_flag
        #     global level

        #     if not next_maze_flag and event.keysym in ['Left', 'Right', 'Up', 'Down']:
        #         click_counter += 1
        #         windows.title("Maze Level-{} Steps-{}".format(level, click_counter))
        #         cur_pos = movement_list[-1]
        #         ops = {'Left': [0, -1], 'Right': [0, 1], 'Up': [-1, 0], 'Down': [1, 0]}
        #         r_, c_ = cur_pos[0] + ops[event.keysym][0], cur_pos[1] + ops[event.keysym][1]
        #         if len(movement_list) > 1 and [r_, c_] == movement_list[-2]:
        #             movement_list.pop()
        #             while True:
        #                 cur_pos = movement_list[-1]
        #                 counter = 0
        #                 for d in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
        #                     r_, c_ = cur_pos[0] + d[0], cur_pos[1] + d[1]
        #                     if c_ >= 0 and maze.matrix[r_][c_] == 0:
        #                         counter += 1
        #                 if counter != 2:
        #                     break
        #                 movement_list.pop()
        #         elif r_ < maze.height and c_ < maze.width and maze.matrix[r_][c_] == 0:
        #             while True:
        #                 movement_list.append([r_, c_])
        #                 temp_list = []
        #                 for d in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
        #                     r__, c__ = r_ + d[0], c_ + d[1]
        #                     if c__ < maze.width and maze.matrix[r__][c__] == 0 and [r__, c__] != cur_pos:
        #                         temp_list.append([r__, c__])
        #                 if len(temp_list) != 1:
        #                     break
        #                 cur_pos = [r_, c_]
        #                 r_, c_ = temp_list[0]
        #         update_maze(canvas, maze.matrix, maze.path, movement_list)
        #         check_reach()
        #     elif next_maze_flag:
        #         next_maze_flag = False
        #         movement_list = [maze.start]
        #         click_counter = 0
        #         maze.generate_matrix_kruskal()
        #         maze.path = []
        #         draw_maze(canvas, maze.matrix, maze.path, movement_list)
        #         level += 1


        # def _paint(event):
        #     x, y = math.floor((event.y - 1) / cell_width), math.floor((event.x - 1) / cell_width)
        #     if maze.matrix[x][y] == 0:
        #         maze.find_path_dfs([x, y])
        #         update_maze(canvas, maze.matrix, maze.path, movement_list)


        # def _reset(event):
        #     maze.path = []
        #     update_maze(canvas, maze.matrix, maze.path, movement_list)


        # if __name__ == '__main__':
        #     # 基础参数
        #     cell_width = 20
        #     rows = 30
        #     cols = 44
        #     height = cell_width * rows
        #     width = cell_width * cols
        #     level = 1
        #     click_counter = 0
        #     next_maze_flag = False

        #     windows = tk.Tk()
        #     windows.title("迷宫小游戏")
        #     canvas = tk.Canvas(windows, background="#F2F2F2", width=width, height=height)
        #     canvas.pack()

        #     maze = Maze(cols, rows)
        #     movement_list = [maze.start]
        #     maze.generate_matrix_kruskal()
        #     draw_maze(canvas, maze.matrix, maze.path, movement_list)

        #     canvas.bind("<Button-1>", _paint)
        #     canvas.bind("<Button-3>", _reset)
        #     canvas.bind_all("<KeyPress>", _eventHandler)
        #     windows.mainloop()
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/996c33f4bd5a6f3563afe0c5d45b8cbe.html")
        fasdasdf1()
    elif dakai == "xiaoqiu":
        class GameWindow(object):
            '''创建游戏窗口类'''
            def __init__(self,*args,**kw):      
                self.window_length = 600
                self.window_wide = 500
                #绘制游戏窗口，设置窗口尺寸
                self.game_window = pygame.display.set_mode((self.window_length,self.window_wide))
                #设置游戏窗口标题
                pygame.display.set_caption("CatchBallGame")
                #定义游戏窗口背景颜色参数
                self.window_color = (135,206,250)

            def backgroud(self):
                #绘制游戏窗口背景颜色
                self.game_window.fill(self.window_color)

        class Ball(object):
            '''创建球类'''
            def __init__(self,*args,**kw):
                #设置球的半径、颜色、移动速度参数
                self.ball_color = (255,215,0)       
                self.move_x = 1
                self.move_y = 1
                self.radius = 10

            def ballready(self):
                #设置球的初始位置、
                self.ball_x = self.mouse_x
                self.ball_y = self.window_wide-self.rect_wide-self.radius
                #绘制球，设置反弹触发条件           
                pygame.draw.circle(self.game_window,self.ball_color,(self.ball_x,self.ball_y),self.radius)

            def ballmove(self):
                #绘制球，设置反弹触发条件           
                pygame.draw.circle(self.game_window,self.ball_color,(self.ball_x,self.ball_y),self.radius)      
                self.ball_x += self.move_x
                self.ball_y -= self.move_y
                #调用碰撞检测函数
                self.ball_window()
                self.ball_rect()
                #每接5次球球速增加一倍
                if self.distance < self.radius:
                    self.frequency += 1
                    if self.frequency == 5:
                        self.frequency = 0
                        self.move_x += self.move_x
                        self.move_y += self.move_y
                        self.point += self.point
                #设置游戏失败条件
                if self.ball_y > 520:
                    self.gameover = self.over_font.render("Game Over",False,(0,0,0))
                    self.game_window.blit(self.gameover,(100,130))
                    self.over_sign = 1

        class Rect(object):
            '''创建球拍类'''
            def __init__(self,*args,**kw):
                #设置球拍颜色参数
                self.rect_color = (255,0,0)
                self.rect_length = 100
                self.rect_wide = 10

            def rectmove(self):
                #获取鼠标位置参数
                self.mouse_x,self.mouse_y = pygame.mouse.get_pos()
                #绘制球拍，限定横向边界                    
                if self.mouse_x >= self.window_length-self.rect_length//2:
                    self.mouse_x = self.window_length-self.rect_length//2
                if self.mouse_x <= self.rect_length//2:
                    self.mouse_x = self.rect_length//2
                pygame.draw.rect(self.game_window,self.rect_color,((self.mouse_x-self.rect_length//2),(self.window_wide-self.rect_wide),self.rect_length,self.rect_wide))

        class Brick(object):
            def __init__(self,*args,**kw):
                #设置砖块颜色参数
                self.brick_color = (139,126,102)
                self.brick_list = [[1,1,1,1,1,1],[1,1,1,1,1,1],[1,1,1,1,1,1],[1,1,1,1,1,1],[1,1,1,1,1,1]]
                self.brick_length = 80
                self.brick_wide = 20

            def brickarrange(self):     
                for i in range(5):
                    for j in range(6):
                        self.brick_x = j*(self.brick_length+24)
                        self.brick_y = i*(self.brick_wide+20)+40
                        if self.brick_list[i][j] == 1:
                            #绘制砖块
                            pygame.draw.rect(self.game_window,self.brick_color,(self.brick_x,self.brick_y,self.brick_length,self.brick_wide))                   
                            #调用碰撞检测函数
                            self.ball_brick()                                       
                            if self.distanceb < self.radius:
                                self.brick_list[i][j] = 0
                                self.score += self.point
                #设置游戏胜利条件
                if self.brick_list == [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]]:
                    self.win = self.win_font.render("You Win",False,(0,0,0))
                    self.game_window.blit(self.win,(100,130))
                    self.win_sign = 1

        class Score(object):
            '''创建分数类'''
            def __init__(self,*args,**kw):      
                #设置初始分数
                self.score = 0
                #设置分数字体
                self.score_font = pygame.font.SysFont('arial',20)
                #设置初始加分点数
                self.point = 1
                #设置初始接球次数
                self.frequency = 0

            def countscore(self):
                #绘制玩家分数         
                my_score = self.score_font.render(str(self.score),False,(255,255,255))
                self.game_window.blit(my_score,(555,15))

        class GameOver(object):
            '''创建游戏结束类'''
            def __init__(self,*args,**kw):
                #设置Game Over字体
                self.over_font = pygame.font.SysFont('arial',80)
                #定义GameOver标识
                self.over_sign = 0

        class Win(object):
            '''创建游戏胜利类'''
            def __init__(self,*args,**kw):
                #设置You Win字体
                self.win_font = pygame.font.SysFont('arial',80)
                #定义Win标识
                self.win_sign = 0

        class Collision(object):
            '''碰撞检测类'''
            #球与窗口边框的碰撞检测
            def ball_window(self):
                if self.ball_x <= self.radius or self.ball_x >= (self.window_length-self.radius):
                    self.move_x = -self.move_x
                if self.ball_y <= self.radius:
                    self.move_y = -self.move_y

            #球与球拍的碰撞检测
            def ball_rect(self):
                #定义碰撞标识
                self.collision_sign_x = 0
                self.collision_sign_y = 0

                if self.ball_x < (self.mouse_x-self.rect_length//2):
                    self.closestpoint_x = self.mouse_x-self.rect_length//2
                    self.collision_sign_x = 1
                elif self.ball_x > (self.mouse_x+self.rect_length//2):
                    self.closestpoint_x = self.mouse_x+self.rect_length//2
                    self.collision_sign_x = 2
                else:
                    self.closestpoint_x = self.ball_x
                    self.collision_sign_x = 3

                if self.ball_y < (self.window_wide-self.rect_wide):
                    self.closestpoint_y = (self.window_wide-self.rect_wide)
                    self.collision_sign_y = 1
                elif self.ball_y > self.window_wide:
                    self.closestpoint_y = self.window_wide
                    self.collision_sign_y = 2
                else:
                    self.closestpoint_y = self.ball_y
                    self.collision_sign_y = 3
                #定义球拍到圆心最近点与圆心的距离
                self.distance = sqrt(pow(self.closestpoint_x-self.ball_x,2)+pow(self.closestpoint_y-self.ball_y,2))
                #球在球拍上左、上中、上右3种情况的碰撞检测
                if self.distance < self.radius and self.collision_sign_y == 1 and (self.collision_sign_x == 1 or self.collision_sign_x == 2):
                    if self.collision_sign_x == 1 and self.move_x > 0:
                        self.move_x = - self.move_x
                        self.move_y = - self.move_y
                    if self.collision_sign_x == 1 and self.move_x < 0:
                        self.move_y = - self.move_y
                    if self.collision_sign_x == 2 and self.move_x < 0:
                        self.move_x = - self.move_x
                        self.move_y = - self.move_y
                    if self.collision_sign_x == 2 and self.move_x > 0:
                        self.move_y = - self.move_y
                if self.distance < self.radius and self.collision_sign_y == 1 and self.collision_sign_x == 3:
                    self.move_y = - self.move_y
                #球在球拍左、右两侧中间的碰撞检测
                if self.distance < self.radius and self.collision_sign_y == 3:
                    self.move_x = - self.move_x

            #球与砖块的碰撞检测
            def ball_brick(self):
                #定义碰撞标识
                self.collision_sign_bx = 0
                self.collision_sign_by = 0

                if self.ball_x < self.brick_x:
                    self.closestpoint_bx = self.brick_x
                    self.collision_sign_bx = 1
                elif self.ball_x > self.brick_x+self.brick_length:
                    self.closestpoint_bx = self.brick_x+self.brick_length
                    self.collision_sign_bx = 2
                else:
                    self.closestpoint_bx = self.ball_x
                    self.collision_sign_bx = 3

                if self.ball_y < self.brick_y:
                    self.closestpoint_by = self.brick_y
                    self.collision_sign_by = 1
                elif self.ball_y > self.brick_y+self.brick_wide:
                    self.closestpoint_by = self.brick_y+self.brick_wide
                    self.collision_sign_by = 2
                else:
                    self.closestpoint_by = self.ball_y
                    self.collision_sign_by = 3
                #定义砖块到圆心最近点与圆心的距离
                self.distanceb = sqrt(pow(self.closestpoint_bx-self.ball_x,2)+pow(self.closestpoint_by-self.ball_y,2))
                #球在砖块上左、上中、上右3种情况的碰撞检测
                if self.distanceb < self.radius and self.collision_sign_by == 1 and (self.collision_sign_bx == 1 or self.collision_sign_bx == 2):
                    if self.collision_sign_bx == 1 and self.move_x > 0:
                        self.move_x = - self.move_x
                        self.move_y = - self.move_y
                    if self.collision_sign_bx == 1 and self.move_x < 0:
                        self.move_y = - self.move_y
                    if self.collision_sign_bx == 2 and self.move_x < 0:
                        self.move_x = - self.move_x
                        self.move_y = - self.move_y
                    if self.collision_sign_bx == 2 and self.move_x > 0:
                        self.move_y = - self.move_y
                if self.distanceb < self.radius and self.collision_sign_by == 1 and self.collision_sign_bx == 3:
                    self.move_y = - self.move_y
                #球在砖块下左、下中、下右3种情况的碰撞检测
                if self.distanceb < self.radius and self.collision_sign_by == 2 and (self.collision_sign_bx == 1 or self.collision_sign_bx == 2):
                    if self.collision_sign_bx == 1 and self.move_x > 0:
                        self.move_x = - self.move_x
                        self.move_y = - self.move_y
                    if self.collision_sign_bx == 1 and self.move_x < 0:
                        self.move_y = - self.move_y
                    if self.collision_sign_bx == 2 and self.move_x < 0:
                        self.move_x = - self.move_x
                        self.move_y = - self.move_y
                    if self.collision_sign_bx == 2 and self.move_x > 0:
                        self.move_y = - self.move_y
                if self.distanceb < self.radius and self.collision_sign_by == 2 and self.collision_sign_bx == 3:
                    self.move_y = - self.move_y
                #球在砖块左、右两侧中间的碰撞检测
                if self.distanceb < self.radius and self.collision_sign_by == 3:
                    self.move_x = - self.move_x

        class Main(GameWindow,Rect,Ball,Brick,Collision,Score,Win,GameOver):
            '''创建主程序类'''
            def __init__(self,*args,**kw):      
                super(Main,self).__init__(*args,**kw)
                super(GameWindow,self).__init__(*args,**kw)
                super(Rect,self).__init__(*args,**kw)
                super(Ball,self).__init__(*args,**kw)
                super(Brick,self).__init__(*args,**kw)
                super(Collision,self).__init__(*args,**kw)      
                super(Score,self).__init__(*args,**kw)
                super(Win,self).__init__(*args,**kw)
                #定义游戏开始标识
                start_sign = 0

                while True:         
                    self.backgroud()
                    self.rectmove()
                    self.countscore()           
                    
                    if self.over_sign == 1 or self.win_sign == 1:
                        break
                    #获取游戏窗口状态
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            fasdasdf1()
                        if event.type == MOUSEBUTTONDOWN:
                            pressed_array = pygame.mouse.get_pressed()
                            if pressed_array[0]:
                                start_sign = 1
                    if start_sign == 0:
                        self.ballready()
                    else:
                        self.ballmove()

                    self.brickarrange()

                    #更新游戏窗口
                    pygame.display.update()
                    #控制游戏窗口刷新频率
                    time.sleep(0.010)

        if __name__ == '__main__':
            pygame.init()
            pygame.font.init()
            catchball = Main()
    elif dakai == "music":
         
        

        class MP3Player(QWidget):
            def __init__(self):
                super().__init__()

                self.startTimeLabel = QLabel('00:00')
                self.endTimeLabel = QLabel('00:00')
                self.slider = QSlider(Qt.Horizontal, self)
                self.PlayModeBtn = QPushButton(self)
                self.playBtn = QPushButton(self)
                self.prevBtn = QPushButton(self)
                self.nextBtn = QPushButton(self)
                self.openBtn = QPushButton(self)
                self.musicList = QListWidget()
                self.song_formats = ['mp3', 'm4a', 'flac', 'wav', 'ogg']
                self.songs_list = []
                self.cur_playing_song = ''
                self.is_pause = True
                self.player = QMediaPlayer()
                self.is_switching = False
                self.playMode = 0
                self.settingfilename = 'config.ini'
                self.textLable = QLabel('前进的路上，也要记得欣赏沿途的风景呀!')
                self.infoLabel = QLabel('Mculover666 v2.0.0')

                self.playBtn.setStyleSheet("QPushButton{border-image: url(resource/image/play.png)}")
                self.playBtn.setFixedSize(48, 48)
                self.nextBtn.setStyleSheet("QPushButton{border-image: url(resource/image/next.png)}")
                self.nextBtn.setFixedSize(48, 48)
                self.prevBtn.setStyleSheet("QPushButton{border-image: url(resource/image/prev.png)}")
                self.prevBtn.setFixedSize(48, 48)
                self.openBtn.setStyleSheet("QPushButton{border-image: url(resource/image/open.png)}")
                self.openBtn.setFixedSize(24, 24)
                self.PlayModeBtn.setStyleSheet("QPushButton{border-image: url(resource/image/sequential.png)}")
                self.PlayModeBtn.setFixedSize(24, 24)

                self.timer = QTimer(self)
                self.timer.start(1000)
                self.timer.timeout.connect(self.playByMode)

                self.hBoxSlider = QHBoxLayout()
                self.hBoxSlider.addWidget(self.startTimeLabel)
                self.hBoxSlider.addWidget(self.slider)
                self.hBoxSlider.addWidget(self.endTimeLabel)

                self.hBoxButton = QHBoxLayout()
                self.hBoxButton.addWidget(self.PlayModeBtn)
                self.hBoxButton.addStretch(1)
                self.hBoxButton.addWidget(self.prevBtn)
                self.hBoxButton.addWidget(self.playBtn)
                self.hBoxButton.addWidget(self.nextBtn)
                self.hBoxButton.addStretch(1)
                self.hBoxButton.addWidget(self.openBtn)

                self.vBoxControl = QVBoxLayout()
                self.vBoxControl.addLayout(self.hBoxSlider)
                self.vBoxControl.addLayout(self.hBoxButton)

                self.hBoxAbout = QHBoxLayout()
                self.hBoxAbout.addWidget(self.textLable)
                self.hBoxAbout.addStretch(1)
                self.hBoxAbout.addWidget(self.infoLabel)

                self.vboxMain = QVBoxLayout()
                self.vboxMain.addWidget(self.musicList)
                self.vboxMain.addLayout(self.vBoxControl)
                self.vboxMain.addLayout(self.hBoxAbout)
                
                self.setLayout(self.vboxMain)

                self.openBtn.clicked.connect(self.openMusicFloder)
                self.playBtn.clicked.connect(self.playMusic)
                self.prevBtn.clicked.connect(self.prevMusic)
                self.nextBtn.clicked.connect(self.nextMusic)
                self.musicList.itemDoubleClicked.connect(self.doubleClicked)
                self.slider.sliderMoved[int].connect(lambda: self.player.setPosition(self.slider.value()))
                self.PlayModeBtn.clicked.connect(self.playModeSet)

                self.loadingSetting()

                self.initUI()

            # 初始化界面
            def initUI(self):
                self.resize(600, 400)
                self.center()
                self.setWindowTitle('音乐播放器')   
                self.setWindowIcon(QIcon('resource/image/favicon.ico'))
                self.show()
                
            # 窗口显示居中
            def center(self):
                qr = self.frameGeometry()
                cp = QDesktopWidget().availableGeometry().center()
                qr.moveCenter(cp)
                self.move(qr.topLeft())

            # 打开文件夹
            def openMusicFloder(self):
                self.cur_path = QFileDialog.getExistingDirectory(self, "选取音乐文件夹", './')
                if self.cur_path:
                    self.showMusicList()
                    self.cur_playing_song = ''
                    self.startTimeLabel.setText('00:00')
                    self.endTimeLabel.setText('00:00')
                    self.slider.setSliderPosition(0)
                    self.updateSetting()
                    self.is_pause = True
                    self.playBtn.setStyleSheet("QPushButton{border-image: url(resource/image/play.png)}")
            
            # 显示音乐列表
            def showMusicList(self):
                self.musicList.clear()
                for song in os.listdir(self.cur_path):
                    if song.split('.')[-1] in self.song_formats:
                        self.songs_list.append([song, os.path.join(self.cur_path, song).replace('\\', '/')])
                        self.musicList.addItem(song)
                self.musicList.setCurrentRow(0)
                if self.songs_list:
                        self.cur_playing_song = self.songs_list[self.musicList.currentRow()][-1]

            # 提示
            def Tips(self, message):
                QMessageBox.about(self, "提示", message)

            # 设置当前播放的音乐
            def setCurPlaying(self):
                self.cur_playing_song = self.songs_list[self.musicList.currentRow()][-1]
                self.player.setMedia(QMediaContent(QUrl(self.cur_playing_song)))

            # 播放/暂停播放
            def playMusic(self):
                if self.musicList.count() == 0:
                        self.Tips('当前路径内无可播放的音乐文件')
                        return
                if not self.player.isAudioAvailable():
                        self.setCurPlaying()
                if self.is_pause or self.is_switching:
                        self.player.play()
                        self.is_pause = False
                        self.playBtn.setStyleSheet("QPushButton{border-image: url(resource/image/pause.png)}")
                elif (not self.is_pause) and (not self.is_switching):
                        self.player.pause()
                        self.is_pause = True
                        self.playBtn.setStyleSheet("QPushButton{border-image: url(resource/image/play.png)}")
            
            # 上一曲
            def prevMusic(self):
                self.slider.setValue(0)
                if self.musicList.count() == 0:
                    self.Tips('当前路径内无可播放的音乐文件')
                    return
                pre_row = self.musicList.currentRow()-1 if self.musicList.currentRow() != 0 else self.musicList.count() - 1
                self.musicList.setCurrentRow(pre_row)
                self.is_switching = True
                self.setCurPlaying()
                self.playMusic()
                self.is_switching = False

            # 下一曲
            def nextMusic(self):
                self.slider.setValue(0)
                if self.musicList.count() == 0:
                    self.Tips('当前路径内无可播放的音乐文件')
                    return
                next_row = self.musicList.currentRow()+1 if self.musicList.currentRow() != self.musicList.count()-1 else 0
                self.musicList.setCurrentRow(next_row)
                self.is_switching = True
                self.setCurPlaying()
                self.playMusic()
                self.is_switching = False  

            # 双击歌曲名称播放音乐
            def doubleClicked(self):
                self.slider.setValue(0)
                self.is_switching = True
                self.setCurPlaying()
                self.playMusic()
                self.is_switching = False

            # 根据播放模式自动播放，并刷新进度条
            def playByMode(self):
                # 刷新进度条
                if (not self.is_pause) and (not self.is_switching):
                    self.slider.setMinimum(0)
                    self.slider.setMaximum(self.player.duration())
                    self.slider.setValue(self.slider.value() + 1000)
                
                # 顺序播放
                if (self.playMode == 0) and (not self.is_pause) and (not self.is_switching):
                    if self.musicList.count() == 0:
                        return
                    if self.player.position() == self.player.duration():
                        self.nextMusic()
                # 单曲循环
                elif (self.playMode == 1) and (not self.is_pause) and (not self.is_switching):
                    if self.musicList.count() == 0:
                        return
                    if self.player.position() == self.player.duration():
                        self.is_switching = True
                        self.setCurPlaying()
                        self.slider.setValue(0)
                        self.playMusic()
                        self.is_switching = False
                # 随机播放
                elif (self.playMode == 2) and (not self.is_pause) and (not self.is_switching):
                    if self.musicList.count() == 0:
                        return
                    if self.player.position() == self.player.duration():
                        self.is_switching = True
                        self.musicList.setCurrentRow(random.randint(0, self.musicList.count()-1))
                        self.setCurPlaying()
                        self.slider.setValue(0)
                        self.playMusic()
                        self.is_switching = False

            # 更新配置文件
            def updateSetting(self):
                config = configparser.ConfigParser()
                config.read(self.settingfilename)
                if not os.path.isfile(self.settingfilename):
                    config.add_section('MP3Player')
                config.set('MP3Player', 'PATH', self.cur_path)
                config.write(open(self.settingfilename, 'w'))

            # 加载配置文件
            def loadingSetting(self):
                config = configparser.ConfigParser()
                config.read(self.settingfilename)
                if not os.path.isfile(self.settingfilename):
                    return
                self.cur_path = config.get('MP3Player', 'PATH')
                self.showMusicList()
            
            # 播放模式设置
            def playModeSet(self):
                # 设置为单曲循环模式
                if self.playMode == 0:
                    self.playMode = 1
                    self.PlayModeBtn.setStyleSheet("QPushButton{border-image: url(resource/image/circulation.png)}")
                # 设置为随机播放模式
                elif self.playMode == 1:
                    self.playMode = 2
                    self.PlayModeBtn.setStyleSheet("QPushButton{border-image: url(resource/image/random.png)}")
                # 设置为顺序播放模式
                elif self.playMode == 2:
                    self.playMode = 0
                    self.PlayModeBtn.setStyleSheet("QPushButton{border-image: url(resource/image/sequential.png)}")

            # 确认用户是否要真正退出
            def closeEvent(self, event):
                reply = QMessageBox.question(self, 'Message',
                    "确定要退出吗？", QMessageBox.Yes | 
                    QMessageBox.No, QMessageBox.No)
                if reply == QMessageBox.Yes:
                    event.accept()
                    fasdasdf1()
                else:
                    event.ignore()


        from PyQt5.QtWidgets import (QApplication)

        if __name__ == '__main__':
            app = QApplication(sys.argv)
            ex = MP3Player()
            sys.exit(app.exec_())
            
    elif dakai == "dazi":
        # pygame初始化
        pygame.init()
        pygame.display.set_caption("打字游戏")
        screen = pygame.display.set_mode((800, 300))

        # 加载游戏所需要的各项图片素材
        bgimg = pygame.image.load("bg3.png")
        bgimg = pygame.transform.scale(bgimg, (800, 300))

        # 加载声音特效
        
        mytext = pygame.font.SysFont("kaiti",30)
        # 加载和播放背景音乐
    

        letterFont = pygame.font.SysFont(None, 80)
        letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
                   "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]

        word = random.choice(letters)
        x = random.randint(100, 700)
        y = 300  # 中间位置
        letter = {"word": word, "color": "blue", "x": x, "y": y}
        fenshu = 0
        letterWait = []  # 字母在letterWait中等待被消除
        letterWait.append(letter)
        add_time = time.time()  # 记录初始添加时间

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    fasdasdf1()

                if event.type == pygame.KEYDOWN:
                    
                    for letter in letterWait:
                        #作答区域 补全48行代码,按键消除字母
                        # ================================================================
                        if chr(event.key) == letter["word"]:
                            fenshu = fenshu + 1
                            letterWait.remove(letter)
                        else:
                            fenshu = fenshu - 1
                        # ================================================================
            screen.blit(bgimg, (0, 0))

            now = time.time()  # 当前时间
            if now - add_time > 2:  # 如果时间间隔超过两秒，就制作一个新的字母，添加到letterWait中
                word = random.choice(letters)
                x = random.randint(100, 700)
                y = 300
                letter = {"word": word, "x": x, "y": y}
                letterWait.append(letter)
                add_time = now  # 每次向letterWait中添加一个新字母，就更新添加时间为当前时间

            # 遍历letterWait，绘制每一个字母
            for letter in letterWait:
                word = letter["word"]
                x = letter["x"]
                y = letter["y"]
                textImage = letterFont.render(word, True, (255, 255, 255))
                screen.blit(textImage, (x, y))

                # 字母上移
                #作答区域 补充第73行代码：完成字母上移（y值减去一个数字）
                # ================================================================
                letter["y"] = y - 1
                # ================================================================

                #作答区域 补充78行代码，当字母（y值）超出画布时，列表移除字母字典
                # ================================================================
                if y <= 0:
                    fenshu = fenshu - 1
                    letterWait.remove(letter)
            if fenshu <= 0:
                fenshu = 0
            if fenshu >= 100:
                pygame.quit()
                print("你赢了！")
                # ================================================================
            text = mytext.render("分数" + str(fenshu),True,(0,0,0))
            screen.blit(text,(20,20))
            pygame.display.update()
            time.sleep(0.02)
    elif dakai == "shijian":
        def print_text(font,x,y,text,color=(255,255,255)):
            imgText=font.render(text,True,color)
            screen.blit(imgText,(x,y))
        def wrap_angle(angle):
            return angle % 360
        pygame.init()
        screen=pygame.display.set_mode([600,500])
        pygame.display.set_caption("AnalogClock")
        font = pygame.font.Font(None,36)
        orange=220,180,0
        white=255,255,255
        yellow=255,255,0
        pink=255,100,100
        pos_x=300
        pos_y=250
        radius=250
        angle=260
        while True:
            screen.fill([0,0,0])
            for event in pygame.event.get():
                if event.type==QUIT:
                    sys.exit()
            keys=pygame.key.get_pressed()
            if keys[K_ESCAPE]:
                sys.exit()
                screen.fill([0,0,100])
            pygame.draw.circle(screen,white,(pos_x,pos_y),radius,6)
            for n in range(1,13):
                angle=radians(n*(360/12)-90)
                x=cos(angle)*(radius-20)-10
                y=sin(angle)*(radius-20)-10
                print_text(font, pos_x+x, pos_y+y, str(n))
            today=datetime.today()
            hours=today.hour % 12
            minutes=today.minute
            seconds=today.second
            hour_angle=wrap_angle(hours*(360/12)-90)
            hour_angle=radians(hour_angle)
            hour_x=cos(hour_angle)*(radius-80)
            hour_y=sin(hour_angle)*(radius-80)
            target=(pos_x+hour_x,pos_y+hour_y)
            pygame.draw.line(screen,pink,(pos_x,pos_y),target,25)
            min_angle=wrap_angle(minutes*(260/60)-90)
            min_angle=radians(min_angle)
            min_x=cos(min_angle)*(radius-60)
            min_y=sin(min_angle)*(radius-60)
            target=(pos_x+min_x,pos_y+min_y)
            pygame.draw.line(screen,orange,(pos_x,pos_y),target,12)
            sec_angle=wrap_angle(seconds*(360/60)-90)
            sec_angle=radians(sec_angle)
            sec_x=cos(sec_angle)*(radius-40)
            sec_y=sin(sec_angle)*(radius-40)
            target=(pos_x+sec_x,pos_y+sec_y)
            pygame.draw.line(screen,yellow,(pos_x,pos_y),target,6)
            pygame.draw.circle(screen,white,(pos_x,pos_y),20)
            print_text(font, 0, 0, str(hours)+":"+str(minutes)+":"+str(seconds))
            pygame.display.update()
    elif dakai == "shipin":
        messagebox.showinfo("提示","该功能维护中，暂不开放")
        fasdasdf1()
    #     class Pro:
    #         header_ai={'Referer': 'http://www.iqiyi.com/',
    #                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.17 Safari/537.36'

    #         }
    #         header_you={'Referer': 'http://list.youku.com/category/video','User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
    #         header_pp = {'Referer': 'http://list.pptv.com/',
    #                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
    #         way=False
    #         def __init__(self):
    #             pass

    #         def search_movies_type(self,u_name,u_type,page):#两个参数 根据状态输出规则
    #             dic1 = {'m': 1, 't': 2, 'z': 6, 'd': 4, 'j': 3}
    #             dic2 = {'m': 96, 't': 97, 'z': 85, 'd': 100, 'j': 84}
    #             dic3 = {'m': 1, 't': 2, 'z': 4, 'd': 3, 'j': 210548}
    #             headers={}
    #             #爱奇艺 a/电影m:1 t:2 z:6 d:4 j:3  优酷y / m:96 t:97 z:85 d:100 j:84 pptv  p/m:1 t:2 z:4 d:3 j:210548
    #             url, pa_movie_title, pa_movie_url, pa_move_pic='','','',''
    #             url_aiqiyi='http://list.iqiyi.com/www/{}/-------------24-{}-1-iqiyi--.html'.format(dic1[u_type],page)
    #             url_youku='https://list.youku.com/category/show/c_{}_s_1_d_1_p_{}.html'.format(dic2[u_type],page)
    #             # url_pptv='http://list.pptv.com/category/type_{}.html'.format(dic3[u_type])
    #             url_pptv='http://list.pptv.com/channel_list.html?page={}&type={}'.format(page,dic3[u_type])
    #             pa_ai_movie_title = '//div[@class="site-piclist_pic"]/a[@class="site-piclist_pic_link"]/@title'
    #             pa_ai_movie_url = '//div[@class="site-piclist_pic"]/a[@class="site-piclist_pic_link"]/@href'
    #             pa_ai_movie_pic = '//div[@class="site-piclist_pic"]/a[@class="site-piclist_pic_link"]/img/@src'
    #             pa_you_movie_title='//div[@class="p-thumb"]/a/@title'
    #             pa_you_movie_url='//div[@class="p-thumb"]/a/@href'
    #             pa_you_movie_pic='//div[@class="p-thumb"]/img[@class="quic"]/@src'
    #             pa_pp_movie_title='//li/a[@class="ui-list-ct"]/@title'
    #             pa_pp_movie_url='//li/a[@class="ui-list-ct"]/@href'
    #             pa_pp_movie_pic='//li/a[@class="ui-list-ct"]/p[@class="ui-pic"]/img/@data-src2'
    #             if u_name=="a":#如果是爱奇艺
    #                 url=url_aiqiyi
    #                 pa_movie_title=pa_ai_movie_title
    #                 pa_movie_url=pa_ai_movie_url
    #                 pa_move_pic=pa_ai_movie_pic
    #                 headers=self.header_ai
    #             elif u_name=="y":#如果是优酷
    #                 url=url_youku
    #                 pa_movie_title=pa_you_movie_title
    #                 pa_movie_url=pa_you_movie_url
    #                 pa_move_pic=pa_you_movie_pic
    #                 headers=self.header_you

    #             elif u_name=="p":#如果是PPTV
    #                 url=url_pptv
    #                 pa_movie_title=pa_pp_movie_title
    #                 pa_movie_url=pa_pp_movie_url
    #                 pa_move_pic=pa_pp_movie_pic
    #                 headers=self.header_pp

    #             return url,pa_movie_title,pa_movie_url,pa_move_pic,headers


    #         def get_movie_res(self,u_name,u_type,page):#输出电影名 链接 图片
    #             url, pa_movie_title, pa_movie_url, pa_move_pic,headers=self.search_movies_type(u_name,u_type,page)
    #             res=requests.get(url=url,headers=headers).content.decode('utf-8')
    #             # print(res)
    #             html=etree.HTML(res)
    #             movie_url=html.xpath(pa_movie_url)
    #             movie_title=html.xpath(pa_movie_title)
    #             movie_src_pic=html.xpath(pa_move_pic)
    #             print(len(movie_title),movie_title)
    #             print(len(movie_url),movie_url)
    #             print(len(movie_src_pic),movie_src_pic)
    #             return movie_url,movie_title,movie_src_pic

    #         def change_urlink(self,lis):
    #             for i in range(len(lis)):
    #                 if '\\' in lis[i]:
    #                     lis[i] = lis[i].replace('\\', '')
    #             # print(lis)
    #             return lis

    #         def change_youku_link(self,urls):
    #             pa_link='//.+[.]html'
    #             if re.match(pa_link,urls):
    #                 urls='http:'+urls
    #             return urls

    #         def get_more_tv_urls(self,url,u_name,u_type):#获取电视剧分集链接
    #             tv_dic_new = {}
    #             if u_name == 'y':
    #                 url=self.change_youku_link(url)
    #                 res = requests.get(url, headers=self.header_you).text.encode(encoding='utf-8').decode('utf-8')
    #                 html = etree.HTML(res)
    #                 print(res)
    #                 if u_type=="m" or u_type=="t":
    #                     self.tv_more_title = html.xpath('//div[@class="item item-num"]/@title')
    #                     self.tv_more_url = html.xpath('//div[@class="item item-num"]/a[@class="sn"]/@href')
    #                 elif u_type=="d":
    #                     self.tv_more_title = html.xpath('//div[@class="item item-txt"]/@title')
    #                     self.tv_more_url = html.xpath('//div[@class="item item-txt"]/a[@class="sn"]/@href')
    #                 elif u_type=="z":
    #                     self.tv_more_title = html.xpath('//div[@class="item item-cover"]/@title')
    #                     self.tv_more_url = html.xpath('//div[@class="item item-cover"]/a/@href')
    #                 elif u_type == "j":
    #                     self.tv_more_title = html.xpath('//div[@class="item item-cover current"]/@title')
    #                     self.tv_more_url = html.xpath('//div[@class="item item-cover current"]/a/@href')
    #             elif u_name == 'a':
    #                 res = requests.get(url, headers=self.header_ai).text.encode(encoding='utf-8').decode('utf-8')
    #                 html = etree.HTML(res)
    #                 print(res)
    #                 if u_type=="m" or u_type=="t" or u_type=='d':
    #                     self.tv_more_title = html.xpath(
    #                         '//ul/li[@data-albumlist-elem="playItem"]/div[@class="site-piclist_pic"]/a[1]/@title')
    #                     self.tv_more_url = html.xpath(
    #                         '//ul/li[@data-albumlist-elem="playItem"]/div[@class="site-piclist_pic"]/a[1]/@href')
    #                 elif u_type=="z" or u_type=="j":
    #                     self.tv_more_title = html.xpath('//div[@class="recoAlbumTit"]/a[1]/@title')
    #                     self.tv_more_url = html.xpath('//div[@class="recoAlbumTit"]/a[1]/@href')
    #             elif u_name == 'p':
    #                 res = requests.get(url, headers=self.header_pp).text.encode(encoding='utf-8').decode('utf-8')
    #                 # html = etree.HTML(res)
    #                 self.tv_more_url2 = re.compile('{"url":"(.+?)"').findall(res)
    #                 self.tv_more_url = self.change_urlink(self.tv_more_url2)
    #                 self.tv_more_title = ["第{}集".format(x) for x in range(1, len(self.tv_more_url) + 1)]
    #             for i, j in zip(self.tv_more_title, self.tv_more_url):
    #                 tv_dic_new[i] = j
    #             print(len(self.tv_more_title), self.tv_more_title)
    #             print(len(self.tv_more_url), self.tv_more_url)
    #             print(tv_dic_new)
    #             return tv_dic_new

    #         def url_change(self,url,flag):
    #             pa_url='http://www.iqiyi.com/a_[.+].html'
    #             if flag=="0":#通道1
    #                 if re.match(pa_url, url):
    #                     _url = url.replace('a', 'v')
    #                 else:
    #                     _url=url
    #                 # new_url='http://www.wq114.org/weixin.php?url={}'.format(_url[21:])
    #                 new_url='http://www.wq114.org/weixin.php?url={}'.format(_url)
    #                 return new_url
    #             elif flag == "1":
    #                 if re.match(pa_url, url):
    #                     _url = url.replace('a', 'v')
    #                 else:
    #                     _url = url
    #                 new_url='http://www.wmxz.wang/video.php?url={}'.format(_url)
    #                 return new_url


    #         def play_movie(self,url,flag):
    #             play_url=self.url_change(url,flag)
    #             webbrowser.open(play_url)


    #     if __name__ == '__main__':
    #         p=Pro()

    #     # from urllib.request import urlopen

    #     class Movie_app:
    #         def __init__(self):
    #             self.win=Tk()
    #             self.win.geometry('600x420')
    #             self.win.title("爱奇艺-优酷-PPTV视频播放下载器V3.1")
    #             self.creat_res()
    #             self.creat_radiores()
    #             self.config()
    #             self.page=1
    #             self.p=Pro()
    #             self.win.mainloop()


    #         def creat_res(self):
    #             self.temp=StringVar()#url地址
    #             self.temp2=StringVar()
    #             self.t1=StringVar()#通道
    #             self.t3=StringVar()#爱奇艺，优酷，PPTV
    #             self.La_title=Label(self.win,text="地址:")
    #             self.La_way=Label(self.win,text="选择视频通道:")
    #             self.R_way1=Radiobutton(self.win,text="通道A",variable=self.t1,value=True)
    #             self.R_way2=Radiobutton(self.win,text="通道B",variable=self.t1,value=False)
    #             self.R_aiqiyi=Radiobutton(self.win,text="爱奇艺",variable=self.t3,value="a")
    #             self.R_youku=Radiobutton(self.win,text="优酷",variable=self.t3,value="y")
    #             self.R_pptv=Radiobutton(self.win,text="PPTV",variable=self.t3,value="p")
    #             self.B_play=Button(self.win,text="播放▶")
    #             self.B_uppage=Button(self.win,text="上页")
    #             self.B_nextpage=Button(self.win,text="下页")
    #             self.B_search=Button(self.win,text="♣搜索全站♠")
    #             self.La_mesasge=Label(self.win,text="☜  ⇠☸⇢  ☞",bg="pink")
    #             self.La_page=Label(self.win,bg="#BFEFFF")
    #             self.S_croll=Scrollbar(self.win)
    #             self.L_box=Listbox(self.win,bg="#BFEFFF",selectmode=SINGLE)
    #             self.E_address=Entry(self.win,textvariable=self.temp)
    #             self.La_title.place(x=10,y=50,width=50,height=30)
    #             self.E_address.place(x=70,y=50,width=200,height=30)
    #             self.B_play.place(x=300,y=50,width=50,height=30)
    #             self.R_way1.place(x=160,y=10,width=70,height=30)
    #             self.R_way2.place(x=240,y=10,width=70,height=30)
    #             self.La_way.place(x=10,y=10,width=100,height=30)
    #             self.R_aiqiyi.place(x=20,y=100,width=70,height=30)
    #             self.R_youku.place(x=90,y=100,width=70,height=30)
    #             self.R_pptv.place(x=160,y=100,width=70,height=30)
    #             self.B_search.place(x=252,y=140,width=100,height=30)
    #             self.La_mesasge.place(x=80,y=125,width=90,height=20)
    #             self.L_box.place(x=10,y=180,width=252,height=230)
    #             self.S_croll.place(x=260,y=180,width=20,height=230)
    #             self.B_uppage.place(x=10,y=140,width=50,height=30)
    #             self.B_nextpage.place(x=180,y=140,width=50,height=30)
    #             self.La_page.place(x=80,y=150,width=90,height=28)

    #         def creat_radiores(self):
    #             self.movie=StringVar()#电影
    #             self.S_croll2=Scrollbar()#分集
    #             self.La_pic=Label(self.win,bg="#E6E6FA")
    #             self.La_movie_message=Listbox(self.win,bg="#7EC0EE")
    #             self.R_movie=Radiobutton(self.win,text="电影",variable=self.movie,value="m")
    #             self.tv=Radiobutton(self.win,text="电视剧",variable=self.movie,value="t")
    #             self.zhongyi=Radiobutton(self.win,text="综艺",variable=self.movie,value="z")
    #             self.dongman=Radiobutton(self.win,text="动漫",variable=self.movie,value="d")
    #             self.jilupian=Radiobutton(self.win,text="纪录片",variable=self.movie,value="j")
    #             self.B_view=Button(self.win,text="✤查看✤")
    #             self.B_info=Button(self.win,text="使用说明")
    #             self.B_clearbox=Button(self.win,text="清空列表")
    #             self.B_add=Button(self.win,text="添加到播放列表")
    #             self.R_movie.place(x=290,y=180,width=80,height=30)
    #             self.B_view.place(x=290,y=330,width=70,height=30)
    #             self.B_add.place(x=370,y=255,width=100,height=30)
    #             self.B_clearbox.place(x=500,y=255,width=70,height=30)
    #             self.tv.place(x=290,y=210,width=80,height=30)
    #             self.zhongyi.place(x=290,y=240,width=80,height=30)
    #             self.dongman.place(x=290,y=270,width=80,height=30)
    #             self.jilupian.place(x=290,y=300,width=80,height=30)
    #             self.La_movie_message.place(x=370,y=290,width=200,height=120)
    #             self.La_pic.place(x=370,y=10,width=200,height=240)
    #             self.B_info.place(x=290,y=370,width=70,height=30)
    #             self.S_croll2.place(x=568,y=290,width=20,height=120)

    #         def show_info(self):
    #             msg="""
    #             1.输入视频播放地址，即可播放
    #               选择A或者B可切换视频源
    #             2.选择视频网，选择电视剧或者电影，
    #               搜索全网后选择想要看得影片，点
    #               查看，在右方list里选择分集视频
    #               添加到播放列表里点选播放
    #             """
    #             messagebox.showinfo(title="使用说明",message=msg)

    #         def config(self):
    #             self.t1.set(True)
    #             self.B_play.config(command=self.play_url_movie)
    #             self.B_search.config(command=self.search_full_movie)
    #             self.B_info.config(command=self.show_info)
    #             self.S_croll.config(command=self.L_box.yview)
    #             self.L_box['yscrollcommand']=self.S_croll.set
    #             self.S_croll2.config(command=self.La_movie_message.yview)
    #             self.La_movie_message['yscrollcommand']=self.S_croll2.set
    #             self.B_view.config(command=self.view_movies)
    #             self.B_add.config(command=self.add_play_list)
    #             self.B_clearbox.config(command=self.clear_lisbox2)
    #             self.B_uppage.config(command=self.uppage_)
    #             self.B_nextpage.config(command=self.nextpage_)

    #         def uppage_(self):
    #             print('---------上一页---------')
    #             self.page-=1
    #             print(self.page)
    #             if self.page<1:
    #                 self.page=1

    #         def nextpage_(self):
    #             print('----------下一页--------')
    #             self.page+=1
    #             print(self.page)
    #             if self.t3=="a" or self.t3=="y":
    #                 if self.page>30:
    #                     self.page=30
    #             elif self.t3=="p":
    #                 if self.movie=="m":
    #                     if self.page>165:
    #                         self.page=165
    #                 elif self.movie == "t":
    #                     if self.page > 85:
    #                         self.page = 85
    #                 elif self.movie == "z":
    #                     if self.page > 38:
    #                         self.page = 38
    #                 elif self.movie == "d":
    #                     if self.page > 146:
    #                         self.page = 146
    #                 elif self.movie == "j":
    #                     if self.page > 40:
    #                         self.page = 40

    #         def clear_lisbox(self):
    #             self.L_box.delete(0,END)

    #         def clear_lisbox2(self):
    #             self.La_movie_message.delete(0,END)

    #         def search_full_movie(self):
    #             print("-----search----")
    #             self.La_page.config(text="当前页:{}".format(self.page))
    #             self.clear_lisbox()
    #             try:
    #                 movie_url, movie_title, movie_src_pic=self.p.get_movie_res(self.t3.get(),self.movie.get(),self.page)
    #                 self.movie_dic={}
    #                 for i,j,k in zip(movie_title,movie_url,movie_src_pic):
    #                     self.movie_dic[i]=[j,k]
    #                 for title in movie_title:
    #                     self.L_box.insert(END,title)
    #                 print(self.movie_dic)
    #                 return self.movie_dic
    #             except:
    #                 messagebox.showerror(title='警告',message='请选择电影或者电视剧')

    #         def add_play_list(self):
    #             print('---------playlist----------')
    #             print(self.movie_dic)
    #             if self.La_movie_message.get(self.La_movie_message.curselection())=="":
    #                 messagebox.showwarning(title="警告",message='请在列表选择影片')
    #             else:
    #                 print("电影名字:",self.La_movie_message.get(self.La_movie_message.curselection()))
    #                 if self.movie.get()!="m":
    #                     self.temp.set(self.new_more_dic[self.La_movie_message.get(self.La_movie_message.curselection())])
    #                 else:
    #                     self.temp.set(self.movie_dic[self.La_movie_message.get(self.La_movie_message.curselection())][0])


    #         def view_pic(self,pic_url):
    #             print('--------viewpic---------')
    #             pa_url_check=r'//.+[.]jpg'
    #             if re.match(pa_url_check,pic_url):
    #                 print("ok")
    #                 pic_url="http:"+pic_url
    #             print(pic_url)
    #             data=requests.get(pic_url).content
    #             # data=urlopen(pic_url).read()
    #             io_data=io.BytesIO(data)
    #             self.img=Image.open(io_data)
    #             self.u=ImageTk.PhotoImage(self.img)
    #             self.La_pic.config(image=self.u)

    #         def view_movies(self):
    #             print("--------viewmovie----------")
    #             cur_index=self.L_box.curselection()
    #             print(self.L_box.get(cur_index))
    #             if self.movie.get()!="m":#非电影类
    #                 self.new_more_dic=self.p.get_more_tv_urls(self.movie_dic[self.L_box.get(cur_index)][0],self.t3.get(),self.movie.get())
    #                 print(self.new_more_dic)
    #                 for i,fenji_url in self.new_more_dic.items():
    #                     self.La_movie_message.insert(END, i)
    #             else:#电影类
    #                 self.La_movie_message.insert(END,self.L_box.get(cur_index))
    #             self.view_pic(self.movie_dic[self.L_box.get(self.L_box.curselection())][1])#加载图片

    #         def play_url_movie(self):
    #             print("--------ok-----------")
    #             # print(type(self.t1.get()),self.t1.get())
    #             if self.temp.get()=="":
    #                 messagebox.showwarning(title="警告",message="请先输入视频地址")
    #             else:
    #                 if self.t1.get()!="":
    #                     self.p.play_movie(self.temp.get(),self.t1.get())
    #                 else:
    #                     messagebox.showwarning(title='警告',message='请选择通道')


    #     m=Movie_app()
    elif dakai == "cortana":
        
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/612a2e8f7ee61e4745beccc5cd20bf33.html")
        fasdasdf1()   
    elif dakai == "mofang":
        
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/76d2c8e1bf727054db00233b7020d52b.html")
        fasdasdf1()
    elif dakai == "tuixiang":
        FPS = 100 # frames per second to update the screen
        WINWIDTH = 800 # width of the program's window, in pixels
        WINHEIGHT = 600 # height in pixels
        HALF_WINWIDTH = int(WINWIDTH / 2)
        HALF_WINHEIGHT = int(WINHEIGHT / 2)
         
        # The total width and height of each tile in pixels.
        TILEWIDTH = 50
        TILEHEIGHT = 85
        TILEFLOORHEIGHT = 40
         
        CAM_MOVE_SPEED = 5 # how many pixels per frame the camera moves
         
        # The percentage of outdoor tiles that have additional
        # decoration on them, such as a tree or rock.
        OUTSIDE_DECORATION_PCT = 20
         
        BRIGHTBLUE = (  0, 170, 255)
        WHITE      = (255, 255, 255)
        BGCOLOR = BRIGHTBLUE
        TEXTCOLOR = WHITE
         
        UP = 'up'
        DOWN = 'down'
        LEFT = 'left'
        RIGHT = 'right'
         
         
        def main():
            global FPSCLOCK, DISPLAYSURF, IMAGESDICT, TILEMAPPING, OUTSIDEDECOMAPPING, BASICFONT, PLAYERIMAGES, currentImage
         
            # Pygame initialization and basic set up of the global variables.
            pygame.init()
            FPSCLOCK = pygame.time.Clock()
         
            # Because the Surface object stored in DISPLAYSURF was returned
            # from the pygame.display.set_mode() function, this is the
            # Surface object that is drawn to the actual computer screen
            # when pygame.display.update() is called.
            DISPLAYSURF = pygame.display.set_mode((WINWIDTH, WINHEIGHT))
         
            pygame.display.set_caption('Star Pusher')
            BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
         
            # A global dict value that will contain all the Pygame
            # Surface objects returned by pygame.image.load().
            IMAGESDICT = {'uncovered goal': pygame.image.load('RedSelector.png'),
                          'covered goal': pygame.image.load('Selector.png'),
                          'star': pygame.image.load('Star.png'),
                          'corner': pygame.image.load('Wall_Block_Tall.png'),
                          'wall': pygame.image.load('Wood_Block_Tall.png'),
                          'inside floor': pygame.image.load('Plain_Block.png'),
                          'outside floor': pygame.image.load('Grass_Block.png'),
                          'title': pygame.image.load('star_title.png'),
                          'solved': pygame.image.load('star_solved.png'),
                          'princess': pygame.image.load('princess.png'),
                          'boy': pygame.image.load('boy.png'),
                          'catgirl': pygame.image.load('catgirl.png'),
                          'horngirl': pygame.image.load('horngirl.png'),
                          'pinkgirl': pygame.image.load('pinkgirl.png'),
                          'rock': pygame.image.load('Rock.png'),
                          'short tree': pygame.image.load('Tree_Short.png'),
                          'tall tree': pygame.image.load('Tree_Tall.png'),
                          'ugly tree': pygame.image.load('Tree_Ugly.png')}
         
            # These dict values are global, and map the character that appears
            # in the level file to the Surface object it represents.
            TILEMAPPING = {'x': IMAGESDICT['corner'],
                           '#': IMAGESDICT['wall'],
                           'o': IMAGESDICT['inside floor'],
                           ' ': IMAGESDICT['outside floor']}
            OUTSIDEDECOMAPPING = {'1': IMAGESDICT['rock'],
                                  '2': IMAGESDICT['short tree'],
                                  '3': IMAGESDICT['tall tree'],
                                  '4': IMAGESDICT['ugly tree']}
         
            # PLAYERIMAGES is a list of all possible characters the player can be.
            # currentImage is the index of the player's current player image.
            currentImage = 0
            PLAYERIMAGES = [IMAGESDICT['princess'],
                            IMAGESDICT['boy'],
                            IMAGESDICT['catgirl'],
                            IMAGESDICT['horngirl'],
                            IMAGESDICT['pinkgirl']]
         
            startScreen() # show the title screen until the user presses a key
         
            # Read in the levels from the text file. See the readLevelsFile() for
            # details on the format of this file and how to make your own levels.
            levels = readLevelsFile('starPusherLevels.txt')
            currentLevelIndex = 0
         
            # The main game loop. This loop runs a single level, when the user
            # finishes that level, the next/previous level is loaded.
            while True: # main game loop
                # Run the level to actually start playing the game:
                result = runLevel(levels, currentLevelIndex)
         
                if result in ('solved', 'next'):
                    # Go to the next level.
                    currentLevelIndex += 1
                    if currentLevelIndex >= len(levels):
                        # If there are no more levels, go back to the first one.
                        currentLevelIndex = 0
                elif result == 'back':
                    # Go to the previous level.
                    currentLevelIndex -= 1
                    if currentLevelIndex < 0:
                        # If there are no previous levels, go to the last one.
                        currentLevelIndex = len(levels)-1
                
                elif result == 'reset':
                    pass # Do nothing. Loop re-calls runLevel() to reset the level
         
         
        def runLevel(levels, levelNum):
            global currentImage
            levelObj = levels[levelNum]
            mapObj = decorateMap(levelObj['mapObj'], levelObj['startState']['player'])
            gameStateObj = copy.deepcopy(levelObj['startState'])
            mapNeedsRedraw = True # set to True to call drawMap()
            levelSurf = BASICFONT.render('Level %s of %s' % (levelNum + 1, len(levels)), 1, TEXTCOLOR)
            levelRect = levelSurf.get_rect()
            levelRect.bottomleft = (20, WINHEIGHT - 35)
            mapWidth = len(mapObj) * TILEWIDTH
            mapHeight = (len(mapObj[0]) - 1) * TILEFLOORHEIGHT + TILEHEIGHT
            MAX_CAM_X_PAN = abs(HALF_WINHEIGHT - int(mapHeight / 2)) + TILEWIDTH
            MAX_CAM_Y_PAN = abs(HALF_WINWIDTH - int(mapWidth / 2)) + TILEHEIGHT
         
            levelIsComplete = False
            # Track how much the camera has moved:
            cameraOffsetX = 0
            cameraOffsetY = 0
            # Track if the keys to move the camera are being held down:
            cameraUp = False
            cameraDown = False
            cameraLeft = False
            cameraRight = False
         
            while True: # main game loop
                # Reset these variables:
                playerMoveTo = None
                keyPressed = False
         
                for event in pygame.event.get(): # event handling loop
                    if event.type == QUIT:
                        # Player clicked the "X" at the corner of the window.
                        terminate()
         
                    elif event.type == KEYDOWN:
                        # Handle key presses
                        keyPressed = True
                        if event.key == K_LEFT:
                            playerMoveTo = LEFT
                        elif event.key == K_RIGHT:
                            playerMoveTo = RIGHT
                        elif event.key == K_UP:
                            playerMoveTo = UP
                        elif event.key == K_DOWN:
                            playerMoveTo = DOWN
         
                        # Set the camera move mode.
                        elif event.key == K_a:
                            cameraLeft = True
                        elif event.key == K_d:
                            cameraRight = True
                        elif event.key == K_w:
                            cameraUp = True
                        elif event.key == K_s:
                            cameraDown = True
         
                        elif event.key == K_n:
                            return 'next'
                        elif event.key == K_b:
                            return 'back'
         
                        elif event.key == K_ESCAPE:
                            terminate() # Esc key quits.
                        elif event.key == K_BACKSPACE:
                            return 'reset' # Reset the level.
                        elif event.key == K_p:
                            # Change the player image to the next one.
                            currentImage += 1
                            if currentImage >= len(PLAYERIMAGES):
                                # After the last player image, use the first one.
                                currentImage = 0
                            mapNeedsRedraw = True
         
                    elif event.type == KEYUP:
                        # Unset the camera move mode.
                        if event.key == K_a:
                            cameraLeft = False
                        elif event.key == K_d:
                            cameraRight = False
                        elif event.key == K_w:
                            cameraUp = False
                        elif event.key == K_s:
                            cameraDown = False
         
                if playerMoveTo != None and not levelIsComplete:
                    # If the player pushed a key to move, make the move
                    # (if possible) and push any stars that are pushable.
                    moved = makeMove(mapObj, gameStateObj, playerMoveTo)
         
                    if moved:
                        # increment the step counter.
                        gameStateObj['stepCounter'] += 1
                        mapNeedsRedraw = True
         
                    if isLevelFinished(levelObj, gameStateObj):
                        # level is solved, we should show the "Solved!" image.
                        levelIsComplete = True
                        keyPressed = False
         
                DISPLAYSURF.fill(BGCOLOR)
         
                if mapNeedsRedraw:
                    mapSurf = drawMap(mapObj, gameStateObj, levelObj['goals'])
                    mapNeedsRedraw = False
         
                if cameraUp and cameraOffsetY < MAX_CAM_X_PAN:
                    cameraOffsetY += CAM_MOVE_SPEED
                elif cameraDown and cameraOffsetY > -MAX_CAM_X_PAN:
                    cameraOffsetY -= CAM_MOVE_SPEED
                if cameraLeft and cameraOffsetX < MAX_CAM_Y_PAN:
                    cameraOffsetX += CAM_MOVE_SPEED
                elif cameraRight and cameraOffsetX > -MAX_CAM_Y_PAN:
                    cameraOffsetX -= CAM_MOVE_SPEED
         
                # Adjust mapSurf's Rect object based on the camera offset.
                mapSurfRect = mapSurf.get_rect()
                mapSurfRect.center = (HALF_WINWIDTH + cameraOffsetX, HALF_WINHEIGHT + cameraOffsetY)
         
                # Draw mapSurf to the DISPLAYSURF Surface object.
                DISPLAYSURF.blit(mapSurf, mapSurfRect)
         
                DISPLAYSURF.blit(levelSurf, levelRect)
                stepSurf = BASICFONT.render('Steps: %s' % (gameStateObj['stepCounter']), 1, TEXTCOLOR)
                stepRect = stepSurf.get_rect()
                stepRect.bottomleft = (20, WINHEIGHT - 10)
                DISPLAYSURF.blit(stepSurf, stepRect)
         
                if levelIsComplete:
                    # is solved, show the "Solved!" image until the player
                    # has pressed a key.
                    solvedRect = IMAGESDICT['solved'].get_rect()
                    solvedRect.center = (HALF_WINWIDTH, HALF_WINHEIGHT)
                    DISPLAYSURF.blit(IMAGESDICT['solved'], solvedRect)
         
                    if keyPressed:
                        return 'solved'
         
                pygame.display.update() # draw DISPLAYSURF to the screen.
                FPSCLOCK.tick()
         
         
        def isWall(mapObj, x, y):
            """Returns True if the (x, y) position on
            the map is a wall, otherwise return False."""
            if x < 0 or x >= len(mapObj) or y < 0 or y >= len(mapObj[x]):
                return False # x and y aren't actually on the map.
            elif mapObj[x][y] in ('#', 'x'):
                return True # wall is blocking
            return False
         
         
        def decorateMap(mapObj, startxy):
            """Makes a copy of the given map object and modifies it.
            Here is what is done to it:
                * Walls that are corners are turned into corner pieces.
                * The outside/inside floor tile distinction is made.
                * Tree/rock decorations are randomly added to the outside tiles.
            Returns the decorated map object."""
         
            startx, starty = startxy # Syntactic sugar
         
            # Copy the map object so we don't modify the original passed
            mapObjCopy = copy.deepcopy(mapObj)
         
            # Remove the non-wall characters from the map data
            for x in range(len(mapObjCopy)):
                for y in range(len(mapObjCopy[0])):
                    if mapObjCopy[x][y] in ('$', '.', '@', '+', '*'):
                        mapObjCopy[x][y] = ' '
         
            # Flood fill to determine inside/outside floor tiles.
            floodFill(mapObjCopy, startx, starty, ' ', 'o')
         
            # Convert the adjoined walls into corner tiles.
            for x in range(len(mapObjCopy)):
                for y in range(len(mapObjCopy[0])):
         
                    if mapObjCopy[x][y] == '#':
                        if (isWall(mapObjCopy, x, y-1) and isWall(mapObjCopy, x+1, y)) or \
                           (isWall(mapObjCopy, x+1, y) and isWall(mapObjCopy, x, y+1)) or \
                           (isWall(mapObjCopy, x, y+1) and isWall(mapObjCopy, x-1, y)) or \
                           (isWall(mapObjCopy, x-1, y) and isWall(mapObjCopy, x, y-1)):
                            mapObjCopy[x][y] = 'x'
         
                    elif mapObjCopy[x][y] == ' ' and random.randint(0, 99) < OUTSIDE_DECORATION_PCT:
                        mapObjCopy[x][y] = random.choice(list(OUTSIDEDECOMAPPING.keys()))
         
            return mapObjCopy
         
         
        def isBlocked(mapObj, gameStateObj, x, y):
            """Returns True if the (x, y) position on the map is
            blocked by a wall or star, otherwise return False."""
         
            if isWall(mapObj, x, y):
                return True
         
            elif x < 0 or x >= len(mapObj) or y < 0 or y >= len(mapObj[x]):
                return True # x and y aren't actually on the map.
         
            elif (x, y) in gameStateObj['stars']:
                return True # a star is blocking
         
            return False
         
         
        def makeMove(mapObj, gameStateObj, playerMoveTo):
            """Given a map and game state object, see if it is possible for the
            player to make the given move. If it is, then change the player's
            position (and the position of any pushed star). If not, do nothing.
            Returns True if the player moved, otherwise False."""
         
            # Make sure the player can move in the direction they want.
            playerx, playery = gameStateObj['player']
         
            # This variable is "syntactic sugar". Typing "stars" is more
            # readable than typing "gameStateObj['stars']" in our code.
            stars = gameStateObj['stars']
         
            # The code for handling each of the directions is so similar aside
            # from adding or subtracting 1 to the x/y coordinates. We can
            # simplify it by using the xOffset and yOffset variables.
            if playerMoveTo == UP:
                xOffset = 0
                yOffset = -1
            elif playerMoveTo == RIGHT:
                xOffset = 1
                yOffset = 0
            elif playerMoveTo == DOWN:
                xOffset = 0
                yOffset = 1
            elif playerMoveTo == LEFT:
                xOffset = -1
                yOffset = 0
         
            # See if the player can move in that direction.
            if isWall(mapObj, playerx + xOffset, playery + yOffset):
                return False
            else:
                if (playerx + xOffset, playery + yOffset) in stars:
                    # There is a star in the way, see if the player can push it.
                    if not isBlocked(mapObj, gameStateObj, playerx + (xOffset*2), playery + (yOffset*2)):
                        # Move the star.
                        ind = stars.index((playerx + xOffset, playery + yOffset))
                        stars[ind] = (stars[ind][0] + xOffset, stars[ind][1] + yOffset)
                    else:
                        return False
                # Move the player upwards.
                gameStateObj['player'] = (playerx + xOffset, playery + yOffset)
                return True
         
         
        def startScreen():
            """Display the start screen (which has the title and instructions)
            until the player presses a key. Returns None."""
         
            # Position the title image.
            titleRect = IMAGESDICT['title'].get_rect()
            topCoord = 50 # topCoord tracks where to position the top of the text
            titleRect.top = topCoord
            titleRect.centerx = HALF_WINWIDTH
            topCoord += titleRect.height
         
            # Unfortunately, Pygame's font & text system only shows one line at
            # a time, so we can't use strings with \n newline characters in them.
            # So we will use a list with each line in it.
            instructionText = ['Push the stars over the marks.',
                               'Arrow keys to move, WASD for camera control, P to change character.',
                               'Backspace to reset level, Esc to quit.',
                               'N for next level, B to go back a level.']
         
            # Start with drawing a blank color to the entire window:
            DISPLAYSURF.fill(BGCOLOR)
         
            # Draw the title image to the window:
            DISPLAYSURF.blit(IMAGESDICT['title'], titleRect)
         
            # Position and draw the text.
            for i in range(len(instructionText)):
                instSurf = BASICFONT.render(instructionText[i], 1, TEXTCOLOR)
                instRect = instSurf.get_rect()
                topCoord += 10 # 10 pixels will go in between each line of text.
                instRect.top = topCoord
                instRect.centerx = HALF_WINWIDTH
                topCoord += instRect.height # Adjust for the height of the line.
                DISPLAYSURF.blit(instSurf, instRect)
         
            while True: # Main loop for the start screen.
                for event in pygame.event.get():
                    if event.type == QUIT:
                        terminate()
                    elif event.type == KEYDOWN:
                        if event.key == K_ESCAPE:
                            terminate()
                        return # user has pressed a key, so return.
         
                # Display the DISPLAYSURF contents to the actual screen.
                pygame.display.update()
                FPSCLOCK.tick()
         
         
        def readLevelsFile(filename):
            assert os.path.exists(filename), 'Cannot find the level file: %s' % (filename)
            mapFile = open(filename, 'r')
            # Each level must end with a blank line
            content = mapFile.readlines() + ['\r\n']
            mapFile.close()
         
            levels = [] # Will contain a list of level objects.
            levelNum = 0
            mapTextLines = [] # contains the lines for a single level's map.
            mapObj = [] # the map object made from the data in mapTextLines
            for lineNum in range(len(content)):
                # Process each line that was in the level file.
                line = content[lineNum].rstrip('\r\n')
         
                if ';' in line:
                    # Ignore the ; lines, they're comments in the level file.
                    line = line[:line.find(';')]
         
                if line != '':
                    # This line is part of the map.
                    mapTextLines.append(line)
                elif line == '' and len(mapTextLines) > 0:
                    # A blank line indicates the end of a level's map in the file.
                    # Convert the text in mapTextLines into a level object.
         
                    # Find the longest row in the map.
                    maxWidth = -1
                    for i in range(len(mapTextLines)):
                        if len(mapTextLines[i]) > maxWidth:
                            maxWidth = len(mapTextLines[i])
                    # Add spaces to the ends of the shorter rows. This
                    # ensures the map will be rectangular.
                    for i in range(len(mapTextLines)):
                        mapTextLines[i] += ' ' * (maxWidth - len(mapTextLines[i]))
         
                    # Convert mapTextLines to a map object.
                    for x in range(len(mapTextLines[0])):
                        mapObj.append([])
                    for y in range(len(mapTextLines)):
                        for x in range(maxWidth):
                            mapObj[x].append(mapTextLines[y][x])
         
                    # Loop through the spaces in the map and find the @, ., and $
                    # characters for the starting game state.
                    startx = None # The x and y for the player's starting position
                    starty = None
                    goals = [] # list of (x, y) tuples for each goal.
                    stars = [] # list of (x, y) for each star's starting position.
                    for x in range(maxWidth):
                        for y in range(len(mapObj[x])):
                            if mapObj[x][y] in ('@', '+'):
                                # '@' is player, '+' is player & goal
                                startx = x
                                starty = y
                            if mapObj[x][y] in ('.', '+', '*'):
                                # '.' is goal, '*' is star & goal
                                goals.append((x, y))
                            if mapObj[x][y] in ('$', '*'):
                                # '$' is star
                                stars.append((x, y))
         
                    # Basic level design sanity checks:
                    assert startx != None and starty != None, 'Level %s (around line %s) in %s is missing a "@" or "+" to mark the start point.' % (levelNum+1, lineNum, filename)
                    assert len(goals) > 0, 'Level %s (around line %s) in %s must have at least one goal.' % (levelNum+1, lineNum, filename)
                    assert len(stars) >= len(goals), 'Level %s (around line %s) in %s is impossible to solve. It has %s goals but only %s stars.' % (levelNum+1, lineNum, filename, len(goals), len(stars))
         
                    # Create level object and starting game state object.
                    gameStateObj = {'player': (startx, starty),
                                    'stepCounter': 0,
                                    'stars': stars}
                    levelObj = {'width': maxWidth,
                                'height': len(mapObj),
                                'mapObj': mapObj,
                                'goals': goals,
                                'startState': gameStateObj}
         
                    levels.append(levelObj)
         
                    # Reset the variables for reading the next map.
                    mapTextLines = []
                    mapObj = []
                    gameStateObj = {}
                    levelNum += 1
            return levels
         
         
        def floodFill(mapObj, x, y, oldCharacter, newCharacter):
            """Changes any values matching oldCharacter on the map object to
            newCharacter at the (x, y) position, and does the same for the
            positions to the left, right, down, and up of (x, y), recursively."""
         
            # In this game, the flood fill algorithm creates the inside/outside
            # floor distinction. This is a "recursive" function.
            # For more info on the Flood Fill algorithm, see:
            #   http://en.wikipedia.org/wiki/Flood_fill
            if mapObj[x][y] == oldCharacter:
                mapObj[x][y] = newCharacter
         
            if x < len(mapObj) - 1 and mapObj[x+1][y] == oldCharacter:
                floodFill(mapObj, x+1, y, oldCharacter, newCharacter) # call right
            if x > 0 and mapObj[x-1][y] == oldCharacter:
                floodFill(mapObj, x-1, y, oldCharacter, newCharacter) # call left
            if y < len(mapObj[x]) - 1 and mapObj[x][y+1] == oldCharacter:
                floodFill(mapObj, x, y+1, oldCharacter, newCharacter) # call down
            if y > 0 and mapObj[x][y-1] == oldCharacter:
                floodFill(mapObj, x, y-1, oldCharacter, newCharacter) # call up
         
         
        def drawMap(mapObj, gameStateObj, goals):
            """Draws the map to a Surface object, including the player and
            stars. This function does not call pygame.display.update(), nor
            does it draw the "Level" and "Steps" text in the corner."""
         
            # mapSurf will be the single Surface object that the tiles are drawn
            # on, so that it is easy to position the entire map on the DISPLAYSURF
            # Surface object. First, the width and height must be calculated.
            mapSurfWidth = len(mapObj) * TILEWIDTH
            mapSurfHeight = (len(mapObj[0]) - 1) * TILEFLOORHEIGHT + TILEHEIGHT
            mapSurf = pygame.Surface((mapSurfWidth, mapSurfHeight))
            mapSurf.fill(BGCOLOR) # start with a blank color on the surface.
         
            # Draw the tile sprites onto this surface.
            for x in range(len(mapObj)):
                for y in range(len(mapObj[x])):
                    spaceRect = pygame.Rect((x * TILEWIDTH, y * TILEFLOORHEIGHT, TILEWIDTH, TILEHEIGHT))
                    if mapObj[x][y] in TILEMAPPING:
                        baseTile = TILEMAPPING[mapObj[x][y]]
                    elif mapObj[x][y] in OUTSIDEDECOMAPPING:
                        baseTile = TILEMAPPING[' ']
         
                    # First draw the base ground/wall tile.
                    mapSurf.blit(baseTile, spaceRect)
         
                    if mapObj[x][y] in OUTSIDEDECOMAPPING:
                        # Draw any tree/rock decorations that are on this tile.
                        mapSurf.blit(OUTSIDEDECOMAPPING[mapObj[x][y]], spaceRect)
                    elif (x, y) in gameStateObj['stars']:
                        if (x, y) in goals:
                            # A goal AND star are on this space, draw goal first.
                            mapSurf.blit(IMAGESDICT['covered goal'], spaceRect)
                        # Then draw the star sprite.
                        mapSurf.blit(IMAGESDICT['star'], spaceRect)
                    elif (x, y) in goals:
                        # Draw a goal without a star on it.
                        mapSurf.blit(IMAGESDICT['uncovered goal'], spaceRect)
         
                    # Last draw the player on the board.
                    if (x, y) == gameStateObj['player']:
                        # Note: The value "currentImage" refers
                        # to a key in "PLAYERIMAGES" which has the
                        # specific player image we want to show.
                        mapSurf.blit(PLAYERIMAGES[currentImage], spaceRect)
         
            return mapSurf
         
         
        def isLevelFinished(levelObj, gameStateObj):
            """Returns True if all the goals have stars in them."""
            for goal in levelObj['goals']:
                if goal not in gameStateObj['stars']:
                    # Found a space with a goal but no star on it.
                    return False
            return True
         
         
        def terminate():
            pygame.quit()
            fasdasdf1()
         
         
        if __name__ == '__main__':
            main()
    elif dakai == "chidou":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/8defd98dfc8abb86ca99a4868e7c0ca9.html")
        fasdasdf1()
    elif dakai == "golf":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/eef5e6e99eab6aa5cd835d37af7cd917.html")
        fasdasdf1()
    elif dakai == "paoku":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/b6ae97d07cd81d80fb34936befab82a9.html")
        fasdasdf1()
    elif dakai == "saolei":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/e29d9731f6f375a43b3b9850969de32a.html")
        fasdasdf1()
    elif dakai == "saiche":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/30ba9fcfcbc6579e0ac0b87857cc09a9.html")
        fasdasdf1()
    elif dakai == "dongwu":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/075dc7de1161e72b1829cb1dee36236e.html")
        fasdasdf1()
    elif dakai == "fanpai":
        
        FPS = 20 # frames per second, the general speed of the program
        WINDOWWIDTH = 640 # size of window's width in pixels
        WINDOWHEIGHT = 480 # size of windows' height in pixels
        REVEALSPEED = 8 # speed boxes' sliding reveals and covers
        BOXSIZE = 40 # size of box height & width in pixels
        GAPSIZE = 10 # size of gap between boxes in pixels
        BOARDWIDTH = 10 # number of columns of icons
        BOARDHEIGHT = 7 # number of rows of icons
        assert (BOARDWIDTH * BOARDHEIGHT) % 2 == 0, 'Board needs to have an even number of boxes for pairs of matches.'
        XMARGIN = int((WINDOWWIDTH - (BOARDWIDTH * (BOXSIZE + GAPSIZE))) / 2)
        YMARGIN = int((WINDOWHEIGHT - (BOARDHEIGHT * (BOXSIZE + GAPSIZE))) / 2)
        
        #            R    G    B
        GRAY     = (100, 100, 100)
        NAVYBLUE = ( 60,  60, 100)
        WHITE    = (255, 255, 255)
        RED      = (255,   0,   0)
        GREEN    = (  0, 255,   0)
        BLUE     = (  0,   0, 255)
        YELLOW   = (255, 255,   0)
        ORANGE   = (255, 128,   0)
        PURPLE   = (255,   0, 255)
        CYAN     = (  0, 255, 255)
        
        BGCOLOR = NAVYBLUE
        LIGHTBGCOLOR = GRAY
        BOXCOLOR = WHITE
        HIGHLIGHTCOLOR = BLUE
        
        DONUT = 'donut'
        SQUARE = 'square'
        DIAMOND = 'diamond'
        LINES = 'lines'
        OVAL = 'oval'
        
        ALLCOLORS = (RED, GREEN, BLUE, YELLOW, ORANGE, PURPLE, CYAN)
        ALLSHAPES = (DONUT, SQUARE, DIAMOND, LINES, OVAL)
        assert len(ALLCOLORS) * len(ALLSHAPES) * 2 >= BOARDWIDTH * BOARDHEIGHT, "Board is too big for the number of shapes/colors defined."
        
        def main():
            global FPSCLOCK, DISPLAYSURF
            pygame.init()
            FPSCLOCK = pygame.time.Clock()
            DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
        
            mousex = 0 # used to store x coordinate of mouse event
            mousey = 0 # used to store y coordinate of mouse event
            pygame.display.set_caption('Memory Game')
        
            mainBoard = getRandomizedBoard()
            revealedBoxes = generateRevealedBoxesData(False)
        
            firstSelection = None # stores the (x, y) of the first box clicked.
        
            DISPLAYSURF.fill(BGCOLOR)
            startGameAnimation(mainBoard)
        
            while True: # main game loop
                mouseClicked = False
        
                DISPLAYSURF.fill(BGCOLOR) # drawing the window
                drawBoard(mainBoard, revealedBoxes)
        
                for event in pygame.event.get(): # event handling loop
                    if event.type == QUIT or (event.type == KEYUP and event.key == K_ESCAPE):
                        pygame.quit()
                        sys.exit()
                    elif event.type == MOUSEMOTION:
                        mousex, mousey = event.pos
                    elif event.type == MOUSEBUTTONUP:
                        mousex, mousey = event.pos
                        mouseClicked = True
        
                boxx, boxy = getBoxAtPixel(mousex, mousey)
                if boxx != None and boxy != None:
                    # The mouse is currently over a box.
                    if not revealedBoxes[boxx][boxy]:
                        drawHighlightBox(boxx, boxy)
                    if not revealedBoxes[boxx][boxy] and mouseClicked:
                        revealBoxesAnimation(mainBoard, [(boxx, boxy)])
                        revealedBoxes[boxx][boxy] = True # set the box as "revealed"
                        if firstSelection == None: # the current box was the first box clicked
                            firstSelection = (boxx, boxy)
                        else: # the current box was the second box clicked
                            # Check if there is a match between the two icons.
                            icon1shape, icon1color = getShapeAndColor(mainBoard, firstSelection[0], firstSelection[1])
                            icon2shape, icon2color = getShapeAndColor(mainBoard, boxx, boxy)
        
                            if icon1shape != icon2shape or icon1color != icon2color:
                                # Icons don't match. Re-cover up both selections.
                                pygame.time.wait(1000) # 1000 milliseconds = 1 sec
                                coverBoxesAnimation(mainBoard, [(firstSelection[0], firstSelection[1]), (boxx, boxy)])
                                revealedBoxes[firstSelection[0]][firstSelection[1]] = False
                                revealedBoxes[boxx][boxy] = False
                            elif hasWon(revealedBoxes): # check if all pairs found
                                gameWonAnimation(mainBoard)
                                pygame.time.wait(2000)
        
                                # Reset the board
                                mainBoard = getRandomizedBoard()
                                revealedBoxes = generateRevealedBoxesData(False)
        
                                # Show the fully unrevealed board for a second.
                                drawBoard(mainBoard, revealedBoxes)
                                pygame.display.update()
                                pygame.time.wait(1000)
        
                                # Replay the start game animation.
                                startGameAnimation(mainBoard)
                            firstSelection = None # reset firstSelection variable
        
                # Redraw the screen and wait a clock tick.
                pygame.display.update()
                FPSCLOCK.tick(FPS)
        
        
        def generateRevealedBoxesData(val):
            revealedBoxes = []
            for i in range(BOARDWIDTH):
                revealedBoxes.append([val] * BOARDHEIGHT)
            return revealedBoxes
        
        
        def getRandomizedBoard():
            # Get a list of every possible shape in every possible color.
            icons = []
            for color in ALLCOLORS:
                for shape in ALLSHAPES:
                    icons.append( (shape, color) )
        
            random.shuffle(icons) # randomize the order of the icons list
            numIconsUsed = int(BOARDWIDTH * BOARDHEIGHT / 2) # calculate how many icons are needed
            icons = icons[:numIconsUsed] * 2 # make two of each
            random.shuffle(icons)
        
            # Create the board data structure, with randomly placed icons.
            board = []
            for x in range(BOARDWIDTH):
                column = []
                for y in range(BOARDHEIGHT):
                    column.append(icons[0])
                    del icons[0] # remove the icons as we assign them
                board.append(column)
            return board
        
        
        def splitIntoGroupsOf(groupSize, theList):
            # splits a list into a list of lists, where the inner lists have at
            # most groupSize number of items.
            result = []
            for i in range(0, len(theList), groupSize):
                result.append(theList[i:i + groupSize])
            return result
        
        
        def leftTopCoordsOfBox(boxx, boxy):
            # Convert board coordinates to pixel coordinates
            left = boxx * (BOXSIZE + GAPSIZE) + XMARGIN
            top = boxy * (BOXSIZE + GAPSIZE) + YMARGIN
            return (left, top)
        
        
        def getBoxAtPixel(x, y):
            for boxx in range(BOARDWIDTH):
                for boxy in range(BOARDHEIGHT):
                    left, top = leftTopCoordsOfBox(boxx, boxy)
                    boxRect = pygame.Rect(left, top, BOXSIZE, BOXSIZE)
                    if boxRect.collidepoint(x, y):
                        return (boxx, boxy)
            return (None, None)
        
        
        def drawIcon(shape, color, boxx, boxy):
            quarter = int(BOXSIZE * 0.25) # syntactic sugar
            half =    int(BOXSIZE * 0.5)  # syntactic sugar
        
            left, top = leftTopCoordsOfBox(boxx, boxy) # get pixel coords from board coords
            # Draw the shapes
            if shape == DONUT:
                pygame.draw.circle(DISPLAYSURF, color, (left + half, top + half), half - 5)
                pygame.draw.circle(DISPLAYSURF, BGCOLOR, (left + half, top + half), quarter - 5)
            elif shape == SQUARE:
                pygame.draw.rect(DISPLAYSURF, color, (left + quarter, top + quarter, BOXSIZE - half, BOXSIZE - half))
            elif shape == DIAMOND:
                pygame.draw.polygon(DISPLAYSURF, color, ((left + half, top), (left + BOXSIZE - 1, top + half), (left + half, top + BOXSIZE - 1), (left, top + half)))
            elif shape == LINES:
                for i in range(0, BOXSIZE, 4):
                    pygame.draw.line(DISPLAYSURF, color, (left, top + i), (left + i, top))
                    pygame.draw.line(DISPLAYSURF, color, (left + i, top + BOXSIZE - 1), (left + BOXSIZE - 1, top + i))
            elif shape == OVAL:
                pygame.draw.ellipse(DISPLAYSURF, color, (left, top + quarter, BOXSIZE, half))
        
        
        def getShapeAndColor(board, boxx, boxy):
            # shape value for x, y spot is stored in board[x][y][0]
            # color value for x, y spot is stored in board[x][y][1]
            return board[boxx][boxy][0], board[boxx][boxy][1]
        
        
        def drawBoxCovers(board, boxes, coverage):
            # Draws boxes being covered/revealed. "boxes" is a list
            # of two-item lists, which have the x & y spot of the box.
            for box in boxes:
                left, top = leftTopCoordsOfBox(box[0], box[1])
                pygame.draw.rect(DISPLAYSURF, BGCOLOR, (left, top, BOXSIZE, BOXSIZE))
                shape, color = getShapeAndColor(board, box[0], box[1])
                drawIcon(shape, color, box[0], box[1])
                if coverage > 0: # only draw the cover if there is an coverage
                    pygame.draw.rect(DISPLAYSURF, BOXCOLOR, (left, top, coverage, BOXSIZE))
            pygame.display.update()
            FPSCLOCK.tick(FPS)
        
        
        def revealBoxesAnimation(board, boxesToReveal):
            # Do the "box reveal" animation.
            for coverage in range(BOXSIZE, (-REVEALSPEED) - 1, -REVEALSPEED):
                drawBoxCovers(board, boxesToReveal, coverage)
        
        
        def coverBoxesAnimation(board, boxesToCover):
            # Do the "box cover" animation.
            for coverage in range(0, BOXSIZE + REVEALSPEED, REVEALSPEED):
                drawBoxCovers(board, boxesToCover, coverage)
        
        
        def drawBoard(board, revealed):
            # Draws all of the boxes in their covered or revealed state.
            for boxx in range(BOARDWIDTH):
                for boxy in range(BOARDHEIGHT):
                    left, top = leftTopCoordsOfBox(boxx, boxy)
                    if not revealed[boxx][boxy]:
                        # Draw a covered box.
                        pygame.draw.rect(DISPLAYSURF, BOXCOLOR, (left, top, BOXSIZE, BOXSIZE))
                    else:
                        # Draw the (revealed) icon.
                        shape, color = getShapeAndColor(board, boxx, boxy)
                        drawIcon(shape, color, boxx, boxy)
        
        
        def drawHighlightBox(boxx, boxy):
            left, top = leftTopCoordsOfBox(boxx, boxy)
            pygame.draw.rect(DISPLAYSURF, HIGHLIGHTCOLOR, (left - 5, top - 5, BOXSIZE + 10, BOXSIZE + 10), 4)
        
        
        def startGameAnimation(board):
            # Randomly reveal the boxes 8 at a time.
            coveredBoxes = generateRevealedBoxesData(False)
            boxes = []
            for x in range(BOARDWIDTH):
                for y in range(BOARDHEIGHT):
                    boxes.append( (x, y) )
            random.shuffle(boxes)
            boxGroups = splitIntoGroupsOf(8, boxes)
        
            drawBoard(board, coveredBoxes)
            for boxGroup in boxGroups:
                revealBoxesAnimation(board, boxGroup)
                coverBoxesAnimation(board, boxGroup)
        
        
        def gameWonAnimation(board):
            # flash the background color when the player has won
            coveredBoxes = generateRevealedBoxesData(True)
            color1 = LIGHTBGCOLOR
            color2 = BGCOLOR
        
            for i in range(13):
                color1, color2 = color2, color1 # swap colors
                DISPLAYSURF.fill(color1)
                drawBoard(board, coveredBoxes)
                pygame.display.update()
                pygame.time.wait(300)
        
        
        def hasWon(revealedBoxes):
            # Returns True if all the boxes have been revealed, otherwise False
            for i in revealedBoxes:
                if False in i:
                    return False # return False if any boxes are covered.
            return True
        
        
        if __name__ == '__main__':
            main()
    elif dakai == "qiangzhan":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/99259bb0f6cc822179339fa14675dc46.html")
        fasdasdf1()
    elif dakai == "tafang":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/ee2195a882836455b058569b7d65e92b.html")
        fasdasdf1()
    elif dakai == "taila":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/86304eb307810bb22c4fe7e57a2c5895.html")
        fasdasdf1()
    elif dakai == "baowei":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/c80acba2086c3f1fdf15f004af9d1e99.html")
        fasdasdf1()
    elif dakai == "renzhe":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/68eea5a0578fc1c2b683e8e827fccf5a.html")
        fasdasdf1()
    elif dakai == "feiji":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/96b7d9a35d4f8faf9f1bf8c0797b0f77.html")
        fasdasdf1()
    elif dakai == "secai":
        # There are different box sizes, number of boxes, and
        # life depending on the "board size" setting selected.
        SMALLBOXSIZE  = 60 # size is in pixels
        MEDIUMBOXSIZE = 20
        LARGEBOXSIZE  = 11
        
        SMALLBOARDSIZE  = 6 # size is in boxes
        MEDIUMBOARDSIZE = 17
        LARGEBOARDSIZE  = 30
        
        SMALLMAXLIFE  = 10 # number of turns
        MEDIUMMAXLIFE = 30
        LARGEMAXLIFE  = 64
        
        FPS = 30
        WINDOWWIDTH = 640
        WINDOWHEIGHT = 480
        boxSize = MEDIUMBOXSIZE
        PALETTEGAPSIZE = 10
        PALETTESIZE = 45
        EASY = 0   # arbitrary but unique value
        MEDIUM = 1 # arbitrary but unique value
        HARD = 2   # arbitrary but unique value
        
        difficulty = MEDIUM # game starts in "medium" mode
        maxLife = MEDIUMMAXLIFE
        boardWidth = MEDIUMBOARDSIZE
        boardHeight = MEDIUMBOARDSIZE
        
        
        #            R    G    B
        WHITE    = (255, 255, 255)
        DARKGRAY = ( 70,  70,  70)
        BLACK    = (  0,   0,   0)
        RED      = (255,   0,   0)
        GREEN    = (  0, 255,   0)
        BLUE     = (  0,   0, 255)
        YELLOW   = (255, 255,   0)
        ORANGE   = (255, 128,   0)
        PURPLE   = (255,   0, 255)
        
        # The first color in each scheme is the background color, the next six are the palette colors.
        COLORSCHEMES = (((150, 200, 255), RED, GREEN, BLUE, YELLOW, ORANGE, PURPLE),
                        ((0, 155, 104),  (97, 215, 164),  (228, 0, 69),  (0, 125, 50),   (204, 246, 0),   (148, 0, 45),    (241, 109, 149)),
                        ((195, 179, 0),  (255, 239, 115), (255, 226, 0), (147, 3, 167),  (24, 38, 176),   (166, 147, 0),   (197, 97, 211)),
                        ((85, 0, 0),     (155, 39, 102),  (0, 201, 13),  (255, 118, 0),  (206, 0, 113),   (0, 130, 9),     (255, 180, 115)),
                        ((191, 159, 64), (183, 182, 208), (4, 31, 183),  (167, 184, 45), (122, 128, 212), (37, 204, 7),    (88, 155, 213)),
                        ((200, 33, 205), (116, 252, 185), (68, 56, 56),  (52, 238, 83),  (23, 149, 195),  (222, 157, 227), (212, 86, 185)))
        for i in range(len(COLORSCHEMES)):
            assert len(COLORSCHEMES[i]) == 7, 'Color scheme %s does not have exactly 7 colors.' % (i)
        bgColor = COLORSCHEMES[0][0]
        paletteColors =  COLORSCHEMES[0][1:]
        
        def main():
            global FPSCLOCK, DISPLAYSURF, LOGOIMAGE, SPOTIMAGE, SETTINGSIMAGE, SETTINGSBUTTONIMAGE, RESETBUTTONIMAGE
        
            pygame.init()
            FPSCLOCK = pygame.time.Clock()
            DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
        
            # Load images
            LOGOIMAGE = pygame.image.load('inkspilllogo.png')
            SPOTIMAGE = pygame.image.load('inkspillspot.png')
            SETTINGSIMAGE = pygame.image.load('inkspillsettings.png')
            SETTINGSBUTTONIMAGE = pygame.image.load('inkspillsettingsbutton.png')
            RESETBUTTONIMAGE = pygame.image.load('inkspillresetbutton.png')
        
            pygame.display.set_caption('Ink Spill')
            mousex = 0
            mousey = 0
            mainBoard = generateRandomBoard(boardWidth, boardHeight, difficulty)
            life = maxLife
            lastPaletteClicked = None
        
            while True: # main game loop
                paletteClicked = None
                resetGame = False
        
                # Draw the screen.
                DISPLAYSURF.fill(bgColor)
                drawLogoAndButtons()
                drawBoard(mainBoard)
                drawLifeMeter(life)
                drawPalettes()
        
                checkForQuit()
                for event in pygame.event.get(): # event handling loop
                    if event.type == MOUSEBUTTONUP:
                        mousex, mousey = event.pos
                        if pygame.Rect(WINDOWWIDTH - SETTINGSBUTTONIMAGE.get_width(),
                                       WINDOWHEIGHT - SETTINGSBUTTONIMAGE.get_height(),
                                       SETTINGSBUTTONIMAGE.get_width(),
                                       SETTINGSBUTTONIMAGE.get_height()).collidepoint(mousex, mousey):
                            resetGame = showSettingsScreen() # clicked on Settings button
                        elif pygame.Rect(WINDOWWIDTH - RESETBUTTONIMAGE.get_width(),
                                         WINDOWHEIGHT - SETTINGSBUTTONIMAGE.get_height() - RESETBUTTONIMAGE.get_height(),
                                         RESETBUTTONIMAGE.get_width(),
                                         RESETBUTTONIMAGE.get_height()).collidepoint(mousex, mousey):
                            resetGame = True # clicked on Reset button
                        else:
                            # check if a palette button was clicked
                            paletteClicked = getColorOfPaletteAt(mousex, mousey)
        
                if paletteClicked != None and paletteClicked != lastPaletteClicked:
                    # a palette button was clicked that is different from the
                    # last palette button clicked (this check prevents the player
                    # from accidentally clicking the same palette twice)
                    lastPaletteClicked = paletteClicked
                    floodAnimation(mainBoard, paletteClicked)
                    life -= 1
        
                    resetGame = False
                    if hasWon(mainBoard):
                        for i in range(4): # flash border 4 times
                            flashBorderAnimation(WHITE, mainBoard)
                        resetGame = True
                        pygame.time.wait(2000) # pause so the player can bask in victory
                    elif life == 0:
                        # life is zero, so player has lost
                        drawLifeMeter(0)
                        pygame.display.update()
                        pygame.time.wait(400)
                        for i in range(4):
                            flashBorderAnimation(BLACK, mainBoard)
                        resetGame = True
                        pygame.time.wait(2000) # pause so the player can suffer in their defeat
        
                if resetGame:
                    # start a new game
                    mainBoard = generateRandomBoard(boardWidth, boardHeight, difficulty)
                    life = maxLife
                    lastPaletteClicked = None
        
                pygame.display.update()
                FPSCLOCK.tick(FPS)
        
        
        def checkForQuit():
            # Terminates the program if there are any QUIT or escape key events.
            for event in pygame.event.get(QUIT): # get all the QUIT events
                pygame.quit() # terminate if any QUIT events are present
                sys.exit()
            for event in pygame.event.get(KEYUP): # get all the KEYUP events
                if event.key == K_ESCAPE:
                    pygame.quit() # terminate if the KEYUP event was for the Esc key
                    sys.exit()
                pygame.event.post(event) # put the other KEYUP event objects back
        
        
        def hasWon(board):
            # if the entire board is the same color, player has won
            for x in range(boardWidth):
                for y in range(boardHeight):
                    if board[x][y] != board[0][0]:
                        return False # found a different color, player has not won
            return True
        
        
        def showSettingsScreen():
            global difficulty, boxSize, boardWidth, boardHeight, maxLife, paletteColors, bgColor
        
            # The pixel coordinates in this function were obtained by loading
            # the inkspillsettings.png image into a graphics editor and reading
            # the pixel coordinates from there. Handy trick.
        
            origDifficulty = difficulty
            origBoxSize = boxSize
            screenNeedsRedraw = True
        
            while True:
                if screenNeedsRedraw:
                    DISPLAYSURF.fill(bgColor)
                    DISPLAYSURF.blit(SETTINGSIMAGE, (0,0))
        
                    # place the ink spot marker next to the selected difficulty
                    if difficulty == EASY:
                        DISPLAYSURF.blit(SPOTIMAGE, (30, 4))
                    if difficulty == MEDIUM:
                        DISPLAYSURF.blit(SPOTIMAGE, (8, 41))
                    if difficulty == HARD:
                        DISPLAYSURF.blit(SPOTIMAGE, (30, 76))
        
                    # place the ink spot marker next to the selected size
                    if boxSize == SMALLBOXSIZE:
                        DISPLAYSURF.blit(SPOTIMAGE, (22, 150))
                    if boxSize == MEDIUMBOXSIZE:
                        DISPLAYSURF.blit(SPOTIMAGE, (11, 185))
                    if boxSize == LARGEBOXSIZE:
                        DISPLAYSURF.blit(SPOTIMAGE, (24, 220))
        
                    for i in range(len(COLORSCHEMES)):
                        drawColorSchemeBoxes(500, i * 60 + 30, i)
        
                    pygame.display.update()
        
                screenNeedsRedraw = False # by default, don't redraw the screen
                for event in pygame.event.get(): # event handling loop
                    if event.type == QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == KEYUP:
                        if event.key == K_ESCAPE:
                            # Esc key on settings screen goes back to game
                            return not (origDifficulty == difficulty and origBoxSize == boxSize)
                    elif event.type == MOUSEBUTTONUP:
                        screenNeedsRedraw = True # screen should be redrawn
                        mousex, mousey = event.pos # syntactic sugar
        
                        # check for clicks on the difficulty buttons
                        if pygame.Rect(74, 16, 111, 30).collidepoint(mousex, mousey):
                            difficulty = EASY
                        elif pygame.Rect(53, 50, 104, 29).collidepoint(mousex, mousey):
                            difficulty = MEDIUM
                        elif pygame.Rect(72, 85, 65, 31).collidepoint(mousex, mousey):
                            difficulty = HARD
        
                        # check for clicks on the size buttons
                        elif pygame.Rect(63, 156, 84, 31).collidepoint(mousex, mousey):
                            # small board size setting:
                            boxSize = SMALLBOXSIZE
                            boardWidth = SMALLBOARDSIZE
                            boardHeight = SMALLBOARDSIZE
                            maxLife = SMALLMAXLIFE
                        elif pygame.Rect(52, 192, 106,32).collidepoint(mousex, mousey):
                            # medium board size setting:
                            boxSize = MEDIUMBOXSIZE
                            boardWidth = MEDIUMBOARDSIZE
                            boardHeight = MEDIUMBOARDSIZE
                            maxLife = MEDIUMMAXLIFE
                        elif pygame.Rect(67, 228, 58, 37).collidepoint(mousex, mousey):
                            # large board size setting:
                            boxSize = LARGEBOXSIZE
                            boardWidth = LARGEBOARDSIZE
                            boardHeight = LARGEBOARDSIZE
                            maxLife = LARGEMAXLIFE
                        elif pygame.Rect(14, 299, 371, 97).collidepoint(mousex, mousey):
                            # clicked on the "learn programming" ad
                            webbrowser.open('http://inventwithpython.com') # opens a web browser
                        elif pygame.Rect(178, 418, 215, 34).collidepoint(mousex, mousey):
                            # clicked on the "back to game" button
                            return not (origDifficulty == difficulty and origBoxSize == boxSize)
        
                        for i in range(len(COLORSCHEMES)):
                            # clicked on a color scheme button
                            if pygame.Rect(500, 30 + i * 60, MEDIUMBOXSIZE * 3, MEDIUMBOXSIZE * 2).collidepoint(mousex, mousey):
                                bgColor = COLORSCHEMES[i][0]
                                paletteColors  = COLORSCHEMES[i][1:]
        
        
        def drawColorSchemeBoxes(x, y, schemeNum):
            # Draws the color scheme boxes that appear on the "Settings" screen.
            for boxy in range(2):
                for boxx in range(3):
                    pygame.draw.rect(DISPLAYSURF, COLORSCHEMES[schemeNum][3 * boxy + boxx + 1], (x + MEDIUMBOXSIZE * boxx, y + MEDIUMBOXSIZE * boxy, MEDIUMBOXSIZE, MEDIUMBOXSIZE))
                    if paletteColors == COLORSCHEMES[schemeNum][1:]:
                        # put the ink spot next to the selected color scheme
                        DISPLAYSURF.blit(SPOTIMAGE, (x - 50, y))
        
        
        def flashBorderAnimation(color, board, animationSpeed=30):
            origSurf = DISPLAYSURF.copy()
            flashSurf = pygame.Surface(DISPLAYSURF.get_size())
            flashSurf = flashSurf.convert_alpha()
            for start, end, step in ((0, 256, 1), (255, 0, -1)):
                # the first iteration on the outer loop will set the inner loop
                # to have transparency go from 0 to 255, the second iteration will
                # have it go from 255 to 0. This is the "flash".
                for transparency in range(start, end, animationSpeed * step):
                    DISPLAYSURF.blit(origSurf, (0, 0))
                    r, g, b = color
                    flashSurf.fill((r, g, b, transparency))
                    DISPLAYSURF.blit(flashSurf, (0, 0))
                    drawBoard(board) # draw board ON TOP OF the transparency layer
                    pygame.display.update()
                    FPSCLOCK.tick(FPS)
            DISPLAYSURF.blit(origSurf, (0, 0)) # redraw the original surface
        
        
        def floodAnimation(board, paletteClicked, animationSpeed=25):
            origBoard = copy.deepcopy(board)
            floodFill(board, board[0][0], paletteClicked, 0, 0)
        
            for transparency in range(0, 255, animationSpeed):
                # The "new" board slowly become opaque over the original board.
                drawBoard(origBoard)
                drawBoard(board, transparency)
                pygame.display.update()
                FPSCLOCK.tick(FPS)
        
        
        def generateRandomBoard(width, height, difficulty=MEDIUM):
            # Creates a board data structure with random colors for each box.
            board = []
            for x in range(width):
                column = []
                for y in range(height):
                    column.append(random.randint(0, len(paletteColors) - 1))
                board.append(column)
        
            # Make board easier by setting some boxes to same color as a neighbor.
        
            # Determine how many boxes to change.
            if difficulty == EASY:
                if boxSize == SMALLBOXSIZE:
                    boxesToChange = 100
                else:
                    boxesToChange = 1500
            elif difficulty == MEDIUM:
                if boxSize == SMALLBOXSIZE:
                    boxesToChange = 5
                else:
                    boxesToChange = 200
            else:
                boxesToChange = 0
        
            # Change neighbor's colors:
            for i in range(boxesToChange):
                # Randomly choose a box whose color to copy
                x = random.randint(1, width-2)
                y = random.randint(1, height-2)
        
                # Randomly choose neighbors to change.
                direction = random.randint(0, 3)
                if direction == 0: # change left and up neighbor
                    board[x-1][y] = board[x][y]
                    board[x][y-1] = board[x][y]
                elif direction == 1: # change right and down neighbor
                    board[x+1][y] = board[x][y]
                    board[x][y+1] = board[x][y]
                elif direction == 2: # change right and up neighbor
                    board[x][y-1] = board[x][y]
                    board[x+1][y] = board[x][y]
                else: # change left and down neighbor
                    board[x][y+1] = board[x][y]
                    board[x-1][y] = board[x][y]
            return board
        
        
        def drawLogoAndButtons():
            # draw the Ink Spill logo and Settings and Reset buttons.
            DISPLAYSURF.blit(LOGOIMAGE, (WINDOWWIDTH - LOGOIMAGE.get_width(), 0))
            DISPLAYSURF.blit(SETTINGSBUTTONIMAGE, (WINDOWWIDTH - SETTINGSBUTTONIMAGE.get_width(), WINDOWHEIGHT - SETTINGSBUTTONIMAGE.get_height()))
            DISPLAYSURF.blit(RESETBUTTONIMAGE, (WINDOWWIDTH - RESETBUTTONIMAGE.get_width(), WINDOWHEIGHT - SETTINGSBUTTONIMAGE.get_height() - RESETBUTTONIMAGE.get_height()))
        
        
        def drawBoard(board, transparency=255):
            # The colored squares are drawn to a temporary surface which is then
            # drawn to the DISPLAYSURF surface. This is done so we can draw the
            # squares with transparency on top of DISPLAYSURF as it currently is.
            tempSurf = pygame.Surface(DISPLAYSURF.get_size())
            tempSurf = tempSurf.convert_alpha()
            tempSurf.fill((0, 0, 0, 0))
        
            for x in range(boardWidth):
                for y in range(boardHeight):
                    left, top = leftTopPixelCoordOfBox(x, y)
                    r, g, b = paletteColors[board[x][y]]
                    pygame.draw.rect(tempSurf, (r, g, b, transparency), (left, top, boxSize, boxSize))
            left, top = leftTopPixelCoordOfBox(0, 0)
            pygame.draw.rect(tempSurf, BLACK, (left-1, top-1, boxSize * boardWidth + 1, boxSize * boardHeight + 1), 1)
            DISPLAYSURF.blit(tempSurf, (0, 0))
        
        
        def drawPalettes():
            # Draws the six color palettes at the bottom of the screen.
            numColors = len(paletteColors)
            xmargin = int((WINDOWWIDTH - ((PALETTESIZE * numColors) + (PALETTEGAPSIZE * (numColors - 1)))) / 2)
            for i in range(numColors):
                left = xmargin + (i * PALETTESIZE) + (i * PALETTEGAPSIZE)
                top = WINDOWHEIGHT - PALETTESIZE - 10
                pygame.draw.rect(DISPLAYSURF, paletteColors[i], (left, top, PALETTESIZE, PALETTESIZE))
                pygame.draw.rect(DISPLAYSURF, bgColor,   (left + 2, top + 2, PALETTESIZE - 4, PALETTESIZE - 4), 2)
        
        
        def drawLifeMeter(currentLife):
            lifeBoxSize = int((WINDOWHEIGHT - 40) / maxLife)
        
            # Draw background color of life meter.
            pygame.draw.rect(DISPLAYSURF, bgColor, (20, 20, 20, 20 + (maxLife * lifeBoxSize)))
        
            for i in range(maxLife):
                if currentLife >= (maxLife - i): # draw a solid red box
                    pygame.draw.rect(DISPLAYSURF, RED, (20, 20 + (i * lifeBoxSize), 20, lifeBoxSize))
                pygame.draw.rect(DISPLAYSURF, WHITE, (20, 20 + (i * lifeBoxSize), 20, lifeBoxSize), 1) # draw white outline
        
        
        def getColorOfPaletteAt(x, y):
            # Returns the index of the color in paletteColors that the x and y parameters
            # are over. Returns None if x and y are not over any palette.
            numColors = len(paletteColors)
            xmargin = int((WINDOWWIDTH - ((PALETTESIZE * numColors) + (PALETTEGAPSIZE * (numColors - 1)))) / 2)
            top = WINDOWHEIGHT - PALETTESIZE - 10
            for i in range(numColors):
                # Find out if the mouse click is inside any of the palettes.
                left = xmargin + (i * PALETTESIZE) + (i * PALETTEGAPSIZE)
                r = pygame.Rect(left, top, PALETTESIZE, PALETTESIZE)
                if r.collidepoint(x, y):
                    return i
            return None # no palette exists at these x, y coordinates
        
        
        def floodFill(board, oldColor, newColor, x, y):
            # This is the flood fill algorithm.
            if oldColor == newColor or board[x][y] != oldColor:
                return
        
            board[x][y] = newColor # change the color of the current box
        
            # Make the recursive call for any neighboring boxes:
            if x > 0:
                floodFill(board, oldColor, newColor, x - 1, y) # on box to the left
            if x < boardWidth - 1:
                floodFill(board, oldColor, newColor, x + 1, y) # on box to the right
            if y > 0:
                floodFill(board, oldColor, newColor, x, y - 1) # on box to up
            if y < boardHeight - 1:
                floodFill(board, oldColor, newColor, x, y + 1) # on box to down
        
        
        def leftTopPixelCoordOfBox(boxx, boxy):
            # Returns the x and y of the left-topmost pixel of the xth & yth box.
            xmargin = int((WINDOWWIDTH - (boardWidth * boxSize)) / 2)
            ymargin = int((WINDOWHEIGHT - (boardHeight * boxSize)) / 2)
            return (boxx * boxSize + xmargin, boxy * boxSize + ymargin)
        
        
        if __name__ == '__main__':
            main()
    elif dakai == "heping":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/0570f61570c7e6b3b02d4007c9d8bf19.html")
        fasdasdf1()
    elif dakai == "wangzhe":
        cefpython.Initialize()
    
        def fangwen(a):
        
            if "https://" in a:
                a = a.replace("https://","http://")
            if "http://" not in a:
                a = "http://" + a
            cefpython.CreateBrowserSync(cefpython.WindowInfo(),url = a)
            cefpython.MessageLoop()

        fangwen("https://livefile.xesimg.com/programme/python_assets/75eb463230104eb7cc467e49c869409b.html")
        fasdasdf1()
    elif dakai == "off":
        caidanlan = Tk()
        caidanlan.geometry("250x350")
        caidanlan.title("开始菜单")

        applb = Listbox(caidanlan, width = 90, height = 30, bg = "grey", fg = "blue")
        for i in range(len(applist)):
            applb.insert(0,applist[i])
            
        
        applb.pack()
        caidanlan.mainloop()
        fasdasdf1()
fasdasdf1()#curselection()